import {createRequire} from 'node:module';
import {join} from 'node:path';
export const CAP=150000;
export function scalar(s){if(typeof s!=='string'||/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/u.test(s))throw Error('SCALAR');return s;}
export function checkedAddon(native){if(!native||typeof native.version!=='function'||native.version()!==1)throw Error('ABI_VERSION');return native;}
export function addon(root){return checkedAddon(createRequire(import.meta.url)(join(root,'index-primitives.node')));}
export function batch(ops){
 if(!Array.isArray(ops)||ops.length<1||ops.length>16)throw Error('OPS');
 const chunks=[];let total=4;
 for(const op of ops){
  if(!op||typeof op!=='object'||Array.isArray(op)||![1,2].includes(op.kind)||Object.keys(op).sort().join(',')!==(op.kind===1?'id,kind,path,raw':'id,kind'))throw Error('OP_SHAPE');
  const fields=[op.id,op.kind===2?'':op.path,op.kind===2?'':op.raw],limits=[32,128,65536];
  for(let i=0;i<3;i++){if(typeof fields[i]!=='string'||fields[i].length>limits[i])throw Error('FIELD_LIMIT');scalar(fields[i]);if(Buffer.byteLength(fields[i])>limits[i])throw Error('FIELD_LIMIT');}
  const sizes=fields.map(x=>Buffer.byteLength(x));if(total+16+sizes.reduce((a,b)=>a+b,0)>70000)throw Error('WIRE_LIMIT');
  const [id,path,raw]=fields.map(x=>Buffer.from(x));
  const head=Buffer.alloc(16);[op.kind,id.length,path.length,raw.length].forEach((n,i)=>head.writeUInt32LE(n,i*4));
  total+=16+id.length+path.length+raw.length;if(total>70000)throw Error('WIRE_LIMIT');chunks.push(head,id,path,raw);
 }const prefix=Buffer.alloc(4);prefix.writeUInt32LE(ops.length);return Buffer.concat([prefix,...chunks],total);
}
export function invoke(native,handle,op,input=Buffer.alloc(0),capacity=CAP){
 const out=Buffer.alloc(capacity),meta=Buffer.alloc(32);
 const code=native.call(handle,op,input,out,meta);const facts=Array.from({length:4},(_,i)=>Number(meta.readBigUInt64LE(i*8)));
 if(!Number.isInteger(code)||code<0||code>8||!facts.every(Number.isSafeInteger)||facts.some(n=>n<0)||facts[1]>CAP||facts[3]>1||(code===0&&facts[1]>capacity))throw Error('NATIVE_RESPONSE');
 return {code,generation:facts[0],length:facts[1],mutations:facts[2],poison:!!facts[3],text:code===0?new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(out.subarray(0,facts[1])):''};
}
export function query(native,handle,q){if(typeof q!=='string'||q.length>4096)throw Error('QUERY_LIMIT');return invoke(native,handle,3,Buffer.from(scalar(q)));}
export function parse(text){const rows=text.trimEnd()?text.trimEnd().split('\n').map(x=>x.split('\t')):[];return rows;}
export function wire(value){
 if(!value||typeof value!=='object'||Array.isArray(value))return false;
 if(Object.keys(value).sort().join(',')!=='epoch,id,op,payload,version')return false;
 return value.version===1&&Number.isSafeInteger(value.id)&&value.id>0&&Number.isSafeInteger(value.epoch)&&value.epoch>0&&
 ['open','batch','commit','commitLost','query','live','close','cancel','hold','release'].includes(value.op);
}
export function validResult(r,op){
 if(!r||typeof r!=='object'||Array.isArray(r))return false;
 const keys=Object.keys(r).sort().join(',');
 if(keys==='code,unknown')return r.code==='BRIDGE_ERROR'&&typeof r.unknown==='boolean';
 if(keys==='code')return (op==='open'&&Number.isInteger(r.code)&&r.code>=1&&r.code<=8)||(op==='hold'&&r.code===0);
 if(op==='open')return keys==='abi,code'&&r.code===0&&r.abi===1;
 if(op==='close'||op==='cancel')return keys==='closeSucceeded,closed,code,lastCommit'&&Number.isInteger(r.code)&&r.code>=0&&r.code<=8&&r.closed===true&&r.closeSucceeded===(r.code===0)&&Number.isSafeInteger(r.lastCommit)&&r.lastCommit>=0;
 return keys==='code,generation,length,mutations,poison,text'&&Number.isInteger(r.code)&&r.code>=0&&r.code<=8&&
  [r.generation,r.length,r.mutations].every(x=>Number.isSafeInteger(x)&&x>=0)&&r.length<=CAP&&typeof r.poison==='boolean'&&typeof r.text==='string'&&r.text.length<=CAP;
}
