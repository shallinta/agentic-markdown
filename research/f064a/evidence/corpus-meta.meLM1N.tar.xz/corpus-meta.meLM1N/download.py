import hashlib
import json
import pathlib
import sys
import urllib.error
import urllib.parse
import urllib.request

MAX_BYTES = 32 * 1024 * 1024


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def allowed(url):
    parsed = urllib.parse.urlsplit(url)
    if (parsed.scheme != 'https' or parsed.hostname != 'codeload.github.com'
            or parsed.port not in (None, 443) or parsed.username or parsed.password
            or parsed.fragment):
        raise ValueError('URL_OUTSIDE_ALLOWLIST')


def main():
    url, destination = sys.argv[1:]
    opener = urllib.request.build_opener(NoRedirect())
    history = []
    for hop in range(4):
        allowed(url)  # Checked before each actual request, not only at completion.
        request = urllib.request.Request(url, headers={'Accept-Encoding': 'identity'})
        try:
            response = opener.open(request, timeout=15)
        except urllib.error.HTTPError as error:
            if error.code not in (301, 302, 303, 307, 308):
                raise
            location = error.headers.get('Location')
            if not location or hop == 3:
                raise ValueError('REDIRECT_LIMIT_OR_MISSING_LOCATION')
            following = urllib.parse.urljoin(url, location)
            allowed(following)
            history.append({'url': url, 'status': error.code, 'next': following})
            error.close()
            url = following
            continue
        with response:
            if response.status != 200:
                raise ValueError('HTTP_NOT_200')
            allowed(response.url)
            length = response.headers.get('Content-Length')
            if length is not None and (not length.isdigit() or int(length) > MAX_BYTES):
                raise ValueError('CONTENT_LENGTH_LIMIT')
            count = 0
            digest = hashlib.sha256()
            with pathlib.Path(destination).open('xb') as output:
                while True:
                    block = response.read(65536)
                    if not block:
                        break
                    if count + len(block) > MAX_BYTES:
                        raise ValueError('TRANSFER_LIMIT')
                    output.write(block)
                    digest.update(block)
                    count += len(block)
            if length is not None and count != int(length):
                raise ValueError('CONTENT_LENGTH_MISMATCH')
            print(json.dumps({'url': url, 'redirects': history, 'status': 200,
                              'bytes': count, 'sha256': digest.hexdigest()}))
            return
    raise ValueError('NO_RESPONSE')


if __name__ == '__main__':
    main()
