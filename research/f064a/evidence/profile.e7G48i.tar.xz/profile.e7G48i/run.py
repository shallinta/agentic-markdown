import hashlib
import json
import pathlib
import stat
import time
from processes import BUN, ROOT, command, sha

PINS_SHA = '68bc3d22a47b87982abb02f92c688ce3ac47b05af246ae1fec390269c4f57de4'
SOURCE_FILES = ('run.py', 'processes.py', 'profile.mjs', 'pins.json')


def snapshot(directory):
    result = []
    for path in sorted(directory.iterdir()):
        metadata = path.lstat()
        assert stat.S_ISREG(metadata.st_mode), 'INDEX_NOT_REGULAR'
        result.append({'name': path.name, 'bytes': metadata.st_size, 'sha256': sha(path)})
    return result


def main():
    output = ROOT / ('run-' + str(time.time_ns()))
    output.mkdir()
    result = {'status': 'failed', 'purpose': 'cost-profile-not-original-timeout-retest'}
    source = None
    copy = output / 'index-copy'
    frozen = {name: sha(ROOT / name) for name in SOURCE_FILES}
    result['sources'] = frozen
    try:
        pin_bytes = (ROOT / 'pins.json').read_bytes()
        assert hashlib.sha256(pin_bytes).hexdigest() == PINS_SHA
        pins = json.loads(pin_bytes)
        source = pathlib.Path(pins['index'])
        assert snapshot(source) == pins['files'], 'ORIGINAL_INDEX_PINS'
        assert [f['name'] for f in pins['files']] == ['index.db', 'index.db-shm', 'index.db-wal']
        original_sqlite = source.parent.parent / 'sqlite.mjs'
        assert sha(original_sqlite) == pins['originalSQLiteSHA']
        assert sha(pathlib.Path(BUN)) == '539598c775882420b9d8deb7dc14d845f20f7d26f5600c50ab067dde6ac3f3bf'
        corpus = pathlib.Path(pins['corpus'])
        complete_bytes = (corpus / 'complete.json').read_bytes()
        assert hashlib.sha256(complete_bytes).hexdigest() == pins['completeSHA']
        complete = json.loads(complete_bytes)
        baseline = next(s for s in complete['stages'] if s['name'] == 'baseline')
        manifest_bytes = (corpus / 'baseline/manifest.json').read_bytes()
        assert hashlib.sha256(manifest_bytes).hexdigest() == baseline['pins']['manifest.json']
        manifest = json.loads(manifest_bytes)
        result['inputPins'] = {'completeSHA': pins['completeSHA'], 'baselinePins': baseline['pins'], 'index': pins['files']}
        for name, digest in baseline['pins'].items():
            assert sha(corpus / 'baseline' / name) == digest
        # Copy exact three ordinary files; never open original through SQLite.
        copy.mkdir()
        for entry in pins['files']:
            with (source / entry['name']).open('rb') as incoming, (copy / entry['name']).open('xb') as outgoing:
                remaining = entry['bytes']
                while remaining:
                    chunk = incoming.read(min(65536, remaining))
                    assert chunk, 'COPY_EOF'
                    outgoing.write(chunk)
                    remaining -= len(chunk)
                assert incoming.read(1) == b'', 'COPY_SIZE_CHANGED'
        assert snapshot(source) == pins['files'] and snapshot(copy) == pins['files'], 'COPY_PINS'
        result['copyBefore'] = snapshot(copy)
        argv = [BUN, str(ROOT / 'profile.mjs'), str(copy), str(corpus), 'baseline', pins['completeSHA']]
        rows = command(output, 'profile', argv, time.monotonic() + 60)
        queries = [row for row in rows if row.get('kind') == 'query']
        assert len(queries) == 24
        assert [(r['slot'], r['phase']) for r in queries[:4]] == [(s, 'first') for s in (1, 2, 10, 12)]
        expected = {q['slot']: q['hits'] for q in manifest['queries']}
        docs = {d['id']: d for d in manifest['documents']}
        first = {}
        for row in queries:
            slot = row['slot']
            assert slot in (1, 2, 10, 12)
            if row['phase'] == 'first':
                value = row['semantic']
                assert value['hits'] == expected[slot]
                ids = [d[0] for d in value['candidates']]
                assert ids == sorted(set(ids))
                assert all(digest == docs[key]['sha256'] for key, digest in value['candidates'])
                assert value['candidateBytes'] == sum(docs[key]['bytes'] for key in ids)
                if slot == 12:
                    assert ids == sorted(docs) and value['mode'] == 'scan-fallback'
                semantic = json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()
                assert row['digest'] == hashlib.sha256(semantic).hexdigest() and row['fullBytes'] == len(semantic)
                first[slot] = row
            for field in ('digest', 'fullBytes', 'candidateCount', 'hitCount'):
                assert row[field] == first[slot][field]
            assert all(isinstance(v, (int, float)) and v >= 0 for v in row['breakdown'].values())
        for slot in (1, 2, 10, 12):
            assert [r['repeat'] for r in queries if r['slot'] == slot and r['phase'] == 'profile'] == list(range(5))
        assert rows[0]['kind'] == 'ready' and rows[-1]['kind'] == 'closed'
        result['queries'] = queries
        result['status'] = 'complete'
    except Exception as error:
        result['outerError'] = repr(error)
        raise
    finally:
        try:
            result['sourcesAfter'] = {name: sha(ROOT / name) for name in SOURCE_FILES}
            assert result['sourcesAfter'] == frozen, 'SOURCE_CHANGED'
            if 'inputPins' in result:
                assert sha(corpus / 'complete.json') == pins['completeSHA'], 'COMPLETE_CHANGED'
                for name, digest in baseline['pins'].items():
                    assert sha(corpus / 'baseline' / name) == digest, 'INPUT_CHANGED'
                assert sha(original_sqlite) == pins['originalSQLiteSHA'], 'ORIGINAL_SOURCE_CHANGED'
            if source is not None:
                result['originalAfter'] = snapshot(source)
                assert result['originalAfter'] == result.get('inputPins', {}).get('index', json.loads((ROOT / 'pins.json').read_bytes())['files']), 'ORIGINAL_CHANGED'
            if copy.exists():
                result['copyAfter'] = snapshot(copy)
                before = {f['name']: f for f in result.get('copyBefore', [])}
                after = {f['name']: f for f in result['copyAfter']}
                result['copyControlChanges'] = {name: {'before': before.get(name), 'after': after.get(name)}
                                                for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)}
                if before:
                    assert before['index.db'] == after.get('index.db'), 'COPY_DATABASE_CHANGED'
                    assert after.get('index.db-wal', {'bytes': 0})['bytes'] == 0, 'COPY_WAL_WRITES'
                    assert set(after) <= {'index.db', 'index.db-wal', 'index.db-shm'}, 'COPY_NEW_FILE'
        except Exception as error:
            result['status'] = 'failed'
            result['verificationError'] = repr(error)
            raise
        finally:
            (output / 'receipt.json').write_text(json.dumps(result, indent=2))
            print(output)


if __name__ == '__main__':
    main()
