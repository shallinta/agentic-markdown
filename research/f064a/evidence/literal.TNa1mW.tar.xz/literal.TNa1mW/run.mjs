import { spawn, spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, statSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { strict as assert } from 'node:assert';
import { grams, token, validateScalarString, pureAdmissionCheck, admitQuery } from './common.mjs';

const root = new URL('.', import.meta.url).pathname.replace(/\/$/, '');
const tool = '/tmp/agentic-f064a-rust190.zxE80R';
const bun = '/tmp/agentic-direct186.uXVnAg/Agentic Markdown-canary.app/Contents/MacOS/bun';
const manifestHash = '0ef079d6e33348bc086d9808f21d89d98152b12001525a3c92f9c1040f66b163';
const lockHash = '639d75f7f400a528fb5879936175f31f51ba6a762e5cee8202f80f73dc00f347';
const bunHash = '539598c775882420b9d8deb7dc14d845f20f7d26f5600c50ab067dde6ac3f3bf';
const sha = path => createHash('sha256').update(readFileSync(path)).digest('hex');
const decode = bytes => new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(bytes);
const manifest = JSON.parse(readFileSync(root + '/manifest.json', 'utf8'));
const fixture = name => validateScalarString(decode(readFileSync(root + '/fixtures/' + name)));

function verify() {
  assert.equal(sha(root + '/manifest.json'), manifestHash);
  assert.equal(sha(root + '/Cargo.lock'), lockHash);
  assert.equal(sha(bun), bunHash);
  for (const ids of Object.values(manifest.groups)) {
    assert.ok(ids.length <= 16);
    const bytes = ids.reduce((sum, id) => {
      const entry = manifest.files.find(file => file.name === id + '.txt');
      assert.ok(entry && entry.bytes <= 65536);
      return sum + entry.bytes;
    }, 0);
    assert.ok(bytes <= 65536);
  }
  for (const file of manifest.files) {
    const path = root + '/fixtures/' + file.name;
    assert.ok(file.bytes <= 65536);
    assert.equal(statSync(path).size, file.bytes);
    assert.equal(sha(path), file.sha256);
    assert.equal(readFileSync(path).length, file.bytes);
    fixture(file.name);
  }
}

const mode = process.argv[2];
if (!['compile', 'diagnose'].includes(mode)) throw Error('EXPLICIT_MODE_REQUIRED');
verify();
const output = root + '/run-' + Date.now();
mkdirSync(output);
const env = {
  ...process.env,
  RUSTC: tool + '/prefix/bin/rustc',
  RUSTDOC: tool + '/prefix/bin/rustdoc',
  CARGO_HOME: tool + '/cargo-home',
  CARGO_TARGET_DIR: root + '/target',
  CARGO_HTTP_TIMEOUT: '30',
  CARGO_NET_RETRY: '2',
  PATH: tool + '/prefix/bin:/usr/bin:/bin:/usr/sbin:/sbin',
};
let activeStop;
let batchExpired = false;
let deadline = Infinity;
let batchTimer;

async function command(label, executable, args, limit) {
  const started = Date.now();
  const child = spawn(executable, args, { cwd: root, env, detached: true, stdio: ['ignore', 'pipe', 'pipe'] });
  const stdout = [], stderr = [];
  let bytes = 0, error, expired = false, killTimer;
  const kill = signal => {
    try { process.kill(-child.pid, signal); }
    catch (e) { if (e.code !== 'ESRCH') error = String(e); }
  };
  const stop = () => {
    expired = true;
    kill('SIGTERM');
    if (!killTimer) killTimer = setTimeout(() => kill('SIGKILL'), 5000);
  };
  activeStop = stop;
  for (const [stream, chunks] of [[child.stdout, stdout], [child.stderr, stderr]]) {
    stream.on('data', chunk => {
      bytes += chunk.length;
      if (bytes > 1048576) { error = 'OUTPUT_LIMIT'; stop(); return; }
      chunks.push(chunk);
    });
  }
  child.on('error', e => { error = String(e); });
  const timer = setTimeout(stop, limit);
  const [status, signal] = await new Promise(resolve => child.on('close', (s, sig) => resolve([s, sig])));
  clearTimeout(timer);
  if (killTimer) {
    await new Promise(resolve => setTimeout(resolve, 5100));
    clearTimeout(killTimer);
  }
  activeStop = undefined;
  const ps = spawnSync('/bin/ps', ['-axo', 'pid,ppid,pgid,command'], { encoding: 'utf8', timeout: 10000 });
  const members = (ps.stdout ?? '').split('\n').filter(line => line.trim().split(/\s+/)[2] === String(child.pid));
  const out = Buffer.concat(stdout), err = Buffer.concat(stderr);
  writeFileSync(output + '/' + label + '.stdout', out);
  writeFileSync(output + '/' + label + '.stderr', err);
  const receipt = { label, executable, args, started, elapsedMs: Date.now() - started,
    status, signal, error, expired, pid: child.pid, groupMembersAfter: members, psStatus: ps.status };
  writeFileSync(output + '/' + label + '.json', JSON.stringify(receipt, null, 2));
  if (status !== 0 || expired || error || members.length || ps.status !== 0 || batchExpired || Date.now() >= deadline) {
    throw Error('CASE_FAILED ' + label);
  }
  return decode(out);
}

function integer(text) {
  if (!/^\d+$/.test(text) || !Number.isSafeInteger(Number(text))) throw Error('INTEGER');
  return Number(text);
}

function rustResult(text) {
  const result = { grams: [], candidates: [], hits: [] };
  let terminal = false;
  for (const line of text.trimEnd().split('\n')) {
    const p = line.split('\t');
    if (terminal) throw Error('AFTER_TERMINAL');
    if (p[0] === 'G' && p.length === 3) result.grams.push([p[1], p[2] ? p[2].split(',') : []]);
    else if (p[0] === 'C' && p.length === 3) result.candidates.push([p[1], p[2]]);
    else if (p[0] === 'H' && p.length === 4) result.hits.push([p[1], integer(p[2]), integer(p[3])]);
    else if (p[0] === 'S' && p.length === 3) {
      result.mode = p[1];
      result.queryGrams = integer(p[2]);
      terminal = true;
    } else throw Error('TSV_RECORD');
  }
  if (!terminal) throw Error('MISSING_TERMINAL');
  return result;
}

function validateResult(result, expected) {
  assert.equal(result.mode, expected.mode);
  const candidates = result.candidates ?? [];
  const hits = result.hits ?? [];
  assert.deepEqual(candidates.map(row => row[0]), expected.candidates);
  assert.deepEqual(hits, expected.hits);
  if (expected.mode === 'skipped') {
    assert.deepEqual(result.grams ?? [], []);
    return;
  }
  assert.equal(result.queryGrams, grams(fixture(expected.queryFile), true).length);
  if (expected.index === 23) assert.equal(result.queryGrams, 128);
  if (expected.index === 24) assert.equal(result.queryGrams, 129);
  const expectedGrams = manifest.groups[expected.group].map(id => [id, grams(fixture(id + '.txt'))]);
  for (const [, values] of result.grams) for (const value of values) {
    const parsed = /^g([123])x([0-9a-f]+)$/.exec(value);
    assert.ok(parsed);
    const size = Number(parsed[1]), hex = parsed[2];
    assert.equal(hex.length, 6 * size);
    for (let i = 0; i < size; i++) {
      const scalar = parseInt(hex.slice(i * 6, (i + 1) * 6), 16);
      assert.ok(scalar <= 0x10ffff && !(scalar >= 0xd800 && scalar <= 0xdfff));
    }
  }
  assert.deepEqual(result.grams, expectedGrams);
  for (const [id, rawHex] of candidates) {
    assert.match(rawHex, /^(?:[0-9a-f]{2})*$/);
    assert.equal(rawHex, readFileSync(root + '/fixtures/' + id + '.txt').toString('hex'));
  }
  for (const [id, start, end] of hits) assert.equal(fixture(id + '.txt').slice(start, end), fixture(expected.queryFile));
}

try {
  if (mode === 'compile') {
    await command('compile', tool + '/prefix/bin/cargo', ['build', '--release', '--locked'], 600000);
  } else {
    deadline = Date.now() + 180000;
    batchTimer = setTimeout(() => { batchExpired = true; activeStop?.(); }, 180000);
    const admission = pureAdmissionCheck();
    // Independent literal encoding oracles, not results generated by either engine.
    assert.equal(token(['中']), 'g1x004e2d');
    assert.equal(token(['中', '文']), 'g2x004e2d006587');
    assert.equal(token(['😀']), 'g1x01f600');
    assert.equal(token(['𠮷']), 'g1x020bb7');
    let refusedDispatches = 0;
    assert.equal(admitQuery(fixture('refused.txt'), () => { refusedDispatches++; }).mode, 'cost-refused');
    assert.equal(refusedDispatches, 0);
    writeFileSync(output + '/admission.json', JSON.stringify({ ...admission, refusedDispatches }, null, 2));
    const results = [];
    for (const expected of manifest.cases) {
      let previous;
      for (const engine of ['sqlite', 'tantivy']) {
        verify();
        const remaining = deadline - Date.now();
        if (remaining <= 0) throw Error('BATCH_DEADLINE');
        const executable = engine === 'sqlite' ? bun : root + '/target/release/f064a-toolchain-check';
        const args = [root + '/fixtures', expected.group, expected.queryFile];
        if (engine === 'sqlite') args.unshift(root + '/sqlite.mjs');
        const raw = await command(engine + '-' + expected.index, executable, args, Math.min(15000, remaining));
        const result = engine === 'sqlite' ? JSON.parse(raw) : rustResult(raw);
        validateResult(result, expected);
        const comparable = { mode: result.mode, candidates: result.candidates ?? [], hits: result.hits ?? [] };
        if (previous) assert.deepEqual(comparable, previous);
        previous = comparable;
        verify();
        if (batchExpired || Date.now() >= deadline) throw Error('BATCH_DEADLINE');
        results.push({ engine, case: expected.index, ...result });
        writeFileSync(output + '/results.json', JSON.stringify(results, null, 2));
      }
    }
    assert.equal(results.length, manifest.engineCases);
  }
  verify();
  if (batchExpired || Date.now() >= deadline) throw Error('BATCH_DEADLINE');
  writeFileSync(output + '/receipt.json', JSON.stringify({ mode, status: 'complete', output, manifestHash, lockHash }, null, 2));
  console.log(output);
} catch (error) {
  writeFileSync(output + '/receipt.json', JSON.stringify({ mode, status: 'failed', output, error: String(error) }, null, 2));
  console.error(error);
  process.exitCode = 1;
} finally {
  clearTimeout(batchTimer);
}
