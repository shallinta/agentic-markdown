import assert from 'node:assert/strict';
const worker = new Worker(new URL('./load-worker.mjs', import.meta.url));
await new Promise((resolve, reject) => {
  worker.onerror = reject;
  worker.onmessage = event => {
    assert.deepEqual(event.data, { closed: true, abi: 1 });
    resolve();
  };
  worker.postMessage('close');
});
// Only the parent process runner can attest natural exit.
console.log(JSON.stringify({ mode: 'load-addon-only', assertions: 'complete' }));
