import { Database } from 'bun:sqlite';
import { readFileSync, statSync, existsSync } from 'node:fs';
import { grams, validateScalarString } from './common.mjs';
const [databasePath, fixturePath, stageText] = process.argv.slice(2);
const stage = Number(stageText);
if (!Number.isInteger(stage) || stage < 1 || stage > 7) throw Error('STAGE');
const readonly = stage === 2 || stage === 7;
if (stage === 1 ? existsSync(databasePath) : !existsSync(databasePath)) throw Error('INDEX_EXISTENCE');
const db = new Database(databasePath, { create: stage === 1, readonly, readwrite: !readonly });
const decode = bytes => validateScalarString(new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(bytes));
if (stage === 1) {
  db.exec("create table originals(id text unique not null, path text not null, raw blob not null); create virtual table gram_index using fts5(tokens, tokenize='ascii'); pragma user_version=1");
}
const version = db.query('pragma user_version').get().user_version;
if (version !== 1) throw Error('SCHEMA_VERSION');
const columns = db.query('pragma table_info(originals)').all().map(c => [c.name, c.type.toLowerCase()]);
if (JSON.stringify(columns) !== JSON.stringify([['id', 'text'], ['path', 'text'], ['raw', 'blob']])) throw Error('SCHEMA');
const ftsSQL = db.query("select sql from sqlite_master where name='gram_index'").get()?.sql;
if (!ftsSQL?.includes("using fts5(tokens, tokenize='ascii')")) throw Error('FTS_SCHEMA');
function remove(id) {
  const row = db.query('select rowid from originals where id=?').get(id);
  if (!row) throw Error('MISSING_DELETE');
  db.query('delete from gram_index where rowid=?').run(row.rowid);
  db.query('delete from originals where rowid=?').run(row.rowid);
}
function add(id, path, name) {
  const file = fixturePath + '/' + name + '.txt';
  const size = statSync(file).size;
  if (size > 1024) throw Error('INPUT_BUDGET');
  const bytes = readFileSync(file);
  if (bytes.length !== size) throw Error('INPUT_CHANGED');
  const raw = decode(bytes);
  const inserted = db.query('insert into originals(id,path,raw) values(?,?,?)').run(id, path, bytes);
  db.query('insert into gram_index(rowid,tokens) values(?,?)').run(inserted.lastInsertRowid, grams(raw).join(' '));
}
if (!readonly) db.transaction(() => {
  if (stage === 1) add('a', 'p.md', 'a0');
  if (stage === 3) add('b', 'q.md', 'b');
  if (stage === 4) { remove('a'); add('a', 'p.md', 'a1'); }
  if (stage === 5) remove('a');
  if (stage === 6) add('c', 'p.md', 'c');
})();
const result = db.transaction(() => {
  const live = db.query('select id,path,raw from originals order by id').all();
  if (live.length > 3) throw Error('LIVE_BUDGET');
  const indexed = db.query('select rowid from gram_index order by rowid').all().map(r => r.rowid);
  const ordinary = db.query('select rowid from originals order by rowid').all().map(r => r.rowid);
  if (JSON.stringify(indexed) !== JSON.stringify(ordinary)) throw Error('ORPHAN_ROW');
  for (const row of live) {
    if (!(row.raw instanceof Uint8Array) || row.raw.byteLength > 1024) throw Error('STORED_BYTES');
    if (!Buffer.from(decode(row.raw)).equals(Buffer.from(row.raw))) throw Error('ROUNDTRIP');
  }
  const queries = ['旧词', '新词', '重建', '😀', '旁文'].map(query => {
    const rows = db.query('select originals.id, originals.raw from gram_index join originals on originals.rowid=gram_index.rowid where gram_index match ?').iterate(grams(query, true).join(' AND '));
    const hits = [], candidates = [];
    for (const row of rows) {
      if (candidates.length >= 3) throw Error('CANDIDATE_COUNT');
      if (!(row.raw instanceof Uint8Array) || row.raw.byteLength > 1024) throw Error('CANDIDATE_BYTES');
      const raw = decode(row.raw), start = raw.indexOf(query);
      candidates.push([row.id, Buffer.from(row.raw).toString('hex')]);
      if (start >= 0) hits.push([row.id, start, start + query.length]);
    }
    const compare = (a, b) => a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0;
    candidates.sort(compare); hits.sort(compare);
    if (candidates.some((r, i) => i && r[0] === candidates[i - 1][0])) throw Error('DUPLICATE');
    return { candidates, hits };
  });
  return { stage, readonly, live: live.map(r => [r.id, r.path, Buffer.from(r.raw).toString('hex')]), queries };
})();
result.metadata = { sqlite: db.query('select sqlite_version() as v').get().v,
  source: db.query('select sqlite_source_id() as v').get().v, options: db.query('pragma compile_options').all() };
db.close();
console.log(JSON.stringify(result));
