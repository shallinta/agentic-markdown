mod sha256;
use std::{collections::{BTreeMap, BTreeSet}, env, fmt::Write as _, fs,
    io::{self, BufRead, Write}, path::Path, time::Instant};
use tantivy::{collector::DocSetCollector, query::{AllQuery, BooleanQuery, Occur, Query, TermQuery},
    schema::{IndexRecordOption, Schema, Value, STORED, STRING}, Index, ReloadPolicy, TantivyDocument, Term};
type Failure = Box<dyn std::error::Error>;
const MODEL: usize = 346_977_964;
#[derive(Clone)]
struct Doc { bytes: usize, hash: String, file: String }
struct Spec { slot: usize, text: String, hits: Vec<(String, usize, usize)> }
fn unhex(s: &str) -> Result<String, Failure> {
    if s.len() % 2 != 0 { return Err("HEX".into()); }
    let bytes = (0..s.len()).step_by(2).map(|i| u8::from_str_radix(&s[i..i+2], 16)).collect::<Result<Vec<_>,_>>()?;
    Ok(String::from_utf8(bytes)?)
}
fn read_docs(path: &str) -> Result<BTreeMap<String, Doc>, Failure> {
    let mut result = BTreeMap::new();
    for line in fs::read_to_string(path)?.lines() {
        let p: Vec<_> = line.split('\t').collect();
        if p.len() != 4 || p[0].len() != 7 || !p[0][1..].bytes().all(|b| b.is_ascii_digit()) {
            return Err("DOC_FIELDS".into());
        }
        let value = Doc {bytes: p[1].parse()?, hash: p[2].into(), file: unhex(p[3])?};
        if ![4096, 1048576].contains(&value.bytes) || result.insert(p[0].into(), value).is_some() {
            return Err("DOC_DUPLICATE_SIZE".into());
        }
    }
    if result.len() > 10101 { return Err("LIVE_BOUND".into()); }
    Ok(result)
}
fn grams(text: &str, query: bool) -> Result<Vec<String>, Failure> {
    if query && text.encode_utf16().count() > 4096 { return Err("QUERY_LIMIT".into()); }
    let chars: Vec<_> = text.chars().collect();
    let sizes = if query { vec![chars.len().min(3)] } else { vec![1, 2, 3] };
    let mut values = BTreeSet::new();
    for size in sizes {
        if size == 0 || size > chars.len() { continue; }
        for slice in chars.windows(size) {
            let mut token = format!("g{size}x");
            for c in slice { write!(&mut token, "{:06x}", *c as u32)?; }
            values.insert(token);
            if values.len() > if query {4096} else {1374} { return Err("DISTINCT_BOUND".into()); }
        }
    }
    let bytes = values.iter().map(String::len).sum::<usize>() + values.len().saturating_sub(1);
    if !query && bytes > 30227 { return Err("TOKEN_BYTES".into()); }
    Ok(values.into_iter().collect())
}
fn checked(key: &str, text: &str, docs: &BTreeMap<String, Doc>) -> Result<String, Failure> {
    let doc = docs.get(key).ok_or("ID")?;
    let hash = sha256::digest(text.as_bytes());
    if text.len() != doc.bytes || hash != doc.hash { return Err("RAW_IDENTITY".into()); }
    Ok(hash)
}
fn hits_json(hits: &[(String, usize, usize)]) -> String {
    format!("[{}]", hits.iter().map(|(key,s,e)| format!("[\"{key}\",{s},{e}]")).collect::<Vec<_>>().join(","))
}
fn emit(line: String, total: &mut usize) -> Result<(), Failure> {
    *total += line.len() + 1;
    if *total > 64*1024*1024 { return Err("OUTPUT_LIMIT".into()); }
    let mut out = io::stdout().lock();
    out.write_all(line.as_bytes())?; out.write_all(b"\n")?; out.flush()?;
    Ok(())
}
fn disk(path: &str) -> Result<String, Failure> {
    let mut bytes = 0; let mut files = 0;
    for entry in fs::read_dir(path)? {
        let m = entry?.metadata()?;
        if !m.is_file() { return Err("INDEX_NONFILE".into()); }
        bytes += m.len(); files += 1;
    }
    Ok(format!("{{\"bytes\":{bytes},\"files\":{files}}}"))
}
fn run() -> Result<(), Failure> {
    if sha256::digest(b"abc") != "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        || sha256::digest(b"") != "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855" {
        return Err("SHA_KAT".into());
    }
    let args: Vec<_> = env::args().collect();
    if args.len() != 10 { return Err("ARGS".into()); }
    let sampling = &args[9];
    if !["correctness", "finite20"].contains(&sampling.as_str()) { return Err("SAMPLING".into()); }
    let mode=&args[1]; let directory=&args[2]; let stage=&args[3]; let corpus=&args[4];
    if !["build", "query", "update", "add", "delete", "cancel"].contains(&mode.as_str()) { return Err("MODE".into()); }
    // Host passes reviewed per-stage pins. No reading fixture bodies in query/cancel.
    for (name, hash) in [("docs.tsv", &args[5]), ("queries.tsv", &args[6]),
                         ("changes.tsv", &args[7]), ("deleted.tsv", &args[8])] {
        if sha256::digest(&fs::read(format!("{stage}/{name}"))?) != *hash { return Err("STAGE_SHA".into()); }
    }
    let docs=read_docs(&format!("{stage}/docs.tsv"))?;
    let changes=read_docs(&format!("{stage}/changes.tsv"))?;
    if docs.values().map(|d| d.bytes).sum::<usize>() > 43462656 || MODEL > 512*1024*1024 { return Err("MODEL".into()); }
    let deleted: Vec<String> = fs::read_to_string(format!("{stage}/deleted.tsv"))?.lines().map(str::to_owned).collect();
    let mut specs=Vec::new();
    for line in fs::read_to_string(format!("{stage}/queries.tsv"))?.lines() {
        let p:Vec<_>=line.split('\t').collect(); if p.len()!=3 { return Err("QUERY_FIELDS".into()); }
        let mut hits=Vec::new();
        if p[2]!="-" { for h in p[2].split(',') {
            let v:Vec<_>=h.split(':').collect(); if v.len()!=3 { return Err("HIT_FIELDS".into()); }
            hits.push((v[0].into(),v[1].parse()?,v[2].parse()?));
        }}
        specs.push(Spec {slot:p[0].parse()?,text:unhex(p[1])?,hits});
    }
    if specs.len()<12 || specs[6].text!="\n\n" || specs[8].text.as_bytes()!=b"e\xcc\x81" { return Err("QUERY_SET".into()); }
    let mut builder=Schema::builder();
    let id=builder.add_text_field("id", STRING|STORED);
    let path=builder.add_text_field("path", STORED);
    let raw=builder.add_text_field("raw", STORED);
    let gram=builder.add_text_field("gram", STRING); let schema=builder.build();
    let opened=Instant::now();
    let index=if mode=="build" {
        if Path::new(directory).exists() { return Err("INDEX_EXISTS".into()); }
        fs::create_dir(directory)?; Index::create_in_dir(directory,schema.clone())?
    } else {
        if !Path::new(directory).is_dir() { return Err("INDEX_MISSING".into()); }
        Index::open_in_dir(directory)?
    };
    if index.schema()!=schema { return Err("SCHEMA".into()); }
    let reader=index.reader_builder().reload_policy(ReloadPolicy::Manual).try_into()?;
    let mut output=0;
    emit(format!("{{\"kind\":\"ready\",\"mode\":\"{mode}\",\"openNs\":{},\"modelBytes\":{MODEL},\"indexThreads\":1,\"mergeThreads\":4,\"writerBytes\":52428800}}",opened.elapsed().as_nanos()),&mut output)?;
    let mutation=!["query","cancel"].contains(&mode.as_str());
    let disk_before=disk(directory)?;
    let started=Instant::now(); let mut batch_number=0;
    let mut final_writer=None;
    if mutation {
        let mut batches:Vec<Vec<(&String,&Doc)>>=Vec::new(); let mut batch=Vec::new();
        for item in &changes {
            if item.1.bytes==1048576 {
                if !batch.is_empty() { batches.push(std::mem::take(&mut batch)); }
                batches.push(vec![item]);
            } else {
                batch.push(item);
                if batch.len()==32 { batches.push(std::mem::take(&mut batch)); }
            }
        }
        if !batch.is_empty() { batches.push(batch); }
        if batches.is_empty() { batches.push(Vec::new()); }
        let last_batch=batches.len();
        let mut expected_live:BTreeSet<String>=if mode=="build" {BTreeSet::new()} else {docs.keys().cloned().collect()};
        if mode=="add" {for key in changes.keys() {expected_live.remove(key);}}
        if mode=="delete" {for key in &deleted {expected_live.insert(key.clone());}}
        for items in batches {
            let mut writer=index.writer_with_num_threads::<TantivyDocument>(1,50*1024*1024)?;
            if mode=="delete" { for key in &deleted { writer.delete_term(Term::from_field_text(id,key)); } }
            for (key,d) in &items {
                if mode=="update" { writer.delete_term(Term::from_field_text(id,key)); }
                let filename=format!("{corpus}/{}",d.file);
                if fs::metadata(&filename)?.len()!=d.bytes as u64 { return Err("INPUT_SIZE".into()); }
                let text=String::from_utf8(fs::read(filename)?)?; checked(key,&text,&docs)?;
                let mut doc=TantivyDocument::default();
                doc.add_text(id,String::as_str(*key)); doc.add_text(path,format!("{key}.md")); doc.add_text(raw,&text);
                for token in grams(&text,false)? { doc.add_text(gram,token); }
                writer.add_document(doc)?;
            }
            writer.commit()?; reader.reload()?;
            if mode=="delete" {for key in &deleted {expected_live.remove(key);}}
            for (key,_) in &items {expected_live.insert((*key).clone());}
            let batch_searcher=reader.searcher();
            let mut actual=BTreeSet::new();
            let batch_keys:BTreeSet<_>=items.iter().map(|(key,_)|String::as_str(*key)).collect();
            for address in batch_searcher.search(&AllQuery,&DocSetCollector)? {
                let found=batch_searcher.doc::<TantivyDocument>(address)?;
                let key=found.get_first(id).and_then(|v|v.as_str()).ok_or("BATCH_ID")?;
                if !actual.insert(key.to_owned()) {return Err("BATCH_DUPLICATE".into());}
                if batch_keys.contains(key) {
                    checked(key,found.get_first(raw).and_then(|v|v.as_str()).ok_or("BATCH_RAW")?,&docs)?;
                }
            }
            if actual!=expected_live {return Err("BATCH_LIVE_IDS".into());}
            let count=batch_searcher.num_docs(); drop(batch_searcher);
            batch_number+=1;
            emit(format!("{{\"kind\":\"batch\",\"number\":{batch_number},\"count\":{count}}}"),&mut output)?;
            // Public consumed-writer boundary includes queue draining and merge costs.
            if batch_number==last_batch {final_writer=Some(writer);}
            else {writer.wait_merging_threads()?;}
        }
    }
    reader.reload()?; let visible_ns=started.elapsed().as_nanos();
    let searcher=reader.searcher();
    let live_addresses=searcher.search(&AllQuery,&DocSetCollector)?;
    let mut live=BTreeSet::new();
    for address in live_addresses {
        let doc=searcher.doc::<TantivyDocument>(address)?;
        let key=doc.get_first(id).and_then(|v|v.as_str()).ok_or("ID")?;
        if !live.insert(key.to_string()) { return Err("DUPLICATE_LIVE".into()); }
    }
    if live!=docs.keys().cloned().collect() { return Err("LIVE_IDS".into()); }
    let mut schedule=Vec::new();
    if mode=="cancel" { schedule.push((&specs[0],"first",0)); }
    else {
        for q in &specs { schedule.push((q,if mutation {"commit-check"} else {"first"},0)); }
        if mode=="query" && sampling=="finite20" { for q in specs.iter().take(12) {
            for i in 0..10 { schedule.push((q,"warmup",i)); }
            for i in 0..20 { schedule.push((q,"timed",i)); }
        }}
    }
    let mut digests=BTreeMap::new();
    for (q,phase,repeat) in schedule {
        let start=Instant::now(); let tokens=grams(&q.text,true)?; let fallback=tokens.len()>128;
        let query:Box<dyn Query>=if fallback { Box::new(AllQuery) } else {
            Box::new(BooleanQuery::new(tokens.iter().map(|t| (Occur::Must,
                Box::new(TermQuery::new(Term::from_field_text(gram,t),IndexRecordOption::Basic)) as Box<dyn Query>)).collect()))
        };
        let addresses=searcher.search(query.as_ref(),&DocSetCollector)?;
        if addresses.len()>10101 { return Err("CANDIDATE_COUNT".into()); }
        let mut rows=Vec::new(); let mut bytes=0;
        for address in addresses {
            let doc=searcher.doc::<TantivyDocument>(address)?;
            let key=doc.get_first(id).and_then(|v|v.as_str()).ok_or("ID")?;
            let text=doc.get_first(raw).and_then(|v|v.as_str()).ok_or("RAW")?;
            let digest=checked(key,text,&docs)?; bytes+=text.len();
            if bytes>43462656 { return Err("CANDIDATE_BYTES".into()); }
            let span=text.find(&q.text).map(|i| { let s=text[..i].encode_utf16().count(); (s,s+q.text.encode_utf16().count()) });
            rows.push((key.to_owned(),digest,span));
        }
        rows.sort_by(|a,b|a.0.cmp(&b.0));
        if rows.windows(2).any(|x|x[0].0==x[1].0) { return Err("DUPLICATE".into()); }
        let hits:Vec<_>=rows.iter().filter_map(|(key,_,span)|span.map(|(s,e)|(key.clone(),s,e))).collect();
        let query_ns=start.elapsed().as_nanos(); if hits!=q.hits { return Err(format!("ORACLE_{}",q.slot).into()); }
        let serial=Instant::now();
        let candidates=format!("[{}]",rows.iter().map(|(key,hash,_)|format!("[\"{key}\",\"{hash}\"]")).collect::<Vec<_>>().join(","));
        let semantic=format!("{{\"slot\":{},\"candidates\":{candidates},\"candidateBytes\":{bytes},\"hits\":{},\"mode\":\"{}\"}}",q.slot,hits_json(&hits),if fallback {"scan-fallback"} else {"index"});
        let serial_ns=serial.elapsed().as_nanos(); let digest=sha256::digest(semantic.as_bytes());
        if digests.get(&q.slot).is_some_and(|previous|previous!=&digest) { return Err("REPEAT_SEMANTICS".into()); }
        digests.insert(q.slot,digest.clone());
        let full=if phase=="first" || phase=="commit-check" {format!(",\"semantic\":{semantic}")}else{String::new()};
        emit(format!("{{\"kind\":\"query\",\"phase\":\"{phase}\",\"repeat\":{repeat},\"slot\":{},\"queryNs\":{query_ns},\"serializeNs\":{serial_ns},\"fullBytes\":{},\"digest\":\"{digest}\",\"candidateCount\":{},\"hitCount\":{}{full}}}",q.slot,semantic.len(),rows.len(),hits.len()),&mut output)?;
    }
    if mode=="cancel" {
        emit("{\"kind\":\"batch-complete\",\"completed\":1,\"published\":1}".into(),&mut output)?;
        let mut line=String::new(); io::stdin().lock().read_line(&mut line)?;
        if line!="CANCEL\n" { return Err("CANCEL_PROTOCOL".into()); }
        emit("{\"kind\":\"cancelled\",\"completed\":1,\"published\":1}".into(),&mut output)?;
    }
    if mutation { emit(format!("{{\"kind\":\"mutation\",\"mode\":\"{mode}\",\"visibleNs\":{visible_ns},\"batches\":{batch_number},\"diskBefore\":{disk_before},\"disk\":{},\"writeAmplificationCaveat\":\"directory logical delta, not OS physical bytes written\"}}",disk(directory)?),&mut output)?; }
    let close=Instant::now(); drop(searcher); drop(reader);
    if let Some(writer)=final_writer {writer.wait_merging_threads()?;}
    drop(index);
    emit(format!("{{\"kind\":\"closed\",\"closeNs\":{},\"disk\":{}}}",close.elapsed().as_nanos(),disk(directory)?),&mut output)?;
    Ok(())
}
fn main() { if let Err(error)=run() { eprintln!("ERROR {error}"); std::process::exit(1); } }
