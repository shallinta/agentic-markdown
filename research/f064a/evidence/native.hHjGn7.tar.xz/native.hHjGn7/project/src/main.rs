use std::{env,fs,fmt::Write as _};
use tantivy::{Index,TantivyDocument,doc,collector::DocSetCollector,query::QueryParser,schema::{Schema,STORED,TEXT,Value}};
fn hex(s:&str)->String { let mut r=String::new(); for b in s.as_bytes(){write!(&mut r,"{:02x}",b).unwrap();} r }
fn read(path:&str)->Result<String,Box<dyn std::error::Error>> {let b=fs::read(path)?;if b.len()>4096{return Err("input bound".into())}Ok(String::from_utf8(b)?)}
fn tokens(index:&Index,kind:&str,id:&str,text:&str)->Result<usize,Box<dyn std::error::Error>> {
 let mut analyzer=index.tokenizers().get("default").ok_or("missing default")?;
 let mut stream=analyzer.token_stream(text);let mut count=0;let mut last=0;
 while stream.advance(){let t=stream.token();if count>=256||t.offset_from<last||t.offset_from>t.offset_to||t.offset_to>text.len()||!text.is_char_boundary(t.offset_from)||!text.is_char_boundary(t.offset_to){return Err("token bounds".into())}last=t.offset_from;
 println!("T\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",kind,hex(id),hex(&t.text),t.position,t.position_length,t.offset_from,t.offset_to,hex(&text[t.offset_from..t.offset_to]));count+=1;}
 Ok(count)
}
fn run()->Result<(),Box<dyn std::error::Error>>{
 let args:Vec<String>=env::args().collect();if args.len()!=3{return Err("args".into())}let root=&args[1];let case=&args[2];
 let mut builder=Schema::builder();let id=builder.add_text_field("id",STORED);let body=builder.add_text_field("body",TEXT);let index=Index::create_in_ram(builder.build());
 if case=="empty"{println!("S\tskipped");return Ok(())}
 if case=="fixture"{for n in 0..6{let text=read(&format!("{}/doc-{}.txt",root,n))?;tokens(&index,"doc",&((b'a'+n as u8)as char).to_string(),&text)?;}println!("D\t6");return Ok(())}
 let n:usize=case.parse()?;if n>=15{return Err("query index".into())}
 let query=read(&format!("{}/query-{}.txt",root,n))?;let count=tokens(&index,"query",&format!("q{}",n),&query)?;
 let mut writer=index.writer(50_000_000)?;
 for n in 0..6{let text=read(&format!("{}/doc-{}.txt",root,n))?;writer.add_document(doc!(id=>((b'a'+n as u8)as char).to_string(),body=>text))?;}
 writer.commit()?;let reader=index.reader()?;reader.reload()?;let searcher=reader.searcher();
 let encoded=format!("\"{}\"",query.replace('\\',"\\\\").replace('"',"\\\""));
 let parsed=QueryParser::for_index(&index,vec![body]).parse_query(&encoded)?;
 let hits=searcher.search(&parsed,&DocSetCollector)?;let mut ids=Vec::new();
 for address in hits{let document=searcher.doc::<TantivyDocument>(address)?;let value=document.get_first(id).and_then(|v|v.as_str()).ok_or("missing id")?;ids.push(value.to_owned());}
 ids.sort();if ids.len()>6||ids.windows(2).any(|p|p[0]==p[1])||ids.iter().any(|s|s.len()!=1||!('a'..='f').contains(&s.chars().next().unwrap())){return Err("ids".into())}
 println!("R\t{}\t{}\t{}",hex(&encoded),count,ids.join(","));Ok(())
}
fn main(){if let Err(e)=run(){eprintln!("E\t{}",hex(&e.to_string()));std::process::exit(1)}}
