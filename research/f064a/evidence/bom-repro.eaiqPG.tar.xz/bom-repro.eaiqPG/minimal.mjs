import { Database } from 'bun:sqlite';
const raw = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true })
  .decode(Uint8Array.from([0xef, 0xbb, 0xbf, 0xe4, 0xb8, 0xad]));
const db = new Database(':memory:');
db.exec('create table t(raw text)');
db.query('insert into t values(?)').run(raw);
const stored = db.query('select raw from t').get().raw;
console.log(JSON.stringify({ candidates: [['f', Buffer.from(stored).toString('hex')]],
  hits: [['f', stored.indexOf('中'), stored.indexOf('中') + 1]] }));
