use std::{collections::BTreeSet, env, fmt::Write as _, fs};
use tantivy::{
    collector::DocSetCollector,
    query::{AllQuery, BooleanQuery, Occur, Query, TermQuery},
    schema::{IndexRecordOption, Schema, Value, STORED, STRING},
    Index, TantivyDocument, Term,
};

type Failure = Box<dyn std::error::Error>;

fn read(path: &str) -> Result<String, Failure> {
    let size = fs::metadata(path)?.len();
    if size > 65536 { return Err("INPUT_BUDGET".into()); }
    let bytes = fs::read(path)?;
    if bytes.len() as u64 != size { return Err("INPUT_CHANGED".into()); }
    Ok(String::from_utf8(bytes)?)
}

fn hex(text: &str) -> String {
    let mut output = String::new();
    for byte in text.as_bytes() { write!(&mut output, "{byte:02x}").unwrap(); }
    output
}

fn grams(text: &str, query: bool) -> Result<Vec<String>, Failure> {
    let chars: Vec<char> = text.chars().collect();
    let sizes = if query { vec![chars.len().min(3)] } else { vec![1, 2, 3] };
    let mut set = BTreeSet::new();
    for size in sizes {
        if size == 0 || size > chars.len() { continue; }
        for slice in chars.windows(size) {
            let mut token = format!("g{size}x");
            for ch in slice { write!(&mut token, "{:06x}", *ch as u32)?; }
            if token.len() != 3 + size * 6 { return Err("TOKEN".into()); }
            if !set.contains(&token) && set.len() >= 4096 { return Err("GRAM_BUDGET".into()); }
            set.insert(token);
        }
    }
    Ok(set.into_iter().collect())
}

fn run() -> Result<(), Failure> {
    let args: Vec<String> = env::args().collect();
    if args.len() != 4 { return Err("ARGS".into()); }
    let root = &args[1];
    let group = &args[2];
    let query = read(&format!("{root}/{}", args[3]))?;
    if query.encode_utf16().count() > 4096 {
        println!("S\tcost-refused\t0");
        return Ok(());
    }
    if query.is_empty() {
        println!("S\tskipped\t0");
        return Ok(());
    }
    let listing = read(&format!("{root}/{group}.tsv"))?;
    if listing.lines().count() > 16 { return Err("CORPUS_BUDGET".into()); }
    let mut docs = Vec::new();
    let mut total_bytes = 0;
    for line in listing.lines() {
        let (id, file) = line.split_once('\t').ok_or("LIST")?;
        if id.len() != 1 || !id.bytes().all(|b| b.is_ascii_lowercase()) { return Err("ID".into()); }
        let raw = read(&format!("{root}/{file}"))?;
        total_bytes += raw.len();
        if docs.len() >= 16 || total_bytes > 65536 { return Err("CORPUS_BUDGET".into()); }
        docs.push((id.to_owned(), raw));
    }
    let mut schema = Schema::builder();
    let id_field = schema.add_text_field("id", STORED);
    let raw_field = schema.add_text_field("raw", STORED);
    let gram_field = schema.add_text_field("gram", STRING);
    let index = Index::create_in_ram(schema.build());
    let mut writer = index.writer(50_000_000)?;
    for (id, raw) in &docs {
        let values = grams(raw, false)?;
        let mut document = TantivyDocument::default();
        document.add_text(id_field, id);
        document.add_text(raw_field, raw);
        for value in &values { document.add_text(gram_field, value); }
        writer.add_document(document)?;
        println!("G\t{id}\t{}", values.join(","));
    }
    writer.commit()?;
    let reader = index.reader()?;
    reader.reload()?;
    let searcher = reader.searcher();
    let tokens = grams(&query, true)?;
    let fallback = tokens.len() > 128;
    let search_query: Box<dyn Query> = if fallback {
        Box::new(AllQuery)
    } else {
        let mut clauses: Vec<(Occur, Box<dyn Query>)> = Vec::new();
        for token in &tokens {
            let term = Term::from_field_text(gram_field, token);
            clauses.push((Occur::Must, Box::new(TermQuery::new(term, IndexRecordOption::Basic))));
        }
        Box::new(BooleanQuery::new(clauses))
    };
    let addresses = searcher.search(&search_query, &DocSetCollector)?;
    if addresses.len() > 16 { return Err("CANDIDATE_BUDGET".into()); }
    let mut candidates = Vec::new();
    for address in addresses {
        let stored = searcher.doc::<TantivyDocument>(address)?;
        let id = stored.get_first(id_field).and_then(|v| v.as_str()).ok_or("STORED_ID")?;
        let raw = stored.get_first(raw_field).and_then(|v| v.as_str()).ok_or("STORED_RAW")?;
        candidates.push((id.to_owned(), raw.to_owned()));
    }
    candidates.sort_by(|a, b| a.0.cmp(&b.0));
    if candidates.windows(2).any(|w| w[0].0 == w[1].0) { return Err("DUPLICATE_ID".into()); }
    for (id, raw) in candidates {
        println!("C\t{id}\t{}", hex(&raw));
        if let Some(byte_start) = raw.find(&query) {
            let start = raw[..byte_start].encode_utf16().count();
            let end = start + query.encode_utf16().count();
            println!("H\t{id}\t{start}\t{end}");
        }
    }
    println!("S\t{}\t{}", if fallback { "scan-fallback" } else { "index" }, tokens.len());
    Ok(())
}

fn main() {
    if let Err(error) = run() {
        eprintln!("E\t{}", hex(&error.to_string()));
        std::process::exit(1);
    }
}
