import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { validateScalarString, pureAdmissionCheck } from './common.mjs';
const root = new URL('.', import.meta.url).pathname;
if (existsSync(root + 'manifest.json')) throw Error('FROZEN_MANIFEST_EXISTS');
mkdirSync(root + 'fixtures', { recursive: true });
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const documents = {
  A: { a: '中文检索支持中英混合。', b: '中国文字与全文搜索。', c: 'Alpha alpha alphabet',
    d: 'café cafe\u0301', e: '甲😀乙 𠮷野家', f: '\ufeff第一行\r\n第二行' },
  B: { g: 'abcXbcd', h: 'abcd', i: 'aaa', j: '甲😀乙甲😀乙', k: 'x"y\\z' },
  C: { u: Array.from({ length: 131 }, (_, i) => String.fromCodePoint(0x100 + i)).join(''),
    v: Array.from({ length: 131 }, (_, i) => String.fromCodePoint(0x182 - i)).join('') },
};
// Handwritten expected candidate IDs and first UTF16 spans, never engine-generated.
const cases = [
  ['A', '中', ['a', 'b'], [['a', 0, 1], ['b', 0, 1]]],
  ['A', '中文', ['a'], [['a', 0, 2]]],
  ['A', '文检', ['a'], [['a', 1, 3]]],
  ['A', '全文', ['b'], [['b', 5, 7]]],
  ['A', 'Alpha', ['c'], [['c', 0, 5]]],
  ['A', 'ALPHA', [], []],
  ['A', 'café', ['d'], [['d', 0, 4]]],
  ['A', 'cafe\u0301', ['d'], [['d', 5, 10]]],
  ['A', '😀', ['e'], [['e', 1, 3]]],
  ['A', '𠮷', ['e'], [['e', 5, 7]]],
  ['A', '第二行', ['f'], [['f', 6, 9]]],
  ['A', '不存在', [], []],
  ['A', 'alpha', ['c'], [['c', 6, 11]]],
  ['A', '"', [], []], ['A', '\\', [], []], ['A', '', [], [], 'skipped'],
  ['B', 'abcd', ['g', 'h'], [['h', 0, 4]]],
  ['B', 'aaaa', ['i'], []],
  ['B', '😀', ['j'], [['j', 1, 3]]],
  ['B', 'bcd', ['g', 'h'], [['g', 4, 7], ['h', 1, 4]]],
  ['B', 'ABC', [], []],
  ['B', '"', ['k'], [['k', 1, 2]]], ['B', '\\', ['k'], [['k', 3, 4]]],
  ['C', documents.C.u.slice(0, 130), ['u'], [['u', 0, 130]]],
  ['C', documents.C.u, ['u', 'v'], [['u', 0, 131]], 'scan-fallback'],
];
const files = [];
function save(name, text) {
  validateScalarString(text);
  const bytes = Buffer.from(text, 'utf8');
  writeFileSync(root + 'fixtures/' + name, bytes, { flag: 'wx' });
  files.push({ name, bytes: bytes.length, sha256: sha(bytes) });
}
const groups = {};
for (const [group, docs] of Object.entries(documents)) {
  groups[group] = Object.keys(docs);
  for (const [id, text] of Object.entries(docs)) save(id + '.txt', text);
  save(group + '.tsv', Object.keys(docs).map(id => id + '\t' + id + '.txt').join('\n') + '\n');
}
const oracle = cases.map(([group, query, candidates, hits, mode = 'index'], index) => {
  save('q' + index + '.txt', query);
  return { index, group, queryFile: 'q' + index + '.txt', mode, candidates, hits };
});
save('refused.txt', 'a'.repeat(4097));
const manifest = { groups, files, cases: oracle, engineCases: 50, pureAdmission: pureAdmissionCheck() };
writeFileSync(root + 'manifest.json', JSON.stringify(manifest, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ manifestSHA: sha(Buffer.from(JSON.stringify(manifest, null, 2) + '\n')), files: files.length }));
