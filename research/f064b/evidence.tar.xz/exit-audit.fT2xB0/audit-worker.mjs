import assert from 'node:assert/strict';
import { addon } from '/tmp/agentic-f064b-bridge.w0G13h/protocol.mjs';
const native = addon('/tmp/agentic-f064b-bridge.w0G13h');
let started = false;
function session(path) {
  let handle = native.open(Buffer.from(path), 0);
  assert.equal(typeof handle, 'object');
  const opened = native.stats();
  const code = native.close(handle);
  assert.equal(code, 0);
  const afterClose = native.stats();
  handle = null;
  return { opened, afterClose, code };
}
self.onmessage = async event => {
  assert.equal(started, false);
  started = true;
  const { mode, index, audit } = event.data;
  assert.ok(mode === 'audit' || mode === 'audit-gc');
  assert.equal(native.audit(Buffer.from(audit)), 0);
  const result = session(index);
  // Both arms yield identically; only the GC arm adds the explicit diagnostic call.
  for (let i = 0; i < 30; i++) {
    if (mode === 'audit-gc') Bun.gc(true);
    await new Promise(resolve => setTimeout(resolve, 1));
  }
  const afterYield = native.stats();
  postMessage({ mode, ...result, afterYield, closed: true });
  close();
};
