import assert from 'node:assert/strict';
import { join } from 'node:path';
const [mode, output] = process.argv.slice(2);
assert.ok(mode === 'audit' || mode === 'audit-gc');
const worker = new Worker(new URL('./audit-worker.mjs', import.meta.url));
await new Promise((resolve, reject) => {
  worker.onerror = reject;
  worker.onmessage = event => {
    const result = event.data;
    assert.equal(result.mode, mode);
    assert.equal(result.code, 0);
    assert.equal(result.closed, true);
    assert.equal(result.opened.allocated, 1);
    assert.equal(result.opened.closed, 0);
    assert.equal(result.afterClose.closed, 1);
    assert.equal(result.afterYield.closed, 1);
    // freed/cleanup timing are observations, not presumed outcomes.
    console.log(JSON.stringify({ observation: result }));
    resolve();
  };
  worker.postMessage({ mode, index: join(output, 'index'), audit: join(output, 'native.audit') });
});
console.log(JSON.stringify({ mode, assertions: 'complete' }));
