import { isDeepStrictEqual } from 'node:util';
import { validResult, wire } from './protocol.mjs';

const which = process.argv[4];
const expectedGenerations = { '1': [], '2': [4, 4], '3': [], '4': [1], '5': [], '6': [1] }[which];
if (!expectedGenerations) throw Error('CASE');
const NativeWorker = globalThis.Worker;
const states = [];
let failed = false, events = 0, summaryWritten = false;
function record(data) {
  events++;
  if (events <= 256) console.log(JSON.stringify({ observer: data }));
  else failed = true;
}
function reject(state, reason) {
  failed = true;
  state.failures++;
  record({ worker: state.ordinal, event: 'failure', reason });
}
globalThis.Worker = class ObservedWorker extends NativeWorker {
  constructor(...args) {
    super(...args);
    const state = { ordinal: states.length + 1, requests: new Map(), lastId: 0,
      failures: 0, held: 0, released: 0, unknown: 0, errors: 0,
      closed: false, closeEvents: 0, closeCode: null };
    states.push(state);
    this.observerState = state;
    this.addEventListener('message', event => {
      const m = event.data;
      if (state.closed) { reject(state, 'AFTER_CLOSE'); return; }
      const request = state.requests.get(m?.id);
      if (!request || request.noReply || m.epoch !== request.epoch) { reject(state, 'UNSENT_RESPONSE'); return; }
      if (m.held === true) {
        if (which !== '4' || request.op !== 'hold' || request.held ||
            !isDeepStrictEqual(m, { held: true, id: request.id, epoch: request.epoch })) {
          reject(state, 'HELD_SHAPE'); return;
        }
        request.held = true;
        state.held++;
        record({ worker: state.ordinal, event: 'held', id: m.id });
        return;
      }
      if (m.version !== 1 || Object.keys(m).sort().join(',') !== 'epoch,id,result,version' ||
          request.terminal || !validResult(m.result, request.op)) {
        reject(state, 'RESPONSE_SHAPE'); return;
      }
      const expectedUnknown = which === '6' && request.op === 'commitLost';
      if (expectedUnknown) {
        if (!isDeepStrictEqual(m.result, { code: 'BRIDGE_ERROR', unknown: true })) reject(state, 'EXPECTED_UNKNOWN');
        state.unknown++;
      } else if (m.result.code !== 0) reject(state, 'UNEXPECTED_CODE');
      if (request.op === 'hold' && (!request.held || !request.released)) reject(state, 'HOLD_SEQUENCE');
      request.terminal = true;
      if (request.op === 'close' || request.op === 'cancel') {
        if (!isDeepStrictEqual(m.result, { code: 0, closed: true, closeSucceeded: true,
          lastCommit: expectedGenerations[state.ordinal - 1] })) reject(state, 'CLOSE_FACTS');
        state.closed = true;
      }
      record({ worker: state.ordinal, event: 'response', id: m.id, op: request.op,
        code: expectedUnknown ? 'expected-unknown' : m.result.code });
    });
    this.addEventListener('error', () => {
      state.errors++;
      reject(state, 'WORKER_ERROR');
    });
    this.addEventListener('close', event => {
      state.closeEvents++;
      state.closeCode = event.code;
      if (event.code !== 0 || state.closeEvents !== 1 || !state.closed) reject(state, 'CLOSE_EVENT');
      record({ worker: state.ordinal, event: 'close', code: event.code });
    });
  }
  postMessage(message, ...rest) {
    const s = this.observerState;
    if (!wire(message) || message.id <= s.lastId || s.closed || s.requests.size >= 128) {
      reject(s, 'DISPATCH_SHAPE');
      throw Error('OBSERVER_DISPATCH');
    }
    s.lastId = message.id;
    const request = { id: message.id, epoch: message.epoch, op: message.op, terminal: false };
    if (message.op === 'release') {
      const holds = [...s.requests.values()].filter(r => r.op === 'hold' && !r.terminal);
      if (which !== '4' || holds.length !== 1 || holds[0].released) {
        reject(s, 'RELEASE_SEQUENCE'); throw Error('OBSERVER_RELEASE');
      }
      holds[0].released = true;
      s.released++;
      request.noReply = true;
    }
    s.requests.set(message.id, request);
    record({ worker: s.ordinal, event: 'dispatch', id: message.id, op: message.op });
    try { return super.postMessage(message, ...rest); }
    catch (error) { reject(s, 'POST_MESSAGE'); throw error; }
  }
};
process.on('beforeExit', () => {
  const workers = states.map(s => {
    const pending = [...s.requests.values()].filter(r => !r.terminal && !r.noReply).length;
    const expectedHeld = which === '4' ? 1 : 0;
    const expectedUnknown = which === '6' ? 1 : 0;
    if (pending || !s.closed || s.closeEvents !== 1 || s.closeCode !== 0 || s.errors ||
        s.held !== expectedHeld || s.released !== expectedHeld || s.unknown !== expectedUnknown) failed = true;
    return { worker: s.ordinal, requests: s.requests.size, pending, closed: s.closed,
      closeEvents: s.closeEvents, closeCode: s.closeCode, held: s.held, released: s.released,
      unknown: s.unknown, errors: s.errors, failures: s.failures };
  });
  if (states.length !== expectedGenerations.length) failed = true;
  if (failed) process.exitCode = 1;
  if (!summaryWritten) {
    summaryWritten = true;
    console.log(JSON.stringify({ observerSummary: { case: which, failed, events, workers } }));
  }
});
await import('./cases.mjs');
