use std::{collections::BTreeSet, env, fmt::Write as _, fs, path::Path};
use tantivy::{
    collector::DocSetCollector,
    query::{AllQuery, BooleanQuery, Occur, Query, TermQuery},
    schema::{IndexRecordOption, Schema, Value, STORED, STRING},
    Index, ReloadPolicy, TantivyDocument, Term,
};
type Failure = Box<dyn std::error::Error>;

fn hex(text: &str) -> String {
    let mut output = String::new();
    for byte in text.as_bytes() { write!(&mut output, "{byte:02x}").unwrap(); }
    output
}

fn grams(text: &str, query: bool) -> Result<Vec<String>, Failure> {
    let chars: Vec<char> = text.chars().collect();
    let sizes = if query { vec![chars.len().min(3)] } else { vec![1, 2, 3] };
    let mut set = BTreeSet::new();
    for size in sizes {
        if size == 0 || size > chars.len() { continue; }
        for slice in chars.windows(size) {
            let mut value = format!("g{size}x");
            for ch in slice { write!(&mut value, "{:06x}", *ch as u32)?; }
            if !set.contains(&value) && set.len() >= 4096 { return Err("GRAM_BUDGET".into()); }
            set.insert(value);
        }
    }
    Ok(set.into_iter().collect())
}

fn read_fixture(root: &str, name: &str) -> Result<String, Failure> {
    let path = format!("{root}/{name}.txt");
    let size = fs::metadata(&path)?.len();
    if size > 1024 { return Err("INPUT_BUDGET".into()); }
    let bytes = fs::read(path)?;
    if bytes.len() as u64 != size { return Err("INPUT_CHANGED".into()); }
    Ok(String::from_utf8(bytes)?)
}

fn run() -> Result<(), Failure> {
    let args: Vec<String> = env::args().collect();
    if args.len() != 4 { return Err("ARGS".into()); }
    let directory = &args[1];
    let fixture_root = &args[2];
    let stage: usize = args[3].parse()?;
    if !(1..=7).contains(&stage) { return Err("STAGE".into()); }
    let readonly = stage == 2 || stage == 7;
    let mut builder = Schema::builder();
    let id_field = builder.add_text_field("id", STRING | STORED);
    let path_field = builder.add_text_field("path", STORED);
    let raw_field = builder.add_text_field("raw", STORED);
    let gram_field = builder.add_text_field("gram", STRING);
    let schema = builder.build();
    let index = if stage == 1 {
        if Path::new(directory).exists() { return Err("INDEX_EXISTS".into()); }
        fs::create_dir(directory)?;
        Index::create_in_dir(directory, schema.clone())?
    } else {
        if !Path::new(directory).is_dir() { return Err("INDEX_MISSING".into()); }
        Index::open_in_dir(directory)?
    };
    if index.schema() != schema { return Err("SCHEMA_MISMATCH".into()); }
    let reader = index.reader_builder().reload_policy(ReloadPolicy::Manual).try_into()?;
    let mut closing_writer = None;
    if !readonly {
        let mut writer = index.writer::<TantivyDocument>(50_000_000)?;
        if stage == 4 || stage == 5 {
            writer.delete_term(Term::from_field_text(id_field, "a"));
        }
        let next = match stage {
            1 => Some(("a", "p.md", "a0")),
            3 => Some(("b", "q.md", "b")),
            4 => Some(("a", "p.md", "a1")),
            6 => Some(("c", "p.md", "c")),
            _ => None,
        };
        if let Some((id, path, fixture)) = next {
            let raw = read_fixture(fixture_root, fixture)?;
            let mut doc = TantivyDocument::default();
            doc.add_text(id_field, id);
            doc.add_text(path_field, path);
            doc.add_text(raw_field, &raw);
            for token in grams(&raw, false)? { doc.add_text(gram_field, token); }
            writer.add_document(doc)?;
        }
        writer.commit()?;
        // Reload is the visibility step. Merge completion below is normal close only.
        reader.reload()?;
        closing_writer = Some(writer);
    } else {
        // Never create a writer or read fixture bodies in a reopen-only process.
        reader.reload()?;
    }
    let searcher = reader.searcher();
    let mut live = Vec::new();
    for address in searcher.search(&AllQuery, &DocSetCollector)? {
        let doc = searcher.doc::<TantivyDocument>(address)?;
        let id = doc.get_first(id_field).and_then(|v| v.as_str()).ok_or("ID")?;
        let path = doc.get_first(path_field).and_then(|v| v.as_str()).ok_or("PATH")?;
        let raw = doc.get_first(raw_field).and_then(|v| v.as_str()).ok_or("RAW")?;
        if raw.len() > 1024 || live.len() >= 3 { return Err("LIVE_BUDGET".into()); }
        live.push((id.to_owned(), path.to_owned(), raw.to_owned()));
    }
    live.sort_by(|a, b| a.0.cmp(&b.0));
    if live.windows(2).any(|w| w[0].0 == w[1].0) { return Err("DUPLICATE_ID".into()); }
    for (id, path, raw) in live { println!("D\t{id}\t{}\t{}", hex(&path), hex(&raw)); }
    for (number, query) in ["旧词", "新词", "重建", "😀", "旁文"].iter().enumerate() {
        let tokens = grams(query, true)?;
        if tokens.len() > 128 { return Err("FIXED_QUERY_CLAUSES".into()); }
        let clauses: Vec<(Occur, Box<dyn Query>)> = tokens.iter().map(|token| {
            let term = Term::from_field_text(gram_field, token);
            (Occur::Must, Box::new(TermQuery::new(term, IndexRecordOption::Basic)) as Box<dyn Query>)
        }).collect();
        let mut rows = Vec::new();
        for address in searcher.search(&BooleanQuery::new(clauses), &DocSetCollector)? {
            let doc = searcher.doc::<TantivyDocument>(address)?;
            let id = doc.get_first(id_field).and_then(|v| v.as_str()).ok_or("ID")?;
            let raw = doc.get_first(raw_field).and_then(|v| v.as_str()).ok_or("RAW")?;
            rows.push((id.to_owned(), raw.to_owned()));
        }
        rows.sort_by(|a, b| a.0.cmp(&b.0));
        for (id, raw) in rows {
            println!("C\t{number}\t{id}\t{}", hex(&raw));
            if let Some(byte_start) = raw.find(query) {
                let start = raw[..byte_start].encode_utf16().count();
                let end = start + query.encode_utf16().count();
                println!("H\t{number}\t{id}\t{start}\t{end}");
            }
        }
    }
    println!("S\t{stage}\t{}", if readonly { "readonly" } else { "committed" });
    // All live enumeration and query evaluation above happens before merge close.
    if let Some(writer) = closing_writer { writer.wait_merging_threads()?; }
    drop(searcher);
    drop(reader);
    drop(index);
    Ok(())
}

fn main() {
    if let Err(error) = run() {
        eprintln!("E\t{}", hex(&error.to_string()));
        std::process::exit(1);
    }
}
