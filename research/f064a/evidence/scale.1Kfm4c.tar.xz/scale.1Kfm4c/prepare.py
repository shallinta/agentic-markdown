"""Explicit execution only. Emits immutable fixtures/oracles, never invokes engines."""
import json
import pathlib
import sys
from model import (MIB, QUERIES, first, gram_stats, header, payload, reservation,
                   selftest, sha, units, write_json)

ROOT = pathlib.Path(__file__).resolve().parent
SELFTEST_SHA = '461ee2187b50b0d8f092efab7a092c1878b5a6422a42deabc85bfb613338b60e'


def main():
    n = int(sys.argv[1])
    budget = reservation(n)  # Before allocating corpus, metadata, or reference results.
    output = pathlib.Path(sys.argv[2])
    assert not output.exists(), 'NO_OVERWRITE'
    frozen = (ROOT / 'literal-inputs.json').read_bytes()
    assert sha(frozen) == SELFTEST_SHA
    selftest(json.loads(frozen))
    output.mkdir()
    (output / 'raw').mkdir()
    live = {}
    all_versions = {}

    def make(doc_id, revision, life, size):
        raw = payload(doc_id, revision, life, size)
        text = raw.decode('utf-8', 'strict')
        count, encoded = gram_stats(text)
        spans = [first(text, query) for query in QUERIES]
        assert all(span is not None for i, span in enumerate(spans) if i != 9)
        assert spans[9] is None, 'ABSENT_ORACLE'
        name = f'{doc_id}-r{revision}.raw'
        with (output / 'raw' / name).open('xb') as stream:
            stream.write(raw)
        item = {'id': doc_id, 'revision': revision, 'life': life, 'bytes': size,
                'sha256': sha(raw), 'output': 'raw/' + name, 'path': doc_id + '.md',
                'marker': header(doc_id, revision, life), 'spans': spans,
                'distinct': count, 'tokenBytes': encoded}
        assert name not in all_versions
        all_versions[name] = item
        live[doc_id] = item
        return item

    for i in range(n):
        make(f'S{i:06d}', 0, 'base', 4096 if i < n - 2 else MIB)

    stages = []
    def freeze(name, action, changed, deleted, old_markers):
        entries = [live[key] for key in sorted(live)]
        assert len(entries) <= budget['liveUpper']
        assert sum(d['bytes'] for d in entries) <= budget['rawUpperBytes']
        queries = []
        for slot, query in enumerate(QUERIES, 1):
            hits = [[d['id'], *d['spans'][slot - 1]] for d in entries
                    if d['spans'][slot - 1] is not None]
            queries.append({'slot': slot, 'text': query, 'utf16': units(query),
                            'sha256': sha(query.encode()), 'hits': hits})
        markers = [{'text': text, 'hits': []} for text in old_markers]
        if action != 'build':
            markers += [{'text': d['marker'], 'hits': [[d['id'], 0, units(d['marker'])]]}
                        for d in changed]
        stage = {'name': name, 'action': action, 'documents': entries,
                 'changed': changed, 'deleted': deleted, 'queries': queries, 'markers': markers}
        folder = output / name
        folder.mkdir()
        write_json(folder / 'manifest.json', stage)
        docs = ''.join(f"{d['id']}\t{d['bytes']}\t{d['sha256']}\t{d['output'].encode().hex()}\n" for d in entries)
        changes = ''.join(f"{d['id']}\t{d['bytes']}\t{d['sha256']}\t{d['output'].encode().hex()}\n" for d in changed)
        query_lines = []
        for q in queries + [{'slot': 100 + i, **m} for i, m in enumerate(markers)]:
            hit_text = ','.join(f'{key}:{start}:{end}' for key, start, end in q['hits']) or '-'
            query_lines.append(f"{q['slot']}\t{q['text'].encode().hex()}\t{hit_text}\n")
        for filename, text in [('docs.tsv', docs), ('changes.tsv', changes),
                               ('deleted.tsv', ''.join(key + '\n' for key in deleted)),
                               ('queries.tsv', ''.join(query_lines))]:
            with (folder / filename).open('x', encoding='utf-8') as stream:
                stream.write(text)
        pins = {p.name: sha(p.read_bytes()) for p in sorted(folder.iterdir())}
        stages.append({'name': name, 'action': action, 'pins': pins})

    freeze('baseline', 'build', list(live.values()), [], [])
    for tag, k, revision, prefix in [('one', 1, 1, 'A'), ('percent', (n + 99) // 100, 2, 'B')]:
        old = [live[f'S{i:06d}']['marker'] for i in range(k)]
        changed = [make(f'S{i:06d}', revision, 'base', live[f'S{i:06d}']['bytes']) for i in range(k)]
        freeze(tag + '-update', 'update', changed, [], old)
        changed = [make(f'{prefix}{i:06d}', 0, 'add', 4096) for i in range(k)]
        freeze(tag + '-add', 'add', changed, [], [])
        deleted = [f'S{n - 1:06d}'] if tag == 'one' else [f'S{i:06d}' for i in range(n - k - 1, n - 1)]
        old = [live[key]['marker'] for key in deleted]
        for key in deleted:
            del live[key]
        freeze(tag + '-delete', 'delete', [], deleted, old)
    # Final completion exists only after all bytes, independent results, stages and pins.
    complete = {'version': 1, 'seed': 64064, 'n': n, 'budget': budget,
                'queryHex': [q.encode().hex() for q in QUERIES], 'stages': stages,
                'files': [{k: v for k, v in d.items() if k != 'spans'} for d in all_versions.values()],
                'selftest': {'literalCases': 25, 'rejected': 3}, 'complete': True}
    write_json(output / 'complete.json', complete)
    print(json.dumps({'complete': True, 'n': n, 'manifestSHA': sha((output / 'complete.json').read_bytes())}))


if __name__ == '__main__':
    main()
