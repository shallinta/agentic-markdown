import { Database } from 'bun:sqlite';
import { readFileSync, statSync } from 'node:fs';
import { admitQuery, grams, validateScalarString } from './common.mjs';
const [root, group, queryFile] = process.argv.slice(2);
const decode = bytes => new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(bytes);
const readBytes = name => {
  const path = root + '/' + name;
  const size = statSync(path).size;
  if (size > 65536) throw Error('INPUT_BUDGET');
  const bytes = readFileSync(path);
  if (bytes.length !== size) throw Error('INPUT_CHANGED');
  return bytes;
};
const read = name => validateScalarString(decode(readBytes(name)));
const query = read(queryFile);
const versions = new Database(':memory:');
const metadata = {
  version: versions.query('select sqlite_version() as v').get().v,
  source: versions.query('select sqlite_source_id() as v').get().v,
  options: versions.query('pragma compile_options').all(),
};
if (metadata.version !== '3.54.0' || !metadata.options.some(v => v.compile_options === 'ENABLE_FTS5')) throw Error('SQLITE_VERSION');
let result = admitQuery(query, () => {
  const lines = read(group + '.tsv').trimEnd().split('\n');
  if (lines.length > 16) throw Error('CORPUS_BUDGET');
  const docs = lines.map(line => {
    const [id, file] = line.split('\t');
    const bytes = readBytes(file);
    return { id, bytes, raw: validateScalarString(decode(bytes)) };
  });
  if (docs.length > 16 || docs.reduce((n, d) => n + Buffer.byteLength(d.raw), 0) > 65536) throw Error('CORPUS_BUDGET');
  const db = versions;
  db.exec("create table originals(id text primary key, raw blob not null); create virtual table gram_index using fts5(tokens, tokenize='ascii'); create virtual table vocab using fts5vocab(gram_index, 'instance')");
  const sets = [];
  db.transaction(() => {
    docs.forEach((d, i) => {
      const tokens = grams(d.raw);
      sets.push([d.id, tokens]);
      db.query('insert into originals(rowid,id,raw) values(?,?,?)').run(i + 1, d.id, d.bytes);
      db.query('insert into gram_index(rowid,tokens) values(?,?)').run(i + 1, tokens.join(' '));
    });
  })();
  const vocabulary = docs.map((d, i) => [d.id, db.query('select term from vocab where doc=? order by term').all(i + 1).map(r => r.term)]);
  if (JSON.stringify(vocabulary) !== JSON.stringify(sets)) throw Error('VOCAB_MISMATCH');
  const tokens = grams(query, true);
  const mode = tokens.length > 128 ? 'scan-fallback' : 'index';
  const rows = mode === 'scan-fallback'
    ? db.query('select id, raw from originals').iterate()
    : db.query('select originals.id, originals.raw from gram_index join originals on originals.rowid=gram_index.rowid where gram_index match ?').iterate(tokens.join(' AND '));
  const hits = [], candidates = [];
  for (const row of rows) {
    if (candidates.length >= 16) throw Error('CANDIDATE_BUDGET');
    const original = docs.find(document => document.id === row.id);
    if (!(row.raw instanceof Uint8Array) || row.raw.byteLength > 65536
      || !original || row.raw.byteLength !== original.bytes.byteLength) throw Error('STORED_BYTES');
    const raw = validateScalarString(decode(row.raw));
    const roundtrip = Buffer.from(raw, 'utf8');
    if (!roundtrip.equals(Buffer.from(row.raw))) throw Error('UTF8_ROUNDTRIP');
    candidates.push([row.id, Buffer.from(row.raw).toString('hex')]);
    const start = raw.indexOf(query);
    if (start >= 0) hits.push([row.id, start, start + query.length]);
  }
  const compare = (a, b) => a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0;
  candidates.sort(compare); hits.sort(compare);
  if (candidates.some((r, i) => i && r[0] === candidates[i - 1][0])) throw Error('DUPLICATE');
  return { mode, queryGrams: tokens.length, grams: sets, candidates, hits };
});
console.log(JSON.stringify({ ...result, metadata }));
