import {readFileSync,writeFileSync,statSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root='/tmp/agentic-f064a-toolchain.XOLigk';
const hashes={rustc:'249f4cacd3fac1f718af19373c73e9d3b9a595965972d8b1f3947c578110f520',cargo:'71c08c8fab9b7a9cd13b6119886d50ce48efa8261d08e1fd328ed3ee1c84e2e0','rust-std':'532be07511af557cb67f33bfc77044a787363ab281b963752542bc837ce90e96'};
for(const [name,expected] of Object.entries(hashes)){
 const file=`${root}/downloads/${name}.tar.xz`,prefix=`${name}-1.88.0-aarch64-apple-darwin`;
 const hash=createHash('sha256').update(readFileSync(file)).digest('hex');
 if(hash!==expected)throw Error('hash '+name);
 const result=spawnSync('/usr/bin/tar',['-tvf',file],{encoding:'utf8',timeout:60000,maxBuffer:16*1024*1024});
 writeFileSync(`${root}/logs/archive-v2-${name}.list`,result.stdout??'');
 if(result.status!==0)throw Error('list '+name);
 const verbose=result.stdout.trim().split('\n');
 // No links/devices accepted: this package check does not need to resolve links.
 if(verbose.some(line=>!['d','-'].includes(line[0])))throw Error('link or special entry '+name);
 if(!verbose.some(line=>line[0]==='d'&&line.endsWith(' '+prefix)))throw Error('root directory '+name);
 const paths=spawnSync('/usr/bin/tar',['-tf',file],{encoding:'utf8',timeout:60000,maxBuffer:16*1024*1024});
 if(paths.status!==0||paths.stdout.trim().split('\n').some(p=>p.startsWith('/')||p.split('/').includes('..')||(p!==prefix&&!p.startsWith(prefix+'/'))))throw Error('path '+name);
 console.log(JSON.stringify({name,hash,bytes:statSync(file).size,entries:paths.stdout.trim().split('\n').length,links:0}));
}
