import hashlib
import json
import os
import pathlib
import re
import signal
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
INPUT_SHA = '461ee2187b50b0d8f092efab7a092c1878b5a6422a42deabc85bfb613338b60e'


def frozen_inputs():
    raw = (ROOT / 'inputs.json').read_bytes()
    if hashlib.sha256(raw).hexdigest() != INPUT_SHA:
        raise ValueError('INPUT_SHA')
    return json.loads(raw)


def main():
    if sys.argv[1:] != ['plan-reference']:
        raise ValueError('EXPLICIT_MODE_REQUIRED')
    output = ROOT / ('run-' + str(time.time_ns()))
    output.mkdir()
    deadline = time.monotonic() + 180
    records = []
    manifest = frozen_inputs()
    entries = manifest['documents']
    if (len(entries) != 36 or [e['id'] for e in entries]
            != ['d' + str(i).zfill(2) for i in range(1, 37)]
            or sum(e['bytes'] for e in entries) != 352051
            or max(e['bytes'] for e in entries) != 25352):
        raise ValueError('DOCUMENT_MANIFEST')
    sources = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
               for name in ['inputs.json', 'reference.py', 'run.py']}
    (output / 'sources.json').write_text(json.dumps(sources, indent=2))

    def command(label, script, args, budget):
        remaining = min(budget, deadline - time.monotonic())
        if remaining <= 0:
            raise TimeoutError('BATCH_DEADLINE')
        started = time.monotonic()
        with (output / (label + '.stdout')).open('xb') as stdout, (output / (label + '.stderr')).open('xb') as stderr:
            process = subprocess.Popen([sys.executable, str(ROOT / script), *args],
                                       stdout=stdout, stderr=stderr, start_new_session=True)
            expired = False
            try:
                process.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                expired = True
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                time.sleep(5)
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait(timeout=10)
        ps = subprocess.run(['/bin/ps', '-axo', 'pid,ppid,pgid,command'], capture_output=True,
                            text=True, timeout=10, check=True)
        members = [line for line in ps.stdout.splitlines()
                   if len(line.split()) >= 3 and line.split()[2] == str(process.pid)]
        receipt = {'label': label, 'python': sys.executable, 'script': script, 'args': args,
                   'pid': process.pid, 'exit': process.returncode, 'expired': expired,
                   'elapsedSeconds': time.monotonic() - started, 'members': members}
        (output / (label + '.json')).write_text(json.dumps(receipt, indent=2))
        if process.returncode != 0 or expired or members or time.monotonic() >= deadline:
            raise RuntimeError('FAILED_' + label)
        return json.loads((output / (label + '.stdout')).read_text())

    try:
        selftest = command('selftest', 'reference.py', ['selftest'], 15)
        query_result = command('queries', 'reference.py', ['queries'], 15)
        for entry in entries:
            frozen_inputs()
            result = command(entry['id'], 'reference.py', ['document', entry['id']], 15)
            frozen_inputs()
            records.append(result)
        oracle = []
        for i, query in enumerate(query_result['queries']):
            oracle.append({**query, 'hits': [[r['id'], *r['hits'][i]]
                                            for r in records if r['hits'][i] is not None]})
        by_id = {record['id']: record for record in records}
        for slot, doc_id, expected in [
            (1, 'd01', [2, 3]), (2, 'd09', [2, 4]),
            (3, 'd12', [2, 5]), (4, 'd01', [8, 18]),
            (6, 'd24', [3, 17]),
            (12, 'd01', [0, query_result['queries'][11]['utf16']]),
        ]:
            if by_id[doc_id]['hits'][slot - 1] != expected:
                raise AssertionError(('FROZEN_ANCHOR', slot, doc_id, expected))
        final = {'status': 'complete', 'selftest': selftest,
                 'statistics': records, 'oracle': oracle, 'sources': sources}
        encoded = json.dumps(final, ensure_ascii=True, indent=2).encode()
        if len(encoded) > 8 * 1024 * 1024 or time.monotonic() >= deadline:
            raise ValueError('FINAL_BUDGET')
        with (output / 'results.json').open('xb') as target:
            target.write(encoded)
        receipt = {'status': 'complete', 'documents': 36, 'queries': 12,
                   'resultsSHA': hashlib.sha256(encoded).hexdigest(), 'sources': sources}
    except Exception as error:
        receipt = {'status': 'failed', 'error': str(error), 'records': records}
        raise
    finally:
        (output / 'receipt.json').write_text(json.dumps(receipt, indent=2))
        print(output)


if __name__ == '__main__':
    main()


