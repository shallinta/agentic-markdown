import { Database } from 'bun:sqlite';
import { readFileSync, statSync } from 'node:fs';
import { admitQuery, grams, validateScalarString } from './common.mjs';
const [root, group, queryFile] = process.argv.slice(2);
const decode = bytes => new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(bytes);
const read = name => {
  const path = root + '/' + name;
  const size = statSync(path).size;
  if (size > 65536) throw Error('INPUT_BUDGET');
  const bytes = readFileSync(path);
  if (bytes.length !== size) throw Error('INPUT_CHANGED');
  return validateScalarString(decode(bytes));
};
const query = read(queryFile);
const versions = new Database(':memory:');
const metadata = {
  version: versions.query('select sqlite_version() as v').get().v,
  source: versions.query('select sqlite_source_id() as v').get().v,
  options: versions.query('pragma compile_options').all(),
};
if (metadata.version !== '3.54.0' || !metadata.options.some(v => v.compile_options === 'ENABLE_FTS5')) throw Error('SQLITE_VERSION');
let result = admitQuery(query, () => {
  const lines = read(group + '.tsv').trimEnd().split('\n');
  if (lines.length > 16) throw Error('CORPUS_BUDGET');
  const docs = lines.map(line => {
    const [id, file] = line.split('\t');
    return { id, raw: read(file) };
  });
  if (docs.length > 16 || docs.reduce((n, d) => n + Buffer.byteLength(d.raw), 0) > 65536) throw Error('CORPUS_BUDGET');
  const db = versions;
  db.exec("create table originals(id text primary key, raw text not null); create virtual table gram_index using fts5(tokens, tokenize='ascii'); create virtual table vocab using fts5vocab(gram_index, 'instance')");
  const sets = [];
  db.transaction(() => {
    docs.forEach((d, i) => {
      const tokens = grams(d.raw);
      sets.push([d.id, tokens]);
      db.query('insert into originals(rowid,id,raw) values(?,?,?)').run(i + 1, d.id, d.raw);
      db.query('insert into gram_index(rowid,tokens) values(?,?)').run(i + 1, tokens.join(' '));
    });
  })();
  const vocabulary = docs.map((d, i) => [d.id, db.query('select term from vocab where doc=? order by term').all(i + 1).map(r => r.term)]);
  if (JSON.stringify(vocabulary) !== JSON.stringify(sets)) throw Error('VOCAB_MISMATCH');
  const tokens = grams(query, true);
  const mode = tokens.length > 128 ? 'scan-fallback' : 'index';
  const rows = mode === 'scan-fallback'
    ? db.query('select id, raw from originals order by id').all()
    : db.query('select originals.id, originals.raw from gram_index join originals on originals.rowid=gram_index.rowid where gram_index match ? order by originals.id').all(tokens.join(' AND '));
  if (rows.length > 16) throw Error('CANDIDATE_BUDGET');
  const hits = [];
  for (const row of rows) {
    const start = row.raw.indexOf(query);
    if (start >= 0) hits.push([row.id, start, start + query.length]);
  }
  return { mode, queryGrams: tokens.length, grams: sets, candidates: rows.map(r => [r.id, Buffer.from(r.raw).toString('hex')]), hits };
});
console.log(JSON.stringify({ ...result, metadata }));
