import hashlib
import json
import math
import os
import pathlib
import selectors
import signal
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
TOOLCHAIN = pathlib.Path('/tmp/agentic-f064a-rust190.zxE80R')
BUN = '/tmp/agentic-direct186.uXVnAg/Agentic Markdown-canary.app/Contents/MacOS/bun'
LOCK_SHA = '639d75f7f400a528fb5879936175f31f51ba6a762e5cee8202f80f73dc00f347'
BINARY = ROOT / 'target/release/f064a-toolchain-check'
LIMIT = 64 * 1024 * 1024

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(65536), b''):
            h.update(block)
    return h.hexdigest()


def group_members(pid):
    ps = subprocess.run(['/bin/ps', '-axo', 'pid,ppid,pgid,command'],
                        capture_output=True, text=True, timeout=10, check=True)
    return [line for line in ps.stdout.splitlines()
            if len(line.split()) >= 3 and line.split()[2] == str(pid)]


ACTIVE = {}


def command(output, label, argv, deadline, environment=None, parse=True, cancel=False):
    ACTIVE.clear()
    try:
        return command_inner(output, label, argv, deadline, environment, parse, cancel)
    except Exception as error:
        cleanup_errors = []
        process = ACTIVE.get('process')
        if process is not None:
            for sig in (signal.SIGTERM, signal.SIGKILL):
                try:
                    os.killpg(process.pid, sig)
                except ProcessLookupError:
                    break
                except Exception as cleanup:
                    cleanup_errors.append(repr(cleanup))
                if sig == signal.SIGTERM:
                    time.sleep(5)
            try:
                process.wait(timeout=10)
            except Exception as cleanup:
                cleanup_errors.append(repr(cleanup))
        for handle in ACTIVE.get('files', {}).values():
            try:
                handle.close()
            except Exception as cleanup:
                cleanup_errors.append(repr(cleanup))
        if 'selector' in ACTIVE:
            ACTIVE['selector'].close()
        members = None
        if process is not None:
            try:
                members = group_members(process.pid)
            except Exception as cleanup:
                cleanup_errors.append(repr(cleanup))
        path = output / (label + '.json')
        prior = json.loads(path.read_bytes()) if path.exists() else {}
        prior.update({'innerFailure': prior.get('failure'), 'outerError': repr(error), 'cleanupErrors': cleanup_errors,
                      'membersAfterCleanup': members, 'pid': None if process is None else process.pid,
                      'partialCounts': ACTIVE.get('counts'), 'partialRSS': ACTIVE.get('samples')})
        path.write_text(json.dumps(prior, indent=2))
        raise
    finally:
        ACTIVE.clear()


def command_inner(output, label, argv, deadline, environment=None, parse=True, cancel=False):
    started = time.monotonic()
    process = subprocess.Popen(argv, cwd=ROOT, env=environment, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, stdin=subprocess.PIPE if cancel else subprocess.DEVNULL,
                               start_new_session=True)
    ACTIVE['process'] = process
    selector = selectors.DefaultSelector()
    files = {}
    counts = {'stdout': 0, 'stderr': 0}
    ACTIVE.update({'files': files, 'selector': selector, 'counts': counts})
    for channel, pipe in [('stdout', process.stdout), ('stderr', process.stderr)]:
        os.set_blocking(pipe.fileno(), False)
        selector.register(pipe, selectors.EVENT_READ, channel)
        files[channel] = (output / (label + '.' + channel)).open('xb')
    samples = []
    ACTIVE['samples'] = samples
    sample_errors = []
    last_sample = 0.0
    finished = False
    failed = None
    term_at = None
    usage = None
    status = None
    first_line = bytearray()
    ready_at = None
    control_buffer = bytearray()
    cancel_sent = None
    cancel_ack = None
    while not finished or selector.get_map():
        tick = time.monotonic()
        if not finished and (tick >= deadline or failed is not None) and term_at is None:
            failed = failed or 'DEADLINE'
            term_at = tick
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        if term_at is not None and tick - term_at > 5 and not finished:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        if not finished and tick - last_sample >= .020:
            sampled_at = time.monotonic()
            try:
                probe = subprocess.run(['/bin/ps', '-o', 'rss=', '-p', str(process.pid)],
                                       capture_output=True, text=True, timeout=2)
                raw = probe.stdout.strip()
            except Exception as error:
                sample_errors.append({'atSeconds': time.monotonic() - started, 'error': repr(error)})
                raw = ''
            if raw.isdigit():
                samples.append({'atSeconds': sampled_at - started, 'rssBytes': int(raw) * 1024})
            last_sample = tick
        for key, _ in selector.select(timeout=.005):
            chunk = os.read(key.fileobj.fileno(), 65536)
            if not chunk:
                selector.unregister(key.fileobj)
                key.fileobj.close()
                continue
            channel = key.data
            if parse and channel == 'stdout' and ready_at is None and len(first_line) < 1048576:
                first_line.extend(chunk)
                if b'\n' in first_line:
                    try:
                        initial = json.loads(first_line.split(b'\n', 1)[0])
                        if initial.get('kind') == 'ready':
                            ready_at = time.monotonic() - started
                    except (ValueError, UnicodeError):
                        failed = 'READY_JSON'
            if cancel and channel == 'stdout':
                control_buffer.extend(chunk)
                if len(control_buffer) > LIMIT:
                    raise ValueError('CONTROL_OUTPUT_LIMIT')
                while b'\n' in control_buffer:
                    line, _, tail = control_buffer.partition(b'\n')
                    control_buffer = bytearray(tail)
                    event = json.loads(line)
                    if event.get('kind') == 'batch-complete':
                        if cancel_sent is not None or event.get('completed') != 1 or event.get('published') != 1:
                            raise ValueError('CANCEL_LATCH')
                        cancel_sent = time.monotonic() - started
                        process.stdin.write(b'CANCEL\n')
                        process.stdin.flush()
                        process.stdin.close()
                    if event.get('kind') == 'cancelled':
                        if cancel_sent is None or cancel_ack is not None:
                            raise ValueError('CANCEL_ACK_ORDER')
                        if event.get('completed') != 1 or event.get('published') != 1:
                            raise ValueError('CANCEL_SEQUENCE')
                        cancel_ack = time.monotonic() - started
            counts[channel] += len(chunk)
            if counts[channel] <= LIMIT:
                files[channel].write(chunk)
            else:
                failed = 'OUTPUT_LIMIT'
        if not finished:
            pid, result_status, result_usage = os.wait4(process.pid, os.WNOHANG)
            if pid:
                finished = True
                status = os.waitstatus_to_exitcode(result_status)
                process.returncode = status
                usage = result_usage
        if finished and selector.get_map() and time.monotonic() > deadline + 15:
            failed = failed or 'PIPE_DRAIN_TIMEOUT'
            for key in list(selector.get_map().values()):
                selector.unregister(key.fileobj)
                key.fileobj.close()
    for handle in files.values():
        handle.close()
    selector.close()
    members = group_members(process.pid)
    if members:
        failed = failed or 'RESIDUAL_GROUP'
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        time.sleep(5)
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        members = group_members(process.pid)
    elapsed = time.monotonic() - started
    baseline = samples[0]['rssBytes'] if samples else None
    peak = max((s['rssBytes'] for s in samples), default=None)
    ready_sample = next((s for s in samples if ready_at is not None
                         and s['atSeconds'] >= ready_at), None)
    ready_peak = max((s['rssBytes'] for s in samples if ready_at is not None
                      and s['atSeconds'] >= ready_at), default=None)
    receipt = {'cancelSentSeconds': cancel_sent, 'cancelAckSeconds': cancel_ack,
               'argv': argv, 'pid': process.pid, 'exit': status, 'failure': failed,
               'elapsedSeconds': elapsed, 'members': members, 'stdoutBytes': counts['stdout'],
               'stderrBytes': counts['stderr'], 'rssSamples': samples,
               'sampleErrors': sample_errors,
               'firstSampleBaselineBytes': baseline, 'samplePeakBytes': peak,
               'readyObservedSeconds': ready_at,
               'readyBaselineBytes': None if ready_sample is None else ready_sample['rssBytes'],
               'readyPeakBytes': ready_peak,
               'readyPeakDeltaBytes': None if ready_sample is None else ready_peak - ready_sample['rssBytes'],
               'samplePeakDeltaBytes': None if peak is None else peak - baseline,
               'maxRSSBytes': None if usage is None else usage.ru_maxrss,
               'maxRSSUnit': 'macOS getrusage ru_maxrss bytes',
               'samplingCaveat': '20ms target; actual intervals recorded; short peaks/start allocations may be missed'}
    rows = []
    if parse and not failed and status == 0 and not members:
        parse_start = time.perf_counter_ns()
        raw = (output / (label + '.stdout')).read_bytes()
        try:
            rows = [json.loads(line) for line in raw.splitlines()]
        except Exception as error:
            failed = 'PARSE_' + type(error).__name__
            receipt['failure'] = failed
        receipt['hostParseNs'] = time.perf_counter_ns() - parse_start
        receipt['hostSpawnToParsedNs'] = int((time.monotonic() - started) * 1e9)
    (output / (label + '.json')).write_text(json.dumps(receipt, indent=2))
    if cancel and (cancel_sent is None or cancel_ack is None):
        failed = 'MISSING_CANCEL_ACK'
        receipt['failure'] = failed
        (output / (label + '.json')).write_text(json.dumps(receipt, indent=2))
    if failed or status != 0 or members or time.monotonic() >= deadline:
        raise RuntimeError('FAILED_' + label)
    return rows
