import assert from 'node:assert/strict';
import {mkdir,readFile,readdir,writeFile,unlink,cp} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {addon,checkedAddon,batch,invoke,query,parse,scalar,validResult} from './protocol.mjs';
import {Client} from './client.mjs';
const [root,caseRoot,which]=process.argv.slice(2);await mkdir(caseRoot,{recursive:false});
const n=addon(root),a='\uFEFF中文\r\n😀x',b='abcXbcd';
const put=(id,raw,path=id)=>({kind:1,id,path,raw});const del=id=>({kind:2,id});
function open(name,mode=0){const h=n.open(Buffer.from(join(caseRoot,name)),mode);assert.equal(typeof h,'object');return h;}
function call(h,op,data){const r=invoke(n,h,op,data);assert.equal(r.code,0);return r;}
function update(h,ops,g){call(h,1,batch(ops));assert.equal(call(h,2).generation,g);}
function hits(h,q,expected){const r=query(n,h,q);assert.equal(r.code,0);assert.deepEqual(parse(r.text).filter(r=>r[0]==='H').map(r=>[r[1],+r[2],+r[3]]),expected);return r;}
async function snapshot(dir){const out={};for(const name of (await readdir(dir)).sort()){const p=join(dir,name);const bytes=await readFile(p);out[name]=[bytes.length,createHash('sha256').update(bytes).digest('hex')];}return out;}
async function collect(){for(let i=0;i<30;i++){Bun.gc(true);await new Promise(r=>setTimeout(r,1));}}
async function basic(h){update(h,[put('a',a,'p'),put('b',b,'q')],1);}

if(which==='1'){
 assert.equal(n.version(),1);const h=open('index');
 let wrongOpen=0;assert.throws(()=>{checkedAddon({version:()=>2,open:()=>{wrongOpen++;}}).open();});assert.equal(wrongOpen,0);
 for(const op of ['commit','query','live','close','cancel'])assert.equal(validResult({code:0},op),false);
 assert.throws(()=>scalar('\ud800'));assert.throws(()=>scalar('\udc00'));assert.equal(scalar('😀𠮷'),'😀𠮷');
 assert.throws(()=>batch([{kind:2,id:'a',raw:'ignored'}]));assert.throws(()=>batch([{kind:'1',id:'a',path:'p',raw:'x'}]));assert.throws(()=>query(n,h,'a'.repeat(4097)));
 let invalid=batch([put('a','x')]);invalid[invalid.length-1]=255;
 assert.equal(invoke(n,h,1,invalid).code,1);
 assert.throws(()=>batch(Array.from({length:17},(_,i)=>put('d'+i,'x'))));const tooMany=Buffer.alloc(4);tooMany.writeUInt32LE(17);assert.equal(invoke(n,h,1,tooMany).code,2);
 const shared=Buffer.alloc(150032);assert.throws(()=>n.call(h,4,Buffer.alloc(0),shared.subarray(0,150000),shared.subarray(149999,150031)));
 assert.throws(()=>n.call(h,NaN,Buffer.alloc(0),Buffer.alloc(150000),Buffer.alloc(32)));
 assert.deepEqual(parse(call(h,4).text),[]);assert.equal(call(h,4).mutations,0);
 update(h,Array.from({length:16},(_,i)=>put('d'+i,'x')),1);
 assert.equal(invoke(n,h,1,batch([put('extra','x')])).code,2);assert.equal(call(h,4).mutations,1);
 assert.equal(n.close(h),0);assert.equal(n.close(h),5);
 const x=open('bytes');update(x,[put('a','a'.repeat(65536))],1);
 assert.equal(invoke(n,x,1,batch([put('b','x')])).code,2);
 update(x,[put('a','x'),put('b','x')],2);const rows=parse(call(x,4).text);assert.deepEqual(rows.map(r=>[r[1],r[3]]),[['a','78'],['b','78']]);assert.equal(n.close(x),0);
}else if(which==='2'){
 const client=new Client(root);assert.equal((await client.send('open',{path:join(caseRoot,'index'),mode:0})).code,0);
 const mutate=async(ops,g)=>{assert.equal((await client.send('batch',ops)).code,0);assert.equal((await client.send('commit')).generation,g);};
 const live=async(want)=>{const r=await client.send('live');assert.equal(r.code,0);assert.deepEqual(parse(r.text),want.map(([id,path,raw])=>['D',id,Buffer.from(path).toString('hex'),Buffer.from(raw).toString('hex')]));};
 const q=async(text,want)=>{const r=await client.send('query',text);assert.equal(r.code,0);assert.deepEqual(parse(r.text).filter(x=>x[0]==='H').map(x=>[x[1],+x[2],+x[3]]),want);return r;};
 await mutate([put('a',a,'p'),put('b',b,'q')],1);await live([['a','p',a],['b','q',b]]);await q('中文',[['a',1,3]]);await q('😀',[['a',5,7]]);
 const falsePositive=await q('abcd',[]);assert.deepEqual(parse(falsePositive.text).map(x=>x[1]),['b']);
 await mutate([put('a','中文新','p')],2);await live([['a','p','中文新'],['b','q',b]]);await q('中文',[['a',0,2]]);await q('😀',[]);
 await mutate([del('a')],3);await live([['b','q',b]]);await q('中文',[]);await mutate([put('c','中文','p')],4);await live([['b','q',b],['c','p','中文']]);await q('中文',[['c',0,2]]);
 const expected=await client.send('live');assert.deepEqual(parse(expected.text).map(x=>x[1]),['b','c']);
 const close=await client.send('close');assert.equal(close.closeSucceeded,true);assert.equal(close.code,0);
 await new Promise(r=>setTimeout(r,10));const before=await snapshot(join(caseRoot,'index'));
 const read=new Client(root,2);assert.equal((await read.send('open',{path:join(caseRoot,'index'),mode:1})).code,0);
 assert.deepEqual(await read.send('live'),{...expected,mutations:0});
 assert.equal((await read.send('query','中文')).generation,4);const readClose=await read.send('close');assert.equal(readClose.code,0);assert.equal(readClose.lastCommit,4);
 assert.deepEqual(await snapshot(join(caseRoot,'index')),before);
}else if(which==='3'){
 const h=open('index');await basic(h);assert.equal(Buffer.byteLength(a),16);
 const r=hits(h,'中文',[['a',1,3]]);const c=parse(r.text).find(x=>x[0]==='C');assert.equal(c[2],Buffer.from(a).toString('hex'));assert.equal(r.generation,1);
 const tooSmall=invoke(n,h,1,batch([put('c','no')]),8);assert.equal(tooSmall.code,2);assert.equal(tooSmall.length,150000);assert.equal(call(h,4).mutations,1);
 hits(h,'😀',[['a',5,7]]);assert.equal(n.close(h),0);
}else if(which==='4'){
 // Pure receiver seam: malformed same-id success cannot publish or hang a pending task.
 const receiver=Object.create(Client.prototype);let rejected;
 Object.assign(receiver,{epoch:1,active:{id:1,op:'query',resolve:r=>{rejected=r;}},latest:null,published:0,closed:false});
 receiver.receive({version:1,id:1,epoch:1,result:{code:0}});assert.equal(receiver.published,0);assert.equal(rejected.code,'INVALID_RESPONSE');assert.equal(receiver.active,null);
 // Host admission is tested with explicit worker latch, not native interruption.
 const client=new Client(root);await client.send('open',{path:join(caseRoot,'worker'),mode:0});
 const waiting=client.send('hold');assert.equal((await client.send('batch',[put('lost','x')])).code,'BUSY');
 const oldQuery=client.send('query','old'),latest=client.send('query','new');assert.equal((await oldQuery).code,'CANCELLED');
 const published=client.published;client.receive({version:1,epoch:999,id:client.active.id,result:{code:0}});assert.equal(client.published,published);
 client.discardQueries();assert.equal((await latest).code,'CANCELLED');client.releaseHold();await waiting;
 assert.equal((await client.send('batch',[put('a','中文')])).code,0);assert.equal((await client.send('commit')).generation,1);
 // Actual cancel message/ACK after commit1, not an interruption of synchronous native.
 const sent=performance.now();const closed=await client.cancel();const ack=performance.now();assert.equal(closed.closeSucceeded,true);assert.equal(closed.lastCommit,1);
 assert.equal((await client.send('batch',[put('never','x')])).code,'CLOSED');
 assert.equal(client.sent.filter(x=>x.op==='batch').length,1);assert.equal(client.lastPublishedCommit,1);
 console.log(JSON.stringify({cancel:{sent,ack,lastCompleted:closed.lastCommit,lastPublished:client.lastPublishedCommit,batchDispatches:client.sent.filter(x=>x.op==='batch').length,mode:'between-calls'}}));
 assert.throws(()=>n.call({},4,Buffer.alloc(0),Buffer.alloc(150000),Buffer.alloc(32)));
 n.audit(Buffer.from(join(caseRoot,'lifecycle.audit')));
 let h=open('gc-first');n.close(h);h=null;await collect();assert.equal(n.stats().allocated,1);assert.equal(n.stats().freed,1);
 let second=open('cleanup-first');assert.equal(n.cleanupForTest(),0);assert.equal(n.stats().closed,2);second=null;await collect();assert.equal(n.stats().freed,2);
 // cleanupForTest invokes the same hook body; explicitly synthetic ordering, not OS crash evidence.
}else if(which==='5'){
 const h=open('index');await basic(h);assert.equal(n.close(h),0);
 for(const kind of ['future','corrupt','missing-lock']){
  const dest=join(caseRoot,kind);await cp(join(caseRoot,'index'),dest,{recursive:true,errorOnExist:true});
  if(kind==='missing-lock')await unlink(join(dest,'.tantivy-meta.lock'));
  else await writeFile(join(dest,'bridge.schema'),kind==='future'?'bridge=1\nschema=2\n':'bad');
  const before=await snapshot(dest);assert.equal(n.open(Buffer.from(dest),1),4);assert.deepEqual(await snapshot(dest),before);
 }
 assert.throws(()=>addon(join(caseRoot,'missing-resource')));
}else if(which==='6'){
 const h=open('pre');const r=invoke(n,h,90);assert.equal(r.code,8);assert.equal(r.mutations,0);assert.equal(r.poison,true);assert.equal(invoke(n,h,4).code,6);assert.equal(n.close(h),0);
 const p=open('post');call(p,1,batch([put('a',a,'p')]));const after=invoke(n,p,91);assert.equal(after.code,8);assert.equal(after.generation,1);assert.equal(after.mutations,1);assert.equal(after.poison,true);
 assert.equal(n.close(p),0);const before=await snapshot(join(caseRoot,'post'));const read=open('post',1);hits(read,'中文',[['a',1,3]]);assert.equal(call(read,4).generation,1);assert.equal(n.close(read),0);assert.deepEqual(await snapshot(join(caseRoot,'post')),before);
 // Real worker commits then substitutes unknown for the receipt; host never retries.
 const lost=new Client(root);await lost.send('open',{path:join(caseRoot,'lost'),mode:0});assert.equal((await lost.send('batch',[put('a','中文')])).code,0);
 assert.deepEqual(await lost.send('commitLost'),{code:'BRIDGE_ERROR',unknown:true});assert.equal(lost.sent.filter(x=>x.op==='batch').length,1);assert.equal(lost.sent.filter(x=>x.op==='commitLost').length,1);
 assert.equal((await lost.send('close')).code,0);const verified=open('lost',1);assert.equal(call(verified,4).generation,1);hits(verified,'中文',[['a',0,2]]);assert.equal(n.close(verified),0);
}else throw Error('CASE');
console.log(JSON.stringify({case:which,status:'complete',injected:which==='6'||which==='4'}));
