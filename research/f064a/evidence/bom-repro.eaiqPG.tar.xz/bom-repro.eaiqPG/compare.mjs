import { Database } from 'bun:sqlite';
import { strict as assert } from 'node:assert';
const mode = process.argv[2];
if (!['parameter-text', 'literal-text', 'parameter-blob'].includes(mode)) throw Error('MODE');
const input = Uint8Array.from([0xef, 0xbb, 0xbf, 0xe4, 0xb8, 0xad]);
const decoder = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true });
const db = new Database(':memory:');
db.exec(mode === 'parameter-blob' ? 'create table t(raw blob)' : 'create table t(raw text)');
if (mode === 'parameter-text') db.query('insert into t values(?)').run(decoder.decode(input));
else if (mode === 'literal-text') db.exec("insert into t values(cast(X'efbbbfe4b8ad' as text))");
else db.query('insert into t values(?)').run(input);
const sql = db.query('select hex(raw) as bytes, length(raw) as length, typeof(raw) as type from t').get();
const returned = db.query('select raw from t').get().raw;
const result = { mode, input: Buffer.from(input).toString('hex'), sql,
  returnedType: returned.constructor.name, returnedHex: Buffer.from(returned).toString('hex') };
if (mode === 'parameter-blob') {
  const text = decoder.decode(returned);
  result.span = [text.indexOf('中'), text.indexOf('中') + 1];
  result.decodedHex = Buffer.from(text).toString('hex');
  console.log(JSON.stringify(result));
  assert.equal(sql.type, 'blob');
  assert.equal(sql.bytes.toLowerCase(), result.input);
  assert.equal(result.returnedHex, result.input);
  assert.equal(result.decodedHex, result.input);
  assert.deepEqual(result.span, [1, 2]);
} else console.log(JSON.stringify(result));
