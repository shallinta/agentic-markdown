# Candidate source preparation — not executed

SQLite candidate: same index/query grammar and raw verification, Statement.iterate,
no SQL payload ORDER BY, sort lightweight candidates/hits by ID, reject duplicates.
No per-document profiling clocks. This is not a repeat/pass of the original 200-sample run.

## Source provenance

- literal: `/tmp/agentic-f064a-literal-blob.pf89ql`
- crud: `/tmp/agentic-f064a-crud-rw.h2jpT5`
- real: `/tmp/agentic-f064a-corpus-cost.hrCQVN`
- scale: `/tmp/agentic-f064a-scale-typed.Xx6GxU`
- scale/processes.py: `/tmp/agentic-f064a-order.DwUfIx/processes.py` (preserves inner/outer errors)

Only SQLite readers and runners differ for literal/CRUD. Their Rust, fixtures,
common helpers, manifest, Cargo.toml and lock are unchanged. Real Rust removes
warm/timed scheduling only. Scale Rust adds required `correctness|finite20`
argument and selects no warm/timed or 10 warm + 20 timed; its index/query logic is unchanged.
Each suite keeps its own budget. Scale payloads are not regenerated/copied.

## Explicit commands after separate execution approval

Execute serially and stop on first nonzero status. No automatic retry or fallback.
Each compile is separately bounded to 600 seconds, own target, same Rust toolchain/lock.

```sh
set -e
cd /tmp/agentic-f064a-candidate.TURSqj
node literal/run.mjs compile
node literal/run.mjs diagnose
node crud/run.mjs compile
node crud/run.mjs diagnose
python3 real/run.py compile
python3 real/run.py correctness
python3 scale/run.py compile
python3 scale/run.py correctness /tmp/agentic-f064a-scale.1Kfm4c/run-1792332750009771000/receipt.json 2822c8814f93dcef772f43a2afc36b3f2209caab4f9c81905b3b6ab8c0494da5
```

L: original 50 engine cases + pure admission, 15s/case and 180s batch.
CRUD: original 14 engine/stage cases, 15s/stage and 180s batch; P2/P7 source fixture path remains a nonexistent sentinel.
Real: original 36 files and 12 queries, build and independent reopen, no warm/timed;
120s per engine including build+reopen, 300s total.
Scale correctness: 100/1000/10000, both engines each fresh index, build + baseline
readonly query + six original mutations + actual CANCEL handshake; 120s per engine,
900s per scale. No warm/timed. Original full live IDs, stage queries and all markers
remain. Source/binary chain required. Result receipts are separate from performance.

Only after all correctness batches pass and main separately approves cost:

```sh
python3 /tmp/agentic-f064a-candidate.TURSqj/scale/run.py finite20 /tmp/agentic-f064a-scale.1Kfm4c/run-1792332750009771000/receipt.json 2822c8814f93dcef772f43a2afc36b3f2209caab4f9c81905b3b6ab8c0494da5
```

Only N=10000, fresh indexes, AB/BA/AB, build + independent query process,
12 first + each 10 warm/20 timed. 120s engine round/900s batch; first failure stops.
No incremental/cancel actions in cost mode. All per-query semantic work and
serialization remain; p99 of 20 samples is not a reliable tail estimate.
Old full-200 timeout is retained and cannot be relabelled as passed.
