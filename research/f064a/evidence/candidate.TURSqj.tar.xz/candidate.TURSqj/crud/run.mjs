import { spawn, spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, statSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { strict as assert } from 'node:assert';
import { validateScalarString } from './common.mjs';

const root = new URL('.', import.meta.url).pathname.replace(/\/$/, '');
const tool = '/tmp/agentic-f064a-rust190.zxE80R';
const bun = '/tmp/agentic-direct186.uXVnAg/Agentic Markdown-canary.app/Contents/MacOS/bun';
const manifestHash = 'b7ba553b117641daca12240eb1e540cd0f13694cad615fcc71cc7da36d5d0139';
const lockHash = '639d75f7f400a528fb5879936175f31f51ba6a762e5cee8202f80f73dc00f347';
const bunHash = '539598c775882420b9d8deb7dc14d845f20f7d26f5600c50ab067dde6ac3f3bf';
const sha = path => createHash('sha256').update(readFileSync(path)).digest('hex');
const decode = bytes => new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(bytes);
const manifest = JSON.parse(readFileSync(root + '/manifest.json', 'utf8'));
const fixture = name => validateScalarString(decode(readFileSync(root + '/fixtures/' + name)));

function verify() {
  assert.equal(sha(root + '/manifest.json'), manifestHash);
  assert.equal(sha(root + '/Cargo.lock'), lockHash);
  assert.equal(sha(bun), bunHash);
  assert.equal(manifest.files.length, 4);
  for (const file of manifest.files) {
    const path = root + '/fixtures/' + file.name;
    assert.ok(file.bytes <= 1024);
    assert.equal(statSync(path).size, file.bytes);
    assert.equal(sha(path), file.sha256);
    assert.equal(readFileSync(path).length, file.bytes);
    fixture(file.name);
  }
}

const mode = process.argv[2];
if (!['compile', 'diagnose'].includes(mode)) throw Error('EXPLICIT_MODE_REQUIRED');
verify();
const output = root + '/run-' + Date.now();
mkdirSync(output);
const sourceNames = ['Cargo.toml', 'Cargo.lock', 'common.mjs', 'manifest.json', 'sqlite.mjs', 'run.mjs', 'src/main.rs'];
const sourceHashes = () => Object.fromEntries(sourceNames.map(name => [name, sha(root + '/' + name)]));
const sources = sourceHashes();
writeFileSync(output + '/sources.json', JSON.stringify(sources, null, 2));
const env = {
  ...process.env,
  RUSTC: tool + '/prefix/bin/rustc',
  RUSTDOC: tool + '/prefix/bin/rustdoc',
  CARGO_HOME: tool + '/cargo-home',
  CARGO_TARGET_DIR: root + '/target',
  CARGO_HTTP_TIMEOUT: '30',
  CARGO_NET_RETRY: '2',
  PATH: tool + '/prefix/bin:/usr/bin:/bin:/usr/sbin:/sbin',
};
let activeStop;
let batchExpired = false;
let deadline = Infinity;
let batchTimer;

async function command(label, executable, args, limit) {
  const started = Date.now();
  const child = spawn(executable, args, { cwd: root, env, detached: true, stdio: ['ignore', 'pipe', 'pipe'] });
  const stdout = [], stderr = [];
  let bytes = 0, error, expired = false, killTimer;
  const kill = signal => {
    try { process.kill(-child.pid, signal); }
    catch (e) { if (e.code !== 'ESRCH') error = String(e); }
  };
  const stop = () => {
    expired = true;
    kill('SIGTERM');
    if (!killTimer) killTimer = setTimeout(() => kill('SIGKILL'), 5000);
  };
  activeStop = stop;
  for (const [stream, chunks] of [[child.stdout, stdout], [child.stderr, stderr]]) {
    stream.on('data', chunk => {
      bytes += chunk.length;
      if (bytes > 1048576) { error = 'OUTPUT_LIMIT'; stop(); return; }
      chunks.push(chunk);
    });
  }
  child.on('error', e => { error = String(e); });
  const timer = setTimeout(stop, limit);
  const [status, signal] = await new Promise(resolve => child.on('close', (s, sig) => resolve([s, sig])));
  clearTimeout(timer);
  if (killTimer) {
    await new Promise(resolve => setTimeout(resolve, 5100));
    clearTimeout(killTimer);
  }
  activeStop = undefined;
  const ps = spawnSync('/bin/ps', ['-axo', 'pid,ppid,pgid,command'], { encoding: 'utf8', timeout: 10000 });
  const members = (ps.stdout ?? '').split('\n').filter(line => line.trim().split(/\s+/)[2] === String(child.pid));
  const out = Buffer.concat(stdout), err = Buffer.concat(stderr);
  writeFileSync(output + '/' + label + '.stdout', out);
  writeFileSync(output + '/' + label + '.stderr', err);
  const receipt = { label, executable, args, started, elapsedMs: Date.now() - started,
    status, signal, error, expired, pid: child.pid, groupMembersAfter: members, psStatus: ps.status };
  writeFileSync(output + '/' + label + '.json', JSON.stringify(receipt, null, 2));
  if (status !== 0 || expired || error || members.length || ps.status !== 0 || batchExpired || Date.now() >= deadline) {
    throw Error('CASE_FAILED ' + label);
  }
  return decode(out);
}

function integer(text) {
  if (!/^\d+$/.test(text) || !Number.isSafeInteger(Number(text))) throw Error('INTEGER');
  return Number(text);
}

function rustResult(text) {
  const result = { live: [], queries: manifest.queries.map(() => ({ candidates: [], hits: [] })) };
  let terminal = false;
  const unhex = text => {
    assert.match(text, /^(?:[0-9a-f]{2})*$/);
    return decode(Buffer.from(text, 'hex'));
  };
  for (const line of text.trimEnd().split('\n')) {
    const p = line.split('\t');
    if (terminal) throw Error('AFTER_TERMINAL');
    if (p[0] === 'D' && p.length === 4) result.live.push([p[1], unhex(p[2]), p[3]]);
    else if (p[0] === 'C' && p.length === 4) result.queries[integer(p[1])].candidates.push([p[2], p[3]]);
    else if (p[0] === 'H' && p.length === 5) result.queries[integer(p[1])].hits.push([p[2], integer(p[3]), integer(p[4])]);
    else if (p[0] === 'S' && p.length === 3) {
      result.stage = integer(p[1]);
      assert.ok(['readonly', 'committed'].includes(p[2]));
      result.readonly = p[2] === 'readonly';
      terminal = true;
    } else throw Error('TSV_RECORD');
  }
  if (!terminal) throw Error('MISSING_TERMINAL');
  return result;
}

function validateResult(result, expected) {
  assert.equal(result.stage, expected.stage);
  assert.equal(result.readonly, expected.action === 'readonly-reopen');
  const live = expected.live.map(([id, path, file]) => [id, path, readFileSync(root + '/fixtures/' + file).toString('hex')]);
  assert.deepEqual(result.live, live);
  assert.equal(result.queries.length, 5);
  result.queries.forEach((query, index) => {
    assert.deepEqual(query.hits, expected.hits[index]);
    const candidateIds = expected.hits[index].map(hit => hit[0]);
    assert.deepEqual(query.candidates.map(row => row[0]), candidateIds);
    for (const [id, bytes] of query.candidates) assert.equal(bytes, live.find(row => row[0] === id)?.[2]);
    for (const [id, start, end] of query.hits) {
      const file = expected.live.find(row => row[0] === id)?.[2];
      assert.equal(fixture(file).slice(start, end), manifest.queries[index]);
    }
  });
}

try {
  if (mode === 'compile') {
    await command('compile', tool + '/prefix/bin/cargo', ['build', '--release', '--locked'], 600000);
  } else {
    const compiled = readdirSync(root).filter(name => name.startsWith('run-')).flatMap(name => {
      try { return [JSON.parse(readFileSync(root + '/' + name + '/receipt.json'))]; } catch { return []; }
    });
    assert.ok(compiled.some(r => r.mode === 'compile' && r.status === 'complete'
      && JSON.stringify(r.sources) === JSON.stringify(sources)
      && r.binarySHA === sha(root + '/target/release/f064a-toolchain-check')), 'COMPILE_CHAIN');
    deadline = Date.now() + 180000;
    batchTimer = setTimeout(() => { batchExpired = true; activeStop?.(); }, 180000);
    const results = [];
    for (const expected of manifest.stages) {
      let previous;
      for (const engine of ['sqlite', 'tantivy']) {
        verify();
        const remaining = deadline - Date.now();
        if (remaining <= 0) throw Error('BATCH_DEADLINE');
        const executable = engine === 'sqlite' ? bun : root + '/target/release/f064a-toolchain-check';
        const database = output + (engine === 'sqlite' ? '/index.sqlite' : '/tantivy-index');
        // Reopen-only processes receive no usable fixture path: stored results cannot be reimported.
        const inputs = expected.action === 'readonly-reopen' ? output + '/no-fixtures' : root + '/fixtures';
        const args = [database, inputs, String(expected.stage)];
        if (engine === 'sqlite') args.unshift(root + '/sqlite.mjs');
        const raw = await command(engine + '-P' + expected.stage, executable, args, Math.min(15000, remaining));
        const result = engine === 'sqlite' ? JSON.parse(raw) : rustResult(raw);
        validateResult(result, expected);
        const comparable = { stage: result.stage, readonly: result.readonly, live: result.live, queries: result.queries };
        if (previous) assert.deepEqual(comparable, previous);
        previous = comparable;
        verify();
        if (batchExpired || Date.now() >= deadline) throw Error('BATCH_DEADLINE');
        results.push({ engine, stage: expected.stage, ...result });
        writeFileSync(output + '/results.json', JSON.stringify(results, null, 2));
      }
    }
    assert.equal(results.length, manifest.cases);
  }
  verify();
  assert.deepEqual(sourceHashes(), sources);
  if (batchExpired || Date.now() >= deadline) throw Error('BATCH_DEADLINE');
  writeFileSync(output + '/receipt.json', JSON.stringify({ mode, status: 'complete', output, manifestHash, lockHash, sources, binarySHA: sha(root + '/target/release/f064a-toolchain-check') }, null, 2));
  console.log(output);
} catch (error) {
  writeFileSync(output + '/receipt.json', JSON.stringify({ mode, status: 'failed', output, sources, error: String(error) }, null, 2));
  console.error(error);
  process.exitCode = 1;
} finally {
  clearTimeout(batchTimer);
}
