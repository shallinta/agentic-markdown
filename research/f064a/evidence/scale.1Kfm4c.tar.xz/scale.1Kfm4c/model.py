"""Frozen synthetic inputs and independent scalar oracle; no work on import."""
import hashlib
import json
import pathlib
import re

SIZES = (100, 1000, 10000)
MIB = 1024 * 1024
LIMIT = 512 * MIB
P = '# 中文检索\n\nAttributes attributes <script setup>\n😀 e\u0301 内 应用 无障碍\nMarkdown mixed text.\n'
LONG = ''.join(chr(i) for i in range(0x100, 0x183))
QUERIES = ['内', '应用', '无障碍', 'Attributes', 'attributes', '<script setup>',
           '\n\n', '😀', 'e\u0301', 'F064A_ABSENT_7d4e1c9b_不存在_𠮷', ' ', LONG]
TOKEN_LIMIT = 1374
TOKEN_BYTES = 30227


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def units(text):
    return sum(2 if ord(c) > 0xffff else 1 for c in text)


def validate(query):
    if any(0xd800 <= ord(c) <= 0xdfff for c in query):
        raise ValueError('SURROGATE')
    if units(query) > 4096:
        raise ValueError('QUERY_LIMIT')


def first(text, query):
    """Independent per-start, per-scalar comparison; not find/gram retrieval."""
    validate(query)
    if not query:
        return None
    start_units = 0
    for start in range(len(text)):
        equal = start + len(query) <= len(text)
        if equal:
            for offset in range(len(query)):
                if text[start + offset] != query[offset]:
                    equal = False
                    break
        if equal:
            return [start_units, start_units + units(query)]
        start_units += 2 if ord(text[start]) > 0xffff else 1
    return None


def reservation(n):
    assert n in SIZES, 'SCALE'
    k = (n + 99) // 100
    raw = (n - 2) * 4096 + 2 * MIB + (k + 1) * 4096
    cost = (4 * raw + 8 * MIB + 512 * TOKEN_LIMIT + 4 * TOKEN_BYTES
            + 128 * TOKEN_LIMIT * 32 + TOKEN_BYTES * 32 + 4 * MIB
            + 1024 * 32 + 50 * MIB + 32 * MIB + 64 * MIB)
    assert raw <= 64 * MIB and n + k + 1 <= 10101 and cost <= LIMIT, 'BUDGET'
    return {'logicalBytes': cost, 'rawUpperBytes': raw, 'liveUpper': n + k + 1}


def header(doc_id, revision, life):
    assert re.fullmatch('[SAB][0-9]{6}', doc_id), 'ID'
    assert revision in (0, 1, 2) and life in ('base', 'add'), 'VERSION'
    result = f'id={doc_id};rev={revision};life={life}\n'
    assert result.isascii() and len(result) <= 64
    return result


def payload(doc_id, revision, life, size):
    assert size in (4096, MIB), 'SIZE'
    assert QUERIES[6].encode().hex() == '0a0a' and units(QUERIES[6]) == 2
    assert QUERIES[8].encode().hex() == '65cc81' and len(QUERIES[8]) == 2
    assert len(P) <= 256 and len('\n' + LONG + '\n') == 133
    h = header(doc_id, revision, life)
    prefix = (h + '\n' + LONG + '\n').encode('utf-8')
    period = P.encode('utf-8')
    count, padding = divmod(size - len(prefix), len(period))
    assert count >= 1 and 0 <= padding < len(period), 'TEMPLATE_STRUCTURE'
    raw = prefix + period * count + b' ' * padding
    assert len(raw) == size and raw.decode('utf-8').encode('utf-8') == raw
    return raw


def gram_stats(text):
    # Full input scan, no truncation or measuring a prefix and extrapolating.
    tokens = set()
    for length in (1, 2, 3):
        for start in range(len(text) - length + 1):
            token = f'g{length}x' + ''.join(f'{ord(c):06x}' for c in text[start:start + length])
            tokens.add(token)
            assert len(tokens) <= TOKEN_LIMIT, 'DISTINCT_BOUND'
    encoded = sum(len(t) for t in tokens) + max(0, len(tokens) - 1)
    assert encoded <= TOKEN_BYTES, 'TOKEN_BYTES'
    return len(tokens), encoded


def selftest(frozen):
    root = pathlib.Path(frozen['literalDirectory'])
    files = {e['name']: e for e in frozen['literal']['files']}
    def read(name):
        item = files[name]
        path = root / name
        assert path.stat().st_size == item['bytes']
        raw = path.read_bytes()
        assert sha(raw) == item['sha256']
        return raw.decode('utf-8', 'strict')
    for case in frozen['literal']['cases']:
        q = read(case['queryFile'])
        hits = []
        for doc in frozen['literal']['groups'][case['group']]:
            span = first(read(doc + '.txt'), q)
            if span is not None:
                hits.append([doc, *span])
        assert hits == case['hits'], ('L_ORACLE', case['index'])
    assert len(frozen['literal']['cases']) == 25
    for bad in ('\ud800', '\udc00', 'a' * 4097):
        try:
            validate(bad)
        except ValueError:
            continue
        raise AssertionError('ADMISSION')
    assert first('😀𠮷', '𠮷') == [2, 4]


def write_json(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=True, indent=2)
        stream.write('\n')
