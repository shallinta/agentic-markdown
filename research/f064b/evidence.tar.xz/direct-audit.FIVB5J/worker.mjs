import {addon,batch,invoke,query,wire} from '/tmp/agentic-f064b-bridge.w0G13h/protocol.mjs';
// Only this Worker calls synchronous native. No native callback into JavaScript.
const native=addon('/tmp/agentic-f064b-bridge.w0G13h');let handle,epoch,held,lastId=0,lastCommit=0;
function reply(m,result){postMessage({version:1,id:m.id,epoch:m.epoch,result});}
function action(m){
 if(m.op==='open'){
  if(handle||epoch!==undefined||!m.payload||Object.keys(m.payload).sort().join(',')!=='mode,path'||typeof m.payload.path!=='string'||![0,1].includes(m.payload.mode))throw Error('OPEN');
  native.audit(Buffer.from(m.payload.path+'.audit'));
  epoch=m.epoch;handle=native.open(Buffer.from(m.payload.path),m.payload.mode);
  if(typeof handle==='number'){const code=handle;handle=undefined;reply(m,{code});return;}
  const initial=invoke(native,handle,4);if(initial.code!==0){const h=handle;handle=undefined;native.close(h);throw Error('OPEN_METADATA');}
  lastCommit=initial.generation;
  reply(m,{code:0,abi:native.version()});return;
 }
 if(m.epoch!==epoch||!handle)throw Error('SESSION');
 if(m.op==='batch')reply(m,invoke(native,handle,1,batch(m.payload)));
 else if(m.op==='commit'||m.op==='commitLost'){if(m.payload!==null)throw Error('PAYLOAD');const r=invoke(native,handle,2);lastCommit=r.generation;if(m.op==='commitLost')throw Error('INJECTED_REPLY_FAILURE');reply(m,r);}
 else if(m.op==='query')reply(m,query(native,handle,m.payload));
 else if(m.op==='live'){if(m.payload!==null)throw Error('PAYLOAD');reply(m,invoke(native,handle,4));}
 else if(m.op==='close'||m.op==='cancel'){if(m.payload!==null)throw Error('PAYLOAD');const h=handle;handle=undefined;
  const code=native.close(h);reply(m,{code,closed:true,closeSucceeded:code===0,lastCommit});close();}
 else throw Error('OP');
}
self.onmessage=event=>{
 const m=event.data;if(!wire(m)||m.id<=lastId){postMessage({invalid:true});return;}lastId=m.id;
 try{
  // Explicit test latch before a batch: not interruption of an executing native call.
  if(m.op==='hold'){if(held||!handle||m.epoch!==epoch||m.payload!==null)throw Error('HOLD');held=m;postMessage({held:true,id:m.id,epoch});return;}
  if(m.op==='release'){if(!held||m.epoch!==epoch||m.payload!==null)throw Error('RELEASE');const old=held;held=undefined;reply(old,{code:0});return;}
  if(held)throw Error('HELD');action(m);
 }catch{reply(m,{code:'BRIDGE_ERROR',unknown:['batch','commit','commitLost','close','cancel'].includes(m.op)});}
};
