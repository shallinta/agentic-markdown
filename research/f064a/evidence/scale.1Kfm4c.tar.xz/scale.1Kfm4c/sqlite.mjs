import { Database } from 'bun:sqlite';
import { createHash } from 'node:crypto';
import { readFileSync, statSync, existsSync, mkdirSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { createInterface } from 'node:readline';

const [mode, directory, corpus, stageName, completeSHA] = process.argv.slice(2);
if (!['build', 'query', 'update', 'add', 'delete', 'cancel'].includes(mode)) throw Error('MODE');
const hash = raw => createHash('sha256').update(raw).digest('hex');
const now = () => process.hrtime.bigint();
const ns = start => Number(now() - start);
const completeBytes = readFileSync(join(corpus, 'complete.json'));
if (hash(completeBytes) !== completeSHA) throw Error('COMPLETE_SHA');
const complete = JSON.parse(completeBytes);
const pin = complete.stages.find(s => s.name === stageName);
if (!complete.complete || !pin || ![100, 1000, 10000].includes(complete.n)) throw Error('MANIFEST');
const stageBytes = readFileSync(join(corpus, stageName, 'manifest.json'));
if (hash(stageBytes) !== pin.pins['manifest.json']) throw Error('STAGE_SHA');
const stage = JSON.parse(stageBytes);
const MODEL = complete.budget.logicalBytes;
if (MODEL > 512 * 1024 * 1024 || MODEL > 346977964) throw Error('MODEL');
const docs = new Map(stage.documents.map(d => [d.id, d]));
if (docs.size !== stage.documents.length || docs.size > complete.budget.liveUpper) throw Error('LIVE_BOUND');
const decode = raw => new TextDecoder('utf-8', {fatal: true, ignoreBOM: true}).decode(raw);
function grams(text, query = false) {
  if (query && text.length > 4096) throw Error('QUERY_LIMIT');
  if (/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/u.test(text)) throw Error('SURROGATE');
  const chars = Array.from(text), values = new Set();
  for (const length of query ? [Math.min(3, chars.length)] : [1, 2, 3]) {
    if (!length) continue;
    for (let i = 0; i + length <= chars.length; i++) {
      const token = 'g' + length + 'x' + chars.slice(i, i + length)
        .map(c => c.codePointAt(0).toString(16).padStart(6, '0')).join('');
      values.add(token);
      if (values.size > (query ? 4096 : 1374)) throw Error('DISTINCT_BOUND');
    }
  }
  const tokens = [...values].sort();
  if (!query && tokens.reduce((n, t) => n + t.length, 0) + tokens.length - 1 > 30227) throw Error('TOKEN_BYTES');
  return tokens;
}
function checked(id, raw) {
  const doc = docs.get(id);
  if (!doc || ![4096, 1048576].includes(doc.bytes) || !(raw instanceof Uint8Array)) throw Error('RAW_TYPE');
  if (raw.byteLength !== doc.bytes || hash(raw) !== doc.sha256) throw Error('RAW_IDENTITY');
  const text = decode(raw);
  if (!Buffer.from(text).equals(Buffer.from(raw))) throw Error('ROUNDTRIP');
  return text;
}
let outputBytes = 0;
function emit(value) {
  const line = JSON.stringify(value) + '\n';
  outputBytes += Buffer.byteLength(line);
  if (outputBytes > 64 * 1024 * 1024) throw Error('OUTPUT_LIMIT');
  process.stdout.write(line);
}
function disk() {
  let bytes = 0, files = 0;
  for (const name of readdirSync(directory)) {
    const item = statSync(join(directory, name));
    if (!item.isFile()) throw Error('INDEX_NONFILE');
    bytes += item.size; files++;
  }
  return {bytes, files};
}
const readonly = mode === 'query' || mode === 'cancel';
if (mode === 'build' ? existsSync(directory) : !existsSync(directory)) throw Error('INDEX_EXISTENCE');
if (mode === 'build') mkdirSync(directory);
const openStart = now();
const db = new Database(join(directory, 'index.db'), {readonly, readwrite: !readonly, create: mode === 'build'});
db.exec('pragma cache_size=-16384; pragma synchronous=FULL');
if (!readonly) db.exec('pragma journal_mode=WAL; pragma wal_autocheckpoint=1000');
const pragmas = Object.fromEntries(['cache_size', 'synchronous', 'journal_mode', 'wal_autocheckpoint']
  .map(k => [k, db.query('pragma ' + k).get()]));
if (Object.values(pragmas.cache_size)[0] !== -16384 || Object.values(pragmas.synchronous)[0] !== 2
    || Object.values(pragmas.journal_mode)[0] !== 'wal') throw Error('PRAGMA');
if (mode === 'build') db.exec("create table originals(id text unique not null,path text not null,raw blob not null);create virtual table gram_index using fts5(tokens,tokenize='ascii');pragma user_version=1");
if (db.query('pragma user_version').get().user_version !== 1) throw Error('SCHEMA');
if (JSON.stringify(db.query('pragma table_info(originals)').all().map(v => [v.name, v.type.toLowerCase()]))
    !== JSON.stringify([['id', 'text'], ['path', 'text'], ['raw', 'blob']])) throw Error('SCHEMA');
if (!db.query("select sql from sqlite_master where name='gram_index'").get()?.sql.includes("fts5(tokens,tokenize='ascii')")) throw Error('FTS_SCHEMA');
emit({kind: 'ready', mode, openNs: ns(openStart), pragmas, modelBytes: MODEL,
  sqlite: db.query('select sqlite_version() v').get().v, options: db.query('pragma compile_options').all()});

function search(query) {
  const start = now(), tokens = grams(query.text, true);
  const rows = tokens.length > 128
    ? db.query('select id,raw from originals order by id').all()
    : db.query('select originals.id,originals.raw from gram_index join originals on originals.rowid=gram_index.rowid where gram_index match ? order by originals.id').all(tokens.join(' AND '));
  if (rows.length > complete.budget.liveUpper) throw Error('CANDIDATE_COUNT');
  let candidateBytes = 0;
  const candidates = [], hits = [];
  for (const row of rows) {
    const text = checked(row.id, row.raw);
    candidateBytes += row.raw.byteLength;
    if (candidateBytes > complete.budget.rawUpperBytes) throw Error('CANDIDATE_BYTES');
    candidates.push([row.id, docs.get(row.id).sha256]);
    const pos = text.indexOf(query.text);
    if (pos >= 0) hits.push([row.id, pos, pos + query.text.length]);
  }
  const queryNs = ns(start);
  if (JSON.stringify(hits) !== JSON.stringify(query.hits)) throw Error('ORACLE_' + query.slot);
  return {slot: query.slot, candidates, candidateBytes, hits, mode: tokens.length > 128 ? 'scan-fallback' : 'index', queryNs};
}
const digests = new Map();
function queryOutput(query, phase, repeat) {
  const result = search(query);
  const {queryNs, ...semantic} = result;
  const start = now(), encoded = JSON.stringify(semantic), serializeNs = ns(start);
  const digest = hash(encoded), previous = digests.get(query.slot);
  if (previous && previous !== digest) throw Error('REPEAT_SEMANTICS');
  digests.set(query.slot, digest);
  // Full semantic serialization is done on every call; only first output transfers it.
  emit({kind: 'query', phase, repeat, slot: query.slot, queryNs, serializeNs,
    fullBytes: Buffer.byteLength(encoded), digest, candidateCount: result.candidates.length,
    hitCount: result.hits.length, ...(phase === 'first' || phase === 'commit-check' ? {semantic} : {})});
}
function verifyLive() {
  const actual = db.query('select id from originals order by id').all().map(r => r.id);
  if (JSON.stringify(actual) !== JSON.stringify([...docs.keys()].sort())) throw Error('LIVE_IDS');
}
if (!readonly) {
  const diskBefore = disk();
  const start = now(), batches = [];
  let batch = [];
  for (const doc of stage.changed) {
    if (doc.bytes === 1048576) {
      if (batch.length) batches.push(batch);
      batches.push([doc]); batch = [];
    } else {
      batch.push(doc);
      if (batch.length === 32) { batches.push(batch); batch = []; }
    }
  }
  if (batch.length) batches.push(batch);
  if (!batches.length) batches.push([]);
  let batchNumber = 0;
  const expectedLive = new Set(mode === 'build' ? [] : docs.keys());
  if (mode === 'add') for (const doc of stage.changed) expectedLive.delete(doc.id);
  if (mode === 'delete') for (const id of stage.deleted) expectedLive.add(id);
  const batchVisible = items => {
    const ids = db.query('select id from originals order by id').all().map(row => row.id);
    if (JSON.stringify(ids) !== JSON.stringify([...expectedLive].sort())) throw Error('BATCH_LIVE_IDS');
    for (const doc of items) {
      const row = db.query('select raw from originals where id=?').get(doc.id);
      if (!row) throw Error('BATCH_MISSING');
      checked(doc.id, row.raw);
    }
  };
  batchVisible([]);
  for (const items of batches) {
    db.transaction(() => {
      const remove = id => {
        const old = db.query('select rowid from originals where id=?').get(id);
        if (!old) throw Error('DELETE_MISSING');
        db.query('delete from gram_index where rowid=?').run(old.rowid);
        db.query('delete from originals where rowid=?').run(old.rowid);
      };
      if (mode === 'delete') for (const id of stage.deleted) remove(id);
      for (const doc of items) {
        if (mode === 'update') remove(doc.id);
        const path = join(corpus, doc.output);
        if (statSync(path).size !== doc.bytes) throw Error('INPUT_SIZE');
        const raw = readFileSync(path), tokens = grams(checked(doc.id, raw));
        const inserted = db.query('insert into originals(id,path,raw) values(?,?,?)').run(doc.id, doc.path, raw);
        db.query('insert into gram_index(rowid,tokens) values(?,?)').run(inserted.lastInsertRowid, tokens.join(' '));
      }
    })();
    if (mode === 'delete') for (const id of stage.deleted) expectedLive.delete(id);
    for (const doc of items) expectedLive.add(doc.id);
    batchVisible(items);
    emit({kind: 'batch', number: ++batchNumber, count: db.query('select count(*) n from originals').get().n});
  }
  const visibleNs = ns(start);
  verifyLive();
  for (const query of stage.queries) queryOutput(query, 'commit-check', 0);
  for (const [i, marker] of stage.markers.entries()) queryOutput({slot: 100 + i, ...marker}, 'commit-check', 0);
  const diskAfter = disk();
  emit({kind: 'mutation', mode, visibleNs, batches: batchNumber, diskBefore, disk: diskAfter,
    logicalDiskDeltaBytes: diskAfter.bytes - diskBefore.bytes,
    writeAmplificationCaveat: 'directory logical delta, not OS physical bytes written'});
} else {
  verifyLive();
  if (mode === 'cancel') {
    // Install listener before completing first work, so queued host input is not lost.
    const lines = createInterface({input: process.stdin});
    const received = new Promise(resolve => lines.once('line', resolve));
    queryOutput(stage.queries[0], 'first', 0);
    emit({kind: 'batch-complete', completed: 1, published: 1});
    if (await received !== 'CANCEL') throw Error('CANCEL_PROTOCOL');
    emit({kind: 'cancelled', completed: 1, published: 1});
    lines.close();
  } else {
    for (const query of stage.queries) queryOutput(query, 'first', 0);
    for (const query of stage.queries) {
      for (let i = 0; i < 10; i++) queryOutput(query, 'warmup', i);
      for (let i = 0; i < 200; i++) queryOutput(query, 'timed', i);
    }
  }
}
const closeStart = now();
const checkpoint = readonly ? null : db.query('pragma wal_checkpoint(TRUNCATE)').all();
const checkpointNs = readonly ? null : ns(closeStart);
db.close();
emit({kind: 'closed', checkpoint, checkpointNs, closeNs: ns(closeStart), disk: disk()});
