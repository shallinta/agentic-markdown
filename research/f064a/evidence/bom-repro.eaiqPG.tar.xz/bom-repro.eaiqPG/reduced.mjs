import { Database } from 'bun:sqlite';
import { readFileSync } from 'node:fs';
import { grams } from '/tmp/agentic-f064a-literal.TNa1mW/common.mjs';
const stage = process.argv[2];
const original = '/tmp/agentic-f064a-literal.TNa1mW/fixtures/';
const bytes = stage === 'small' ? Buffer.from([0xef, 0xbb, 0xbf, 0xe4, 0xb8, 0xad]) : readFileSync(original + 'f.txt');
const raw = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(bytes);
const query = stage === 'small' ? '中' : '第二行';
const db = new Database(':memory:');
db.exec('create table originals(id text primary key, raw text not null)');
if (stage === 'one-doc') db.exec("create virtual table gram_index using fts5(tokens, tokenize='ascii')");
db.transaction(() => {
  db.query('insert into originals(rowid,id,raw) values(?,?,?)').run(1, 'f', raw);
  if (stage === 'one-doc') db.query('insert into gram_index(rowid,tokens) values(?,?)').run(1, grams(raw).join(' '));
})();
const rows = stage === 'one-doc'
  ? db.query('select originals.id, originals.raw from gram_index join originals on originals.rowid=gram_index.rowid where gram_index match ? order by originals.id').all(grams(query, true).join(' AND '))
  : db.query('select id, raw from originals order by id').all();
const hits = rows.map(row => [row.id, row.raw.indexOf(query), row.raw.indexOf(query) + query.length]);
console.log(JSON.stringify({ candidates: rows.map(row => [row.id, Buffer.from(row.raw).toString('hex')]), hits }));
