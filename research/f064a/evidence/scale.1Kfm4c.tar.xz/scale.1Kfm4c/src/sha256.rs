use std::ffi::c_void;
// macOS SDK CommonCrypto/CommonDigest.h: CC_LONG uint32_t; digest length 32.
#[link(name = "System")]
extern "C" {
    fn CC_SHA256(data: *const c_void, len: u32, md: *mut u8) -> *mut u8;
}
pub fn digest(bytes: &[u8]) -> String {
    let length = u32::try_from(bytes.len()).expect("SHA_LENGTH");
    let mut output = [0u8; 32];
    let destination = output.as_mut_ptr();
    // Input and output remain alive and non-overlapping for this synchronous call.
    // Output owns all 32 bytes required by the public API.
    let returned = unsafe { CC_SHA256(bytes.as_ptr().cast(), length, destination) };
    assert!(!returned.is_null() && returned == destination, "SHA_RETURN");
    output.iter().map(|byte| format!("{byte:02x}")).collect()
}
