import { Database } from 'bun:sqlite';
const input = Uint8Array.from([0xef, 0xbb, 0xbf, 0xe4, 0xb8, 0xad]);
const raw = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(input);
const before = {
  codepoints: Array.from(raw, char => char.codePointAt(0).toString(16)),
  utf8: Buffer.from(raw).toString('hex'),
};
const db = new Database(':memory:');
db.exec('create table t(raw text)');
db.query('insert into t values(?)').run(raw);
const sql = db.query('select hex(raw) as bytes, length(raw) as length, typeof(raw) as type from t').get();
const text = db.query('select raw from t').get().raw;
const blob = db.query('select cast(raw as blob) as bytes from t').get().bytes;
console.log(JSON.stringify({ input: Buffer.from(input).toString('hex'), before, sql,
  returnedText: { utf8: Buffer.from(text).toString('hex'), codepoints: Array.from(text, char => char.codePointAt(0).toString(16)) },
  returnedBlob: { type: blob.constructor.name, utf8: Buffer.from(blob).toString('hex') } }));
