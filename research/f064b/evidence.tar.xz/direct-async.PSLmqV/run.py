"""Explicit single diagnostic arm; no automatic retry or GC repair."""
import json
import pathlib
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
OLD = pathlib.Path('/tmp/agentic-f064b-bridge.w0G13h')
sys.path.insert(0, str(OLD))
from processes import command, sha

BUN = pathlib.Path('/tmp/agentic-direct186.uXVnAg/Agentic Markdown-canary.app/Contents/MacOS/bun')

def main():
    assert len(sys.argv) == 2 and sys.argv[1] == 'direct-open-close'
    mode = sys.argv[1]
    compiled = json.loads((OLD / 'run-1792339410377845000/receipt.json').read_bytes())
    assert compiled['status'] == 'complete'
    assert all(sha(OLD / name) == value for name, value in compiled['sources'].items())
    assert sha(OLD / 'index-primitives.node') == compiled['nativeSHA']
    assert sha(BUN) == compiled['bunSHA']
    pins = {name: sha(ROOT / name) for name in ('probe.mjs', 'worker.mjs', 'run.py')}
    output = ROOT / ('run-' + str(time.time_ns()))
    output.mkdir()
    receipt = {'status': 'running', 'mode': mode, 'sources': pins, 'original': compiled}
    try:
        rows = command(output, 'probe', [str(BUN), str(ROOT / 'probe.mjs'), mode, str(output)],
                       time.monotonic() + 15, parse=True)
        assert len(rows) == 1 and rows[-1] == {'mode': mode, 'assertions': 'complete'}
        receipt['status'] = 'complete'
    except Exception as error:
        receipt.update(status='failed', error=repr(error))
        raise
    finally:
        audit = output / 'index.audit'
        receipt['audit'] = {'sha': sha(audit), 'text': audit.read_text()} if audit.exists() else None
        receipt['sourcesUnchanged'] = all(sha(ROOT / name) == value for name, value in pins.items())
        receipt['originalUnchanged'] = all(sha(OLD / name) == value for name, value in compiled['sources'].items())
        receipt['nativeUnchanged'] = sha(OLD / 'index-primitives.node') == compiled['nativeSHA']
        if not all(receipt[key] for key in ('sourcesUnchanged', 'originalUnchanged', 'nativeUnchanged')):
            receipt.update(status='failed', pinError='SOURCE_CHANGED')
        (output / 'receipt.json').write_text(json.dumps(receipt, indent=2))
        print(output)
    assert receipt['status'] == 'complete', 'DIAGNOSTIC_FAILED'

if __name__ == '__main__':
    main()
