import {readFileSync,writeFileSync,statSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root='/tmp/agentic-f064a-rust190.zxE80R';
const sha=f=>createHash('sha256').update(readFileSync(f)).digest('hex');
if(sha(root+'/downloads/channel.toml')!=='489c19f20d331765ab2835661eb546de90f6446a107a8db83045e7371e45cae2')throw Error('manifest');
const hashes={rustc:'89551c0ba1cc6d0312aebc4a6cafe4497223217ea8e87c81f6afbe127dfaeeb6',cargo:'17a4410a27bf7dad4765f3809265c225f25f8b009da3d4b76cd0927acdae04b5','rust-std':'c36777aec17d617f85f94b7cb87bdd4270eeca30ef38c6f686809d163c881609'};
for(const [name,expected] of Object.entries(hashes)){
 const file=`${root}/downloads/${name}.tar.xz`,prefix=`${name}-1.90.0-aarch64-apple-darwin`,hash=sha(file);
 if(hash!==expected)throw Error('hash '+name);
 const v=spawnSync('/usr/bin/tar',['-tvf',file],{encoding:'utf8',timeout:60000,maxBuffer:16*1024*1024});
 writeFileSync(`${root}/logs/archive-${name}.list`,v.stdout??'');
 if(v.status!==0||v.stdout.trim().split('\n').some(l=>!['d','-'].includes(l[0]))||!v.stdout.trim().split('\n').some(l=>l[0]==='d'&&l.endsWith(' '+prefix)))throw Error('type '+name);
 const p=spawnSync('/usr/bin/tar',['-tf',file],{encoding:'utf8',timeout:60000,maxBuffer:16*1024*1024});
 if(p.status!==0||p.stdout.trim().split('\n').some(x=>x.startsWith('/')||x.split('/').includes('..')||(x!==prefix&&!x.startsWith(prefix+'/'))))throw Error('path '+name);
 console.log({name,hash,bytes:statSync(file).size,entries:p.stdout.trim().split('\n').length,links:0});
}
