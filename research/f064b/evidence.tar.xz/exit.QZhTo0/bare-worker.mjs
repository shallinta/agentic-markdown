self.onmessage = event => {
  if (event.data !== 'close') throw Error('MESSAGE');
  postMessage({ closed: true });
  close();
};
