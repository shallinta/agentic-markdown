import {join} from 'node:path';
import {validResult} from './protocol.mjs';
export class Client{
 constructor(root,epoch=1){this.epoch=epoch;this.serial=0;this.active=null;this.latest=null;this.closed=false;this.published=0;this.sent=[];this.lastPublishedCommit=0;
  this.worker=new Worker(join(root,'worker.mjs'));this.worker.onmessage=e=>this.receive(e.data);
  this.worker.onerror=()=>this.terminal({code:'WORKER_ERROR',unknown:true});
 }
 terminal(result){this.closed=true;this.active?.resolve(result);this.active=null;this.latest?.resolve({code:'CANCELLED'});this.latest=null;this.cancelResolve?.(result);}
 receive(m){if(!m||m.version!==1||m.epoch!==this.epoch||!this.active||m.id!==this.active.id)return;
  const current=this.active;if(!validResult(m.result,current.op)){this.terminal({code:'INVALID_RESPONSE',unknown:true});return;}
  this.active=null;if(!current.cancelled){this.published++;if(current.op==='commit'&&m.result.code===0)this.lastPublishedCommit=m.result.generation;current.resolve(m.result);}else current.resolve({code:'CANCELLED'});
  if(current.op==='close'||current.op==='cancel'){this.terminal(m.result);return;}
  if(this.cancelling){this.send('cancel',null,true).then(this.cancelResolve);return;}
  if(this.latest){const next=this.latest;this.latest=null;this.send(next.op,next.payload).then(next.resolve);}
 }
 send(op,payload=null,internal=false){if(this.closed)return Promise.resolve({code:'CLOSED'});if(this.cancelling&&!internal)return Promise.resolve({code:'CANCELLED'});
  if(this.active){if(op!=='query')return Promise.resolve({code:'BUSY',accepted:false});
   this.latest?.resolve({code:'CANCELLED'});return new Promise(resolve=>{this.latest={op,payload,resolve};});}
  return new Promise(resolve=>{const id=++this.serial;this.active={id,op,resolve,cancelled:false};try{this.worker.postMessage({version:1,epoch:this.epoch,id,op,payload});this.sent.push({id,op});}
   catch{this.terminal({code:'DISPATCH_ERROR',unknown:true});}});
 }
 discardQueries(){this.latest?.resolve({code:'CANCELLED'});this.latest=null;if(this.active?.op==='query')this.active.cancelled=true;}
 cancel(){if(this.cancelPromise)return this.cancelPromise;this.cancelling=true;this.discardQueries();
  this.cancelPromise=new Promise(resolve=>{this.cancelResolve=resolve;});if(!this.active)this.send('cancel',null,true).then(this.cancelResolve);return this.cancelPromise;}
 releaseHold(){this.worker.postMessage({version:1,epoch:this.epoch,id:++this.serial,op:'release',payload:null});}
}
