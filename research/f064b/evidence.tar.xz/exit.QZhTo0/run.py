"""Explicit single minimisation case; no execution during source preparation."""
import json
import pathlib
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
OLD = pathlib.Path('/tmp/agentic-f064b-bridge.w0G13h')
sys.path.insert(0, str(OLD))
from processes import command, sha

BUN = pathlib.Path('/tmp/agentic-direct186.uXVnAg/Agentic Markdown-canary.app/Contents/MacOS/bun')
MODES = ('client-open-close', 'direct-open-close', 'bare-close')

def main():
    assert len(sys.argv) == 2 and sys.argv[1] in MODES
    mode = sys.argv[1]
    compiled = json.loads((OLD / 'run-1792339410377845000/receipt.json').read_bytes())
    assert compiled['status'] == 'complete'
    assert all(sha(OLD / name) == value for name, value in compiled['sources'].items())
    assert sha(OLD / 'index-primitives.node') == compiled['nativeSHA']
    assert sha(BUN) == compiled['bunSHA']
    pins = {name: sha(ROOT / name) for name in ('probe.mjs', 'bare-worker.mjs', 'run.py')}
    output = ROOT / ('run-' + str(time.time_ns()))
    output.mkdir()
    receipt = {'status': 'running', 'mode': mode, 'sources': pins, 'original': compiled}
    try:
        rows = command(output, 'probe', [str(BUN), str(ROOT / 'probe.mjs'), mode, str(output)],
                       time.monotonic() + 15, parse=True)
        assert rows == [{'mode': mode, 'assertions': 'complete'}]
        assert all(sha(ROOT / name) == value for name, value in pins.items())
        assert all(sha(OLD / name) == value for name, value in compiled['sources'].items())
        assert sha(OLD / 'index-primitives.node') == compiled['nativeSHA']
        receipt['status'] = 'complete'
    except Exception as error:
        receipt.update(status='failed', error=repr(error))
        raise
    finally:
        (output / 'receipt.json').write_text(json.dumps(receipt, indent=2))
        print(output)

if __name__ == '__main__':
    main()
