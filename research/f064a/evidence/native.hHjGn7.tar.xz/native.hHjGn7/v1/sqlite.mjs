import {Database} from 'bun:sqlite';
import {readFileSync} from 'node:fs';
import {join} from 'node:path';
const [root,profile,which]=process.argv.slice(2);
if(!['unicode61','trigram'].includes(profile))throw Error('profile');
const read=n=>{const bytes=readFileSync(join(root,n));if(bytes.length>4096)throw Error('input bound');const text=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes);if(!Buffer.from(text).equals(bytes))throw Error('roundtrip');return text;};
const db=new Database(':memory:');
try {
 const version=db.query('select sqlite_version() as version, sqlite_source_id() as source').get();
 const options=db.query('pragma compile_options').all();
 if(version.version!=='3.54.0'||!options.some(x=>x.compile_options==='ENABLE_FTS5'))throw Error('engine version');
 if(which==='empty'){console.log(JSON.stringify({profile,version,status:'skipped'}));process.exit(0);}
 // profile is restricted enum, never user query text.
 db.exec(`CREATE VIRTUAL TABLE ft USING fts5(body, tokenize='${profile}', detail=full)`);
 db.exec("CREATE VIRTUAL TABLE vocab USING fts5vocab(ft, 'instance')");
 const insert=db.query('INSERT INTO ft(rowid,body) VALUES(?,?)');
 for(let i=0;i<6;i++)insert.run(i+1,read(`doc-${i}.txt`));
 const rows=()=>db.query('SELECT term,doc,col,offset FROM vocab ORDER BY doc,offset,term').all();
 if(which==='fixture'){const tokens=rows();if(tokens.length>1536)throw Error('tokens bound');console.log(JSON.stringify({profile,version,status:'fixture',tokens,span:'unavailable-token-ordinal'}));}
 else {
  const n=Number(which);if(!Number.isInteger(n)||n<0||n>=15)throw Error('case');
  db.exec(`CREATE VIRTUAL TABLE qprobe USING fts5(body, tokenize='${profile}', detail=full)`);
  db.exec("CREATE VIRTUAL TABLE qv USING fts5vocab(qprobe, 'instance')");
  const query=read(`query-${n}.txt`);db.exec('DELETE FROM qprobe');db.query('INSERT INTO qprobe(rowid,body) VALUES(?,?)').run(1,query);
  const tokens=db.query('SELECT term,doc,col,offset FROM qv ORDER BY doc,offset,term').all();
  const encoded='"'+query.replaceAll('"','""')+'"';
  const ids=db.query('SELECT rowid FROM ft WHERE ft MATCH ? ORDER BY rowid').all(encoded).map(x=>String.fromCharCode(96+Number(x.rowid)));
  if(tokens.length>256||ids.length>6||new Set(ids).size!==ids.length||ids.some(x=>!['a','b','c','d','e','f'].includes(x)))throw Error('output bound');
  console.log(JSON.stringify({profile,version,status:tokens.length?'tokens':'no-token',tokens,encoded,ids,span:'unavailable-token-ordinal'}));
 }
} finally {db.close();}
