import {spawn,spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {validateScalarString,checkScalarRejection} from './scalars.mjs';
const root='/tmp/agentic-f064a-native.hHjGn7',tool='/tmp/agentic-f064a-rust190.zxE80R';
const bun='/tmp/agentic-direct186.uXVnAg/Agentic Markdown-canary.app/Contents/MacOS/bun';
const sha=f=>createHash('sha256').update(readFileSync(f)).digest('hex');
const manifestHash='77ada5d071e42a3d23e5c747810b3757d6653eca448efc9271bd51ff0bf0a3be';
const lockHash='639d75f7f400a528fb5879936175f31f51ba6a762e5cee8202f80f73dc00f347';
function verify(){if(sha(root+'/manifest.json')!==manifestHash||sha(root+'/project/Cargo.lock')!==lockHash||sha(bun)!=='539598c775882420b9d8deb7dc14d845f20f7d26f5600c50ab067dde6ac3f3bf')throw Error('frozen input');for(const f of [...manifest.documents,...manifest.queries,manifest.empty]){const bytes=readFileSync(root+'/fixtures/'+f.name);if(sha(root+'/fixtures/'+f.name)!==f.sha256||bytes.length!==f.byteLength)throw Error('fixture');validateScalarString(new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes));}}
const manifest=JSON.parse(readFileSync(root+'/manifest.json','utf8'));
const mode=process.argv[2];if(!['compile','diagnose'].includes(mode))throw Error('explicit mode required');
verify();const output=root+'/run-'+Date.now();mkdirSync(output);let activeStop,batchExpired=false,deadline=Infinity;
const env={...process.env,RUSTC:tool+'/prefix/bin/rustc',RUSTDOC:tool+'/prefix/bin/rustdoc',CARGO_HOME:tool+'/cargo-home',CARGO_TARGET_DIR:root+'/target',CARGO_HTTP_TIMEOUT:'30',CARGO_NET_RETRY:'2',PATH:tool+'/prefix/bin:/usr/bin:/bin:/usr/sbin:/sbin'};
async function command(label,cmd,args,ms){
 const start=Date.now(),child=spawn(cmd,args,{cwd:root+'/project',env,detached:true,stdio:['ignore','pipe','pipe']});
 const stdout=[],stderr=[];let total=0,error,expired=false,killTimer;
 const kill=s=>{try{process.kill(-child.pid,s)}catch(e){if(e.code!=='ESRCH')error=String(e)}};
 const stop=()=>{expired=true;kill('SIGTERM');if(!killTimer)killTimer=setTimeout(()=>kill('SIGKILL'),5000)};
 activeStop=stop;
 for(const [stream,chunks] of [[child.stdout,stdout],[child.stderr,stderr]])stream.on('data',chunk=>{total+=chunk.length;if(total>1048576){error='output limit';stop();return}chunks.push(chunk)});
 child.on('error',e=>error=String(e));const timer=setTimeout(stop,ms);
 const [status,signal]=await new Promise(resolve=>child.on('close',(a,b)=>resolve([a,b])));clearTimeout(timer);
 if(killTimer){await new Promise(r=>setTimeout(r,5100));clearTimeout(killTimer)}activeStop=undefined;
 const ps=spawnSync('/bin/ps',['-axo','pid,ppid,pgid,command'],{encoding:'utf8',timeout:10000});
 const members=(ps.stdout??'').split('\n').filter(l=>l.trim().split(/\s+/)[2]===String(child.pid));
 const out=Buffer.concat(stdout),err=Buffer.concat(stderr);
 writeFileSync(output+'/'+label+'.stdout',out);writeFileSync(output+'/'+label+'.stderr',err);
 const receipt={label,cmd,args,start,elapsedMs:Date.now()-start,status,signal,error,expired,pid:child.pid,groupMembersAfter:members,psStatus:ps.status};
 writeFileSync(output+'/'+label+'.json',JSON.stringify(receipt,null,2));
 if(status!==0||expired||error||members.length||ps.status!==0||batchExpired||Date.now()>=deadline)throw Error('case failed '+label);
 return new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(out);
}
function unhex(h){if(!/^(?:[a-f0-9]{2})*$/.test(h)||h.length>16384)throw Error('hex');return new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(Buffer.from(h,'hex'));}
function number(s){if(!/^\d+$/.test(s)||!Number.isSafeInteger(Number(s)))throw Error('number');return Number(s)}
function rustResult(raw,which){
 const rows=raw.replace(/\n$/,'').split('\n'),tokens=[];let result;
 for(const row of rows){const p=row.split('\t');
  if(p[0]==='T'&&p.length===9){if(tokens.length>=1536||!['doc','query'].includes(p[1]))throw Error('tokens');tokens.push({kind:p[1],id:unhex(p[2]),text:unhex(p[3]),position:number(p[4]),positionLength:number(p[5]),from:number(p[6]),to:number(p[7]),raw:unhex(p[8])});}
  else if(p[0]==='D'&&p.length===2&&p[1]==='6'&&which==='fixture'&&!result)result={status:'fixture'};
  else if(p[0]==='S'&&p.length===2&&p[1]==='skipped'&&which==='empty'&&!result)result={status:'skipped'};
  else if(p[0]==='R'&&p.length===4&&!result&&which!=='fixture'&&which!=='empty'){const count=number(p[2]);result={status:count?'tokens':'no-token',encoded:unhex(p[1]),ids:p[3]?p[3].split(','):[],count};}
  else throw Error('TSV record');
 }
 if(!result)throw Error('missing terminal');
 if(result.ids&&(result.count!==tokens.length||result.ids.some(id=>!manifest.expectedIdsDomain.includes(id))||new Set(result.ids).size!==result.ids.length||JSON.stringify([...result.ids].sort())!==JSON.stringify(result.ids)))throw Error('result');
 return {...result,tokens};
}
let batchTimer;
try{
 if(mode==='compile')await command('compile',tool+'/prefix/bin/cargo',['build','--release','--locked'],600000);
 else {
  deadline=Date.now()+180000;
  // This outer deadline is independent of case timers and stops only this runner's active group.
  batchTimer=setTimeout(()=>{batchExpired=true;activeStop?.();},180000);
  const cases=['fixture',...manifest.queries.map((_,i)=>String(i)),'empty'],results=[];
  writeFileSync(output+'/scalar-precheck.json',JSON.stringify(checkScalarRejection()));
  for(const profile of manifest.profiles)for(const which of cases){
   verify();const remaining=deadline-Date.now();if(remaining<=0)throw Error('batch deadline');
   const isRust=profile==='tantivy',cmd=isRust?root+'/target/release/f064a-toolchain-check':bun;
   const args=isRust?[root+'/fixtures',which]:[root+'/sqlite.mjs',root+'/fixtures',profile,which];
   const raw=await command(profile+'-'+which,cmd,args,Math.min(15000,remaining));
   const parsed=isRust?rustResult(raw,which):JSON.parse(raw);
   if(!isRust){if(parsed.profile!==profile||!['fixture','tokens','no-token','skipped'].includes(parsed.status)||!Array.isArray(parsed.tokens??[])||(parsed.tokens??[]).length>1536)throw Error('sqlite result');for(const t of parsed.tokens??[])if(typeof t.term!=='string'||t.col!=='body'||!Number.isSafeInteger(t.offset)||t.offset<0||!Number.isSafeInteger(t.doc)||t.doc<1||t.doc>(which==='fixture'?6:1))throw Error('vocab');}
   verify();if(batchExpired||Date.now()>=deadline)throw Error('batch deadline');results.push({profile,case:which,...parsed});writeFileSync(output+'/results.json',JSON.stringify(results,null,2));
  }
  if(results.length!==manifest.caseCount)throw Error('case count');
 }
 verify();if(batchExpired||Date.now()>=deadline)throw Error('batch deadline');writeFileSync(output+'/receipt.json',JSON.stringify({mode,status:'complete',manifestHash,lockHash,output},null,2));console.log(output);
}catch(e){writeFileSync(output+'/receipt.json',JSON.stringify({mode,status:'failed',error:String(e),output},null,2));console.error(e);process.exitCode=1;}
finally{clearTimeout(batchTimer)}
