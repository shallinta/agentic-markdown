export function validateScalarString(text) {
 if(typeof text!=='string')throw Error('INVALID_SCALAR');
 for(let i=0;i<text.length;i++){
  const n=text.charCodeAt(i);
  if(n>=0xd800&&n<=0xdbff){const next=text.charCodeAt(++i);if(!(next>=0xdc00&&next<=0xdfff))throw Error('INVALID_SCALAR');}
  else if(n>=0xdc00&&n<=0xdfff)throw Error('INVALID_SCALAR');
 }
 return text;
}
export function withValidatedScalars(text,action){return action(validateScalarString(text));}
export function checkScalarRejection(){
 let dispatches=0,rejections=0;
 for(const invalid of ['\ud800','\udc00']){
  try{withValidatedScalars(invalid,()=>{dispatches++;Buffer.from(invalid,'utf8');});throw Error('accepted invalid');}
  catch(error){if(error.message!=='INVALID_SCALAR')throw error;rejections++;}
 }
 if(dispatches!==0||rejections!==2)throw Error('invalid dispatched');
 for(const text of ['😀','𠮷','"','\\'])validateScalarString(text);
 return {rejections,dispatches};
}
