import { addon } from '/tmp/agentic-f064b-bridge.w0G13h/protocol.mjs';
const native = addon('/tmp/agentic-f064b-bridge.w0G13h');
self.onmessage = event => {
  if (event.data !== 'close') throw Error('MESSAGE');
  if (native.version() !== 1) throw Error('ABI');
  // No open/call/close native session and no index directory creation.
  postMessage({ closed: true, abi: 1 });
  close();
};
