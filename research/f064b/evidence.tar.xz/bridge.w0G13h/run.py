"""Explicit compile or six fixed cases; source preparation does not invoke either."""
import ast
import json
import os
import pathlib
import re
import shlex
import sys
import time
from processes import command, sha

ROOT=pathlib.Path(__file__).resolve().parent
TOOL=pathlib.Path('/tmp/agentic-f064a-rust190.zxE80R')
BUN=pathlib.Path('/tmp/agentic-direct186.uXVnAg/Agentic Markdown-canary.app/Contents/MacOS/bun')
HEADERS=pathlib.Path('/Users/shallinta/Documents/github/agentic-markdown/apps/desktop/node_modules/node-api-headers/include')
LOCK='639d75f7f400a528fb5879936175f31f51ba6a762e5cee8202f80f73dc00f347'
BUN_SHA='539598c775882420b9d8deb7dc14d845f20f7d26f5600c50ab067dde6ac3f3bf'
SOURCES=['Cargo.toml','Cargo.lock','index_bridge_v1.h','src/lib.rs','bridge.c','protocol.mjs','worker.mjs','client.mjs','cases.mjs','processes.py','run.py','README.md']

def sources():
    return {name:sha(ROOT/name) for name in SOURCES}

def headers():
    return {p.name:sha(p) for p in sorted(HEADERS.glob('*.h'))}

def main():
    assert sys.platform=='darwin' and len(sys.argv)==2 and sys.argv[1] in ('compile','diagnose')
    mode=sys.argv[1]
    assert sha(ROOT/'Cargo.lock')==LOCK and sha(BUN)==BUN_SHA
    output=ROOT/('run-'+str(time.time_ns()));output.mkdir()
    frozen=sources();header_pins=headers();assert header_pins
    result={'status':'running','mode':mode,'sources':frozen,'headers':header_pins,'bunSHA':BUN_SHA,'records':[]}
    result['toolSHA']={name:sha(TOOL/'prefix/bin'/name) for name in ('cargo','rustc','rustdoc')}
    assert result['toolSHA']=={
        'rustc':'b2011d06d5c7efff7b48b1e1aec6106989e44f3a5ad1d171e06a41c0fbc3ffea',
        'cargo':'b617f75ab3fadd5d764368413b7e87532dfa45039aac431f9c0af883b824a6e6',
        'rustdoc':'07908f4c9e558bc6a4025c9aa3c717eeabf6cdb916b02f4790dc7b655a8744e4'},'TOOLCHAIN_PIN'
    (output/'sources.json').write_text(json.dumps(frozen,indent=2))
    try:
        if mode=='compile':
            deadline=time.monotonic()+600
            prefix=TOOL/'prefix'
            environment={**os.environ,'RUSTC':str(prefix/'bin/rustc'),'RUSTDOC':str(prefix/'bin/rustdoc'),
                'CARGO_HOME':str(TOOL/'cargo-home'),'CARGO_TARGET_DIR':str(ROOT/'target'),
                'CARGO_NET_OFFLINE':'true','PATH':str(prefix/'bin')+':/usr/bin:/bin:/usr/sbin:/sbin'}
            command(output,'rust',[str(prefix/'bin/cargo'),'rustc','--release','--locked','--lib','--','--print','native-static-libs'],deadline,environment,parse=False)
            stderr=(output/'rust.stderr').read_text()
            matches=re.findall(r'native-static-libs:\s*([^\n]+)',stderr)
            assert len(matches)==1,'EXACT_NATIVE_LIBS_OUTPUT'
            libs=shlex.split(matches[0])
            assert libs and all(re.fullmatch(r'-l[A-Za-z0-9_+.-]+',x) for x in libs),'NATIVE_LIBS_REVIEW_REQUIRED'
            result['nativeStaticLibs']=libs
            command(output,'clang',['/usr/bin/xcrun','clang','-bundle','-undefined','dynamic_lookup','-DNAPI_VERSION=8',
                '-Wall','-Wextra','-Werror','-I',str(HEADERS),str(ROOT/'bridge.c'),str(ROOT/'target/release/libf064b_index.a'),
                *libs,'-o',str(ROOT/'index-primitives.node')],deadline,environment,parse=False)
            result['nativeSHA']=sha(ROOT/'index-primitives.node');result['staticlibSHA']=sha(ROOT/'target/release/libf064b_index.a')
        else:
            compiles=[]
            for p in ROOT.glob('run-*/receipt.json'):
                v=json.loads(p.read_bytes())
                if v.get('mode')=='compile' and v.get('status')=='complete':compiles.append((p,v))
            assert compiles,'SUCCESSFUL_COMPILE_REQUIRED'
            receipt,compiled=sorted(compiles)[-1]
            assert compiled['sources']==frozen and compiled['headers']==header_pins
            assert compiled['nativeSHA']==sha(ROOT/'index-primitives.node')
            result.update({'compileReceipt':str(receipt),'nativeSHA':compiled['nativeSHA']})
            deadline=time.monotonic()+180
            for case in range(1,7):
                assert time.monotonic()<deadline
                label='case'+str(case)
                rows=command(output,label,[str(BUN),str(ROOT/'cases.mjs'),str(ROOT),str(output/label),str(case)],min(deadline,time.monotonic()+15),parse=True)
                assert rows[-1]=={'case':str(case),'status':'complete','injected':case in (4,6)}
                if case==4:
                    cancel=rows[0]['cancel'];assert cancel['ack']>=cancel['sent'] and cancel['lastCompleted']==cancel['lastPublished']==cancel['batchDispatches']==1
                    audit=(output/label/'lifecycle.audit').read_text().splitlines()
                    assert sum(line.startswith('close ') for line in audit)==2
                    assert sum(line.startswith('finalize ') for line in audit)==2
                    assert any(line.startswith('cleanup ') for line in audit)
                    assert audit[-1]=='state-free 2 2 2'
                result['records'].append({'case':case,'rows':rows})
                assert sources()==frozen and headers()==header_pins and sha(ROOT/'index-primitives.node')==compiled['nativeSHA']
        assert sources()==frozen and headers()==header_pins and sha(ROOT/'Cargo.lock')==LOCK
        result['status']='complete'
    except Exception as error:
        result.update(status='failed',error=repr(error));raise
    finally:
        (output/'receipt.json').write_text(json.dumps(result,indent=2));print(output)

if __name__=='__main__':main()
