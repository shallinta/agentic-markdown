import { Database } from 'bun:sqlite';
import { createHash } from 'node:crypto';
import { readFileSync, statSync, existsSync, mkdirSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
const ROOT = import.meta.dirname;
const hash = b => createHash('sha256').update(b).digest('hex');
const manifestBytes = readFileSync(join(ROOT, 'manifest.json'));
if (hash(manifestBytes) !== 'd6b544e240993096dfb7514621f7a954413df22d2189e69a8919abd497561711') throw Error('MANIFEST');
const manifest = JSON.parse(manifestBytes);
const docs = new Map(manifest.documents.map(d => [d.id, d]));
const [mode, directory] = process.argv.slice(2);
if (!['build', 'query'].includes(mode) || !directory) throw Error('ARGS');
const now = () => process.hrtime.bigint();
const ns = start => Number(now() - start);
const decode = b => new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(b);
const MODEL = 297516520;
if (MODEL > 512 * 1024 * 1024) throw Error('MODEL');
function reserve(b) {
  if (b > 25352) throw Error('DOC_BYTES');
  const k = b + Math.max(b - 1, 0) + Math.max(b - 2, 0);
  const e = 9*b + 15*Math.max(b-1,0) + 21*Math.max(b-2,0);
  if (8*b + 512*k + 4*(e+k) + 1048576 + 4*352051 + 12*4096*64 + 8388608 > 58002188) throw Error('RESERVE');
}
function grams(text, query = false) {
  const chars = Array.from(text);
  if (query && text.length > 4096) throw Error('QUERY_LIMIT');
  const values = new Set();
  for (const n of query ? [Math.min(3, chars.length)] : [1,2,3]) {
    if (!n) continue;
    for (let i=0; i+n<=chars.length; i++) {
      const token = 'g'+n+'x'+chars.slice(i,i+n).map(c=>c.codePointAt(0).toString(16).padStart(6,'0')).join('');
      if (!values.has(token) && values.size >= 76056) throw Error('TOKEN_COUNT');
      values.add(token);
    }
  }
  const tokens = [...values].sort();
  if (tokens.reduce((a,t)=>a+t.length,0)+Math.max(0,tokens.length-1)>1216896) throw Error('TOKEN_BYTES');
  return tokens;
}
function checked(id, bytes) {
  const d = docs.get(id);
  if (!d || !(bytes instanceof Uint8Array)) throw Error('CANDIDATE_TYPE');
  reserve(d.bytes);
  if (bytes.byteLength !== d.bytes || hash(bytes) !== d.sha256) throw Error('RAW_IDENTITY');
  const text = decode(bytes);
  if (!Buffer.from(text).equals(Buffer.from(bytes))) throw Error('ROUNDTRIP');
  return { text, sha: d.sha256, bytes: bytes.byteLength };
}
let outputBytes = 0;
function emit(result) {
  const start = now();
  const encoded = JSON.stringify(result);
  const serializeNs = ns(start);
  const line = '{"result":' + encoded + ',"serializeNs":' + serializeNs + '}\n';
  outputBytes += Buffer.byteLength(line);
  if (outputBytes > 64*1024*1024) throw Error('OUTPUT_LIMIT');
  process.stdout.write(line);
}
function disk() {
  let bytes=0, files=0;
  for (const name of readdirSync(directory)) {
    const s=statSync(join(directory,name));
    if (!s.isFile()) throw Error('INDEX_NONFILE');
    bytes+=s.size; files++;
  }
  return {bytes,files};
}
const opened = now();
const readonly = mode === 'query';
if (readonly ? !existsSync(directory) : existsSync(directory)) throw Error('INDEX_EXISTENCE');
if (!readonly) mkdirSync(directory);
const db = new Database(join(directory,'index.db'), {readonly,readwrite:!readonly,create:!readonly});
db.exec('pragma cache_size=-16384; pragma synchronous=FULL');
if (!readonly) db.exec('pragma journal_mode=WAL; pragma wal_autocheckpoint=1000');
const pragmas = Object.fromEntries(['cache_size','synchronous','journal_mode','wal_autocheckpoint'].map(k=>[k,db.query('pragma '+k).get()]));
if (Object.values(pragmas.journal_mode)[0] !== 'wal' || Object.values(pragmas.cache_size)[0] !== -16384 || Object.values(pragmas.synchronous)[0] !== 2) throw Error('PRAGMA');
if (!readonly) db.exec("create table originals(id text unique not null,path text not null,raw blob not null);create virtual table gram_index using fts5(tokens,tokenize='ascii');pragma user_version=1");
if (db.query('pragma user_version').get().user_version!==1) throw Error('SCHEMA');
if (JSON.stringify(db.query('pragma table_info(originals)').all().map(r=>[r.name,r.type.toLowerCase()]))!==JSON.stringify([['id','text'],['path','text'],['raw','blob']])) throw Error('SCHEMA');
if (!db.query("select sql from sqlite_master where name='gram_index'").get()?.sql.includes("fts5(tokens,tokenize='ascii')")) throw Error('FTS_SCHEMA');
emit({kind:'ready',mode,openNs:ns(opened),pragmas,sqlite:db.query('select sqlite_version() v').get().v,options:db.query('pragma compile_options').all(),modelBytes:MODEL});
function search(q) {
  const start=now(), tokens=grams(q.text,true);
  const rows=tokens.length>128
    ? db.query('select id,raw from originals order by id').all()
    : db.query('select originals.id,originals.raw from gram_index join originals on originals.rowid=gram_index.rowid where gram_index match ? order by originals.id').all(tokens.join(' AND '));
  if (rows.length>36) throw Error('CANDIDATE_COUNT');
  let bytes=0; const candidates=[],hits=[];
  for(const row of rows) {
    const value=checked(row.id,row.raw); bytes+=value.bytes;
    if(bytes>352051) throw Error('CANDIDATE_BYTES');
    candidates.push([row.id,value.sha]);
    const pos=value.text.indexOf(q.text);
    if(pos>=0)hits.push([row.id,pos,pos+q.text.length]);
  }
  const queryNs=ns(start);
  if(JSON.stringify(hits)!==JSON.stringify(q.hits))throw Error('ORACLE_'+q.slot);
  return {slot:q.slot,queryNs,candidates,candidateBytes:bytes,hits,mode:tokens.length>128?'scan-fallback':'index'};
}
if (!readonly) {
  const start=now(); let bytes=0;
  db.transaction(()=>{
    for(const d of manifest.documents){
      reserve(d.bytes);
      const p=join(manifest.corpusDirectory,d.output);
      if(statSync(p).size!==d.bytes)throw Error('INPUT_SIZE');
      const raw=readFileSync(p), value=checked(d.id,raw); bytes+=raw.length;
      if(bytes>352051)throw Error('CORPUS_BYTES');
      const tokens=grams(value.text);
      const inserted=db.query('insert into originals(id,path,raw) values(?,?,?)').run(d.id,d.path,raw);
      db.query('insert into gram_index(rowid,tokens) values(?,?)').run(inserted.lastInsertRowid,tokens.join(' '));
    }
  })();
  const visibleNs=ns(start);
  if(db.query('select count(*) n from originals').get().n!==36)throw Error('LIVE_COUNT');
  for(const q of manifest.queries) emit({kind:'query',phase:'commit-check',repeat:0,...search(q)});
  emit({kind:'build',visibleNs,disk:disk()});
  const closeStart=now();
  const checkpoint=db.query('pragma wal_checkpoint(TRUNCATE)').all();
  const checkpointNs=ns(closeStart);
  db.close();
  emit({kind:'closed',checkpoint,checkpointNs,closeNs:ns(closeStart),disk:disk()});
} else {
  for(const q of manifest.queries) emit({kind:'query',phase:'first',repeat:0,...search(q)});
  for(const q of manifest.queries){
    for(let i=0;i<10;i++)emit({kind:'query',phase:'warmup',repeat:i,...search(q)});
    for(let i=0;i<200;i++)emit({kind:'query',phase:'timed',repeat:i,...search(q)});
  }
  const start=now();db.close();
  emit({kind:'closed',closeNs:ns(start),disk:disk()});
}

