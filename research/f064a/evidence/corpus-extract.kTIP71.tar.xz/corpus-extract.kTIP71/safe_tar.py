import gzip
import json
import pathlib
import sys
import tarfile

MAX_STREAM = 256 * 1024 * 1024
MAX_ENTRY = 16 * 1024 * 1024
MAX_OUTPUT = 8 * 1024 * 1024


def scan(archive, expected_root, destination, selected, consume):
    if pathlib.Path(archive).stat().st_size > 32 * 1024 * 1024:
        raise ValueError('COMPRESSED_LIMIT')
    expanded = 0
    declared = 0
    count = 0
    output_bytes = 0
    names = set()
    global_pax_seen = False
    expected_commit = expected_root.rsplit('-', 1)[-1]
    if len(expected_commit) != 40 or any(c not in '0123456789abcdef' for c in expected_commit):
        raise ValueError('EXPECTED_COMMIT')
    with gzip.open(archive, 'rb') as stream, pathlib.Path(destination).open('xb') as output:
        def read(amount):
            nonlocal expanded
            remaining_budget = MAX_STREAM - expanded
            block = stream.read(min(amount, remaining_budget + 1))
            if len(block) > remaining_budget:
                raise ValueError('EXPANDED_LIMIT')
            expanded += len(block)
            return block

        while True:
            header = read(512)
            if len(header) != 512:
                raise ValueError('TRUNCATED_TAR_HEADER')
            if header == bytes(512):
                if read(512) != bytes(512):
                    raise ValueError('MISSING_SECOND_ZERO_BLOCK')
                while True:
                    padding = read(65536)
                    if not padding:
                        break
                    if any(padding):
                        raise ValueError('NONZERO_TRAILING_DATA')
                break
            # Public standard-library parser validates the header checksum.
            # NUL padding inside standard header fields is normal, not a name violation.
            entry = tarfile.TarInfo.frombuf(header, 'utf-8', 'strict')
            if entry.type == tarfile.XGLTYPE:
                if global_pax_seen or count != 0 or not 0 < entry.size <= 65536:
                    raise ValueError('GLOBAL_PAX_ORDER_OR_SIZE')
                if (not entry.name or '\x00' in entry.name or entry.name.startswith('/')
                        or '..' in entry.name.split('/') or len(entry.name.encode('utf-8')) > 4096):
                    raise ValueError('GLOBAL_PAX_HEADER_PATH')
                payload = read(entry.size)
                if len(payload) != entry.size:
                    raise ValueError('TRUNCATED_PAX')
                padding_size = (-entry.size) % 512
                if read(padding_size) != bytes(padding_size):
                    raise ValueError('PAX_PADDING')
                offset = 0
                keys = set()
                while offset < len(payload):
                    space = payload.find(b' ', offset)
                    if space < 0 or space - offset > 6:
                        raise ValueError('PAX_LENGTH')
                    digits = payload[offset:space]
                    if not digits.isdigit() or digits.startswith(b'0'):
                        raise ValueError('PAX_LENGTH')
                    length = int(digits)
                    end = offset + length
                    if end > len(payload) or end <= space + 1 or payload[end - 1:end] != b'\n':
                        raise ValueError('PAX_FRAME')
                    pair = payload[space + 1:end - 1]
                    if b'=' not in pair:
                        raise ValueError('PAX_KEY_VALUE')
                    key, value = pair.split(b'=', 1)
                    if key != b'comment' or key in keys or value != expected_commit.encode('ascii'):
                        raise ValueError('PAX_UNSUPPORTED_OR_DUPLICATE')
                    keys.add(key)
                    offset = end
                if keys != {b'comment'}:
                    raise ValueError('PAX_COMMENT_REQUIRED')
                global_pax_seen = True
                declared += entry.size
                continue
            if entry.type not in (tarfile.REGTYPE, tarfile.AREGTYPE, tarfile.DIRTYPE):
                raise ValueError('UNSUPPORTED_TYPE_' + repr(entry.type))
            # Local PAX/GNU, links and special entries are unsupported; no path/size overrides.
            name = entry.name
            encoded = name.encode('utf-8', 'strict')
            parts = name.rstrip('/').split('/')
            if (not name or '\x00' in name or name.startswith('/') or len(encoded) > 4096
                    or any(part in ('', '.', '..') for part in parts)):
                raise ValueError('UNSAFE_PATH')
            if parts[0] != expected_root:
                raise ValueError('UNEXPECTED_TOPDIR')
            if len(parts) == 1 and entry.type != tarfile.DIRTYPE:
                raise ValueError('ROOT_NOT_DIRECTORY')
            effective = '/'.join(parts)
            if effective in names:
                raise ValueError('DUPLICATE_EFFECTIVE_PATH')
            names.add(effective)
            count += 1
            if count + int(global_pax_seen) > 20000 or entry.size < 0 or entry.size > MAX_ENTRY:
                raise ValueError('ENTRY_LIMIT')
            if entry.type == tarfile.DIRTYPE and entry.size != 0:
                raise ValueError('DIRECTORY_PAYLOAD')
            declared += entry.size
            if declared > MAX_STREAM:
                raise ValueError('DECLARED_TOTAL_LIMIT')
            record = json.dumps({'path': name, 'type': 'dir' if entry.isdir() else 'file',
                                 'size': entry.size}, ensure_ascii=True).encode() + b'\n'
            if output_bytes + len(record) > MAX_OUTPUT:
                raise ValueError('METADATA_OUTPUT_LIMIT')
            output.write(record)
            output_bytes += len(record)
            if selected(effective, entry.size, entry.isdir()):
                if entry.size > 1024 * 1024:
                    raise ValueError('SELECTED_SIZE_LIMIT')
                payload = read(entry.size)
                if len(payload) != entry.size:
                    raise ValueError('TRUNCATED_SELECTED_PAYLOAD')
                consume(effective, payload)
                remaining = (-entry.size) % 512
            else:
                remaining = ((entry.size + 511) // 512) * 512
            while remaining:
                amount = min(65536, remaining)
                if len(read(amount)) != amount:
                    raise ValueError('TRUNCATED_PAYLOAD')
                remaining -= amount
    return {'entries': count, 'declaredBytes': declared,
                      'expandedBytes': expanded, 'metadataBytes': output_bytes,
                      'globalPaxComment': expected_commit if global_pax_seen else None}

