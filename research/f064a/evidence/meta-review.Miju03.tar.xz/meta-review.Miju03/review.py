import hashlib,json,os,pathlib,signal,subprocess,sys,time
out=pathlib.Path(__file__).resolve().parent
source=pathlib.Path('/tmp/agentic-f064a-corpus-meta.meLM1N/run-1792329688912526000')
parser=source.parent/'list_tar.py'
original=json.loads((source/'receipt.json').read_text())
receipts=[]
deadline=time.monotonic()+180
for record in original['records']:
    name=record['repo'].split('/')[-1]
    archive=source/(name+'.tar.gz')
    assert archive.stat().st_size==record['download']['bytes']
    digest=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()
    assert digest==record['download']['sha256']
    prior=[]
    for phase in ['download','list']:
        receipt=json.loads((source/(name+'-'+phase+'.json')).read_text())
        assert receipt['exit']==0 and not receipt['expired'] and not receipt['members']
        assert (source/(name+'-'+phase+'.stderr')).stat().st_size==0
        prior.append(receipt)
    args=[sys.executable,str(parser),str(archive),name+'-'+record['commit'],str(out/(name+'.members.jsonl'))]
    start=time.monotonic()
    expired=False
    with (out/(name+'.stdout')).open('xb') as stdout,(out/(name+'.stderr')).open('xb') as stderr:
        proc=subprocess.Popen(args,stdout=stdout,stderr=stderr,start_new_session=True)
        try:
            proc.wait(timeout=min(30,deadline-time.monotonic()))
        except subprocess.TimeoutExpired:
            expired=True
            for sig in [signal.SIGTERM,signal.SIGKILL]:
                try: os.killpg(proc.pid,sig)
                except ProcessLookupError: pass
                if sig==signal.SIGTERM: time.sleep(5)
            proc.wait(timeout=10)
    ps=subprocess.run(['/bin/ps','-axo','pid,ppid,pgid,command'],capture_output=True,text=True,timeout=10,check=True)
    members=[line for line in ps.stdout.splitlines() if len(line.split())>=3 and line.split()[2]==str(proc.pid)]
    receipt={'repo':record['repo'],'command':args,'sha256':digest,'pid':proc.pid,'exit':proc.returncode,'expired':expired,'members':members,'elapsedMs':round((time.monotonic()-start)*1000),'prior':prior}
    receipts.append(receipt)
    (out/'receipts.json').write_text(json.dumps(receipts,indent=2))
    assert proc.returncode==0 and not expired and not members and time.monotonic()<deadline
    assert (out/(name+'.stderr')).stat().st_size==0
    assert json.loads((out/(name+'.stdout')).read_text())==record['metadata']
    assert (out/(name+'.members.jsonl')).read_bytes()==(source/(name+'.members.jsonl')).read_bytes()
    receipt['metadataIdentical']=True
    (out/'receipts.json').write_text(json.dumps(receipts,indent=2))
    print(name,'PASS',receipt['elapsedMs'])
print('3/0 independent offline metadata rerun; no extraction or network')
