mod sha256;
use std::{collections::{BTreeMap, BTreeSet}, env, fmt::Write as _, fs, io::{self, Write}, path::Path, time::Instant};
use tantivy::{collector::DocSetCollector, query::{AllQuery,BooleanQuery,Occur,Query,TermQuery},
    schema::{IndexRecordOption,Schema,Value,STORED,STRING}, Index,ReloadPolicy,TantivyDocument,Term};
type Failure=Box<dyn std::error::Error>;
const MODEL: usize=297_516_520;
struct Doc { bytes:usize, hash:String, path:String }
struct QuerySpec { slot:usize, text:String, hits:Vec<(String,usize,usize)> }
fn unhex(s:&str)->Result<String,Failure>{
    if s.len()%2!=0{return Err("HEX".into());}
    let bytes=(0..s.len()).step_by(2).map(|i|u8::from_str_radix(&s[i..i+2],16)).collect::<Result<Vec<_>,_>>()?;
    Ok(String::from_utf8(bytes)?)
}
fn reserve(b:usize)->Result<(),Failure>{
    if b>25352{return Err("DOC_BYTES".into());}
    let k=b+b.saturating_sub(1)+b.saturating_sub(2);
    let e=9*b+15*b.saturating_sub(1)+21*b.saturating_sub(2);
    let cost=8*b+512*k+4*(e+k)+1048576+4*352051+12*4096*64+8388608;
    if cost>58002188 || MODEL>512*1024*1024{return Err("MODEL".into());} Ok(())
}
fn grams(text:&str,query:bool)->Result<Vec<String>,Failure>{
    if query && text.encode_utf16().count()>4096{return Err("QUERY_LIMIT".into());}
    let chars:Vec<char>=text.chars().collect();
    let sizes=if query {vec![chars.len().min(3)]}else{vec![1,2,3]};
    let mut values=BTreeSet::new();
    for size in sizes{
        if size==0 || size>chars.len(){continue;}
        for slice in chars.windows(size){
            let mut token=format!("g{size}x");
            for c in slice{write!(&mut token,"{:06x}",*c as u32)?;}
            if !values.contains(&token)&&values.len()>=76056{return Err("TOKEN_COUNT".into());}
            values.insert(token);
        }
    }
    let bytes:usize=values.iter().map(String::len).sum::<usize>()+values.len().saturating_sub(1);
    if bytes>1216896{return Err("TOKEN_BYTES".into());}
    Ok(values.into_iter().collect())
}
fn checked(id:&str,raw:&str,docs:&BTreeMap<String,Doc>)->Result<String,Failure>{
    let doc=docs.get(id).ok_or("ID")?;reserve(doc.bytes)?;
    let hash=sha256::digest(raw.as_bytes());
    if raw.len()!=doc.bytes||hash!=doc.hash{return Err("RAW_IDENTITY".into());}Ok(hash)
}
fn hits_json(hits:&[(String,usize,usize)])->String{
    format!("[{}]",hits.iter().map(|(id,s,e)|format!("[\"{id}\",{s},{e}]")).collect::<Vec<_>>().join(","))
}
fn emit(result:String,total:&mut usize)->Result<(),Failure>{
    // Building result's JSON is measured by caller; this measures envelope formatting only.
    *total+=result.len()+1;if *total>64*1024*1024{return Err("OUTPUT_LIMIT".into());}
    let mut out=io::stdout().lock();out.write_all(result.as_bytes())?;out.write_all(b"\n")?;Ok(())
}
fn disk(path:&str)->Result<String,Failure>{
    let mut bytes=0u64;let mut files=0;
    for entry in fs::read_dir(path)?{
        let metadata=entry?.metadata()?;if !metadata.is_file(){return Err("INDEX_NONFILE".into());}
        bytes+=metadata.len();files+=1;
    } Ok(format!("{{\"bytes\":{bytes},\"files\":{files}}}"))
}
fn run()->Result<(),Failure>{
    if sha256::digest(b"abc")!="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        ||sha256::digest(b"")!="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"{return Err("SHA_KAT".into());}
    let args:Vec<_>=env::args().collect();if args.len()!=5{return Err("ARGS".into());}
    let mode=&args[1];let directory=&args[2];let source=&args[3];let corpus=&args[4];
    if mode!="build"&&mode!="query"{return Err("MODE".into());}
    let docbytes=fs::read(format!("{source}/docs.tsv"))?;
    let querybytes=fs::read(format!("{source}/queries.tsv"))?;
    if sha256::digest(&docbytes)!="c9b53c8e0c36b379aa9da77f178d3b1f86c80576ff46f1fd6d7dc1cc40aac64b"
        ||sha256::digest(&querybytes)!="208ce5ab37f9efdd4b2e1663847e52bdae6774485a44f7e7f8ad5bf5be46af3d"{return Err("MANIFEST".into());}
    let mut docs=BTreeMap::new();
    for line in std::str::from_utf8(&docbytes)?.lines(){
        let p:Vec<_>=line.split('\t').collect();if p.len()!=4{return Err("DOC_FIELDS".into());}
        docs.insert(p[0].to_string(),Doc{bytes:p[1].parse()?,hash:p[2].into(),path:unhex(p[3])?});
    }
    if docs.len()!=36||docs.values().map(|d|d.bytes).sum::<usize>()!=352051{return Err("DOC_SET".into());}
    let mut specs=Vec::new();
    for line in std::str::from_utf8(&querybytes)?.lines(){
        let p:Vec<_>=line.split('\t').collect();if p.len()!=3{return Err("QUERY_FIELDS".into());}
        let mut hits=Vec::new();
        if p[2]!="-" {for h in p[2].split(','){let v:Vec<_>=h.split(':').collect();hits.push((v[0].into(),v[1].parse()?,v[2].parse()?));}}
        specs.push(QuerySpec{slot:p[0].parse()?,text:unhex(p[1])?,hits});
    }
    if specs.len()!=12||specs[6].text!="\n\n"{return Err("QUERY_SET".into());}
    let mut b=Schema::builder();let id=b.add_text_field("id",STRING|STORED);
    let path=b.add_text_field("path",STORED);let raw=b.add_text_field("raw",STORED);
    let gram=b.add_text_field("gram",STRING);let schema=b.build();
    let opened=Instant::now();
    let index=if mode=="build"{
        if Path::new(directory).exists(){return Err("INDEX_EXISTS".into());}
        fs::create_dir(directory)?;Index::create_in_dir(directory,schema.clone())?
    }else{
        if !Path::new(directory).is_dir(){return Err("INDEX_MISSING".into());}
        Index::open_in_dir(directory)?
    };
    if index.schema()!=schema{return Err("SCHEMA".into());}
    let reader=index.reader_builder().reload_policy(ReloadPolicy::Manual).try_into()?;
    let mut output=0;
    emit(format!("{{\"result\":{{\"kind\":\"ready\",\"mode\":\"{mode}\",\"openNs\":{},\"modelBytes\":{MODEL},\"indexThreads\":1,\"mergeThreads\":4,\"writerBytes\":52428800}},\"serializeNs\":null}}",opened.elapsed().as_nanos()),&mut output)?;
    let mut writer=None;let mut visible_ns=0;
    if mode=="build"{
        let start=Instant::now();
        let mut w=index.writer_with_num_threads::<TantivyDocument>(1,50*1024*1024)?;
        for (key,d) in &docs{
            reserve(d.bytes)?;
            let filename=format!("{corpus}/{key}.raw");
            if fs::metadata(&filename)?.len()!=d.bytes as u64{return Err("INPUT_SIZE".into());}
            let text=String::from_utf8(fs::read(filename)?)?;
            checked(key,&text,&docs)?;
            let mut doc=TantivyDocument::default();doc.add_text(id,key);doc.add_text(path,&d.path);doc.add_text(raw,&text);
            for token in grams(&text,false)?{doc.add_text(gram,token);}
            w.add_document(doc)?;
        }
        w.commit()?;reader.reload()?;visible_ns=start.elapsed().as_nanos();writer=Some(w);
    }else{reader.reload()?;}
    let searcher=reader.searcher();
    if searcher.num_docs()!=36{return Err("LIVE_COUNT".into());}
    let mut schedule=Vec::new();
    for q in &specs {schedule.push((q,if mode=="build"{"commit-check"}else{"first"},0));}
    if mode=="query" {for q in &specs {
        for repeat in 0..10 {schedule.push((q,"warmup",repeat));}
        for repeat in 0..200 {schedule.push((q,"timed",repeat));}
    }}
    for (q,phase,repeat) in schedule {
            let start=Instant::now();let tokens=grams(&q.text,true)?;let fallback=tokens.len()>128;
            let query:Box<dyn Query>=if fallback{Box::new(AllQuery)}else{
                let clauses=tokens.iter().map(|t|(Occur::Must,Box::new(TermQuery::new(Term::from_field_text(gram,t),IndexRecordOption::Basic))as Box<dyn Query>)).collect();
                Box::new(BooleanQuery::new(clauses))
            };
            let addresses=searcher.search(query.as_ref(),&DocSetCollector)?;
            if addresses.len()>36{return Err("CANDIDATE_COUNT".into());}
            let mut rows=Vec::new();let mut bytes=0;
            for address in addresses{
                let doc=searcher.doc::<TantivyDocument>(address)?;
                let key=doc.get_first(id).and_then(|v|v.as_str()).ok_or("ID")?;
                let text=doc.get_first(raw).and_then(|v|v.as_str()).ok_or("RAW")?;
                let digest=checked(key,text,&docs)?;bytes+=text.len();if bytes>352051{return Err("CANDIDATE_BYTES".into());}
                let span=text.find(&q.text).map(|i|{let s=text[..i].encode_utf16().count();(s,s+q.text.encode_utf16().count())});
                rows.push((key.to_owned(),digest,span));
            }
            rows.sort_by(|a,b|a.0.cmp(&b.0));
            if rows.windows(2).any(|x|x[0].0==x[1].0){return Err("DUPLICATE".into());}
            let hits:Vec<_>=rows.iter().filter_map(|(key,_,span)|span.map(|(s,e)|(key.clone(),s,e))).collect();
            let elapsed=start.elapsed().as_nanos();if hits!=q.hits{return Err(format!("ORACLE_{}",q.slot).into());}
            let serial=Instant::now();
            let candidates=format!("[{}]",rows.iter().map(|(key,hash,_)|format!("[\"{key}\",\"{hash}\"]")).collect::<Vec<_>>().join(","));
            let result=format!("{{\"kind\":\"query\",\"phase\":\"{phase}\",\"repeat\":{repeat},\"slot\":{},\"queryNs\":{elapsed},\"candidateBytes\":{bytes},\"candidates\":{candidates},\"hits\":{},\"mode\":\"{}\"}}",q.slot,hits_json(&hits),if fallback{"scan-fallback"}else{"index"});
            let serial_ns=serial.elapsed().as_nanos();
            emit(format!("{{\"result\":{result},\"serializeNs\":{serial_ns}}}"),&mut output)?;
    }
    if mode=="build"{emit(format!("{{\"result\":{{\"kind\":\"build\",\"visibleNs\":{visible_ns},\"disk\":{}}},\"serializeNs\":null}}",disk(directory)?),&mut output)?;}
    drop(searcher);drop(reader);
    let close=Instant::now();if let Some(w)=writer{w.wait_merging_threads()?;}drop(index);
    emit(format!("{{\"result\":{{\"kind\":\"closed\",\"closeNs\":{},\"disk\":{}}},\"serializeNs\":null}}",close.elapsed().as_nanos(),disk(directory)?),&mut output)?;
    Ok(())
}
fn main(){if let Err(e)=run(){eprintln!("ERROR {e}");std::process::exit(1);}}

