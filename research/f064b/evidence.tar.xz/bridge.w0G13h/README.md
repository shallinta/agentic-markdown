# F064b isolated Node-API 8 bridge — source preparation only

No production files, dependency installation, compilation or engine execution has
been approved by source creation. Only AST/JS syntax checks are permitted initially.

After independent full-source review and explicit approval:

```
python3 /tmp/agentic-f064b-bridge.w0G13h/run.py compile
python3 /tmp/agentic-f064b-bridge.w0G13h/run.py diagnose
```

Compile is one 600-second deadline shared by cargo rustc and clang, exact process
groups/dual streams. The native-static-libs output is recorded and strictly checked,
not guessed. Runtime group limit is 15 seconds each, 180 batch, six cases first red
stop. Cleanup grace and ps probes are outside operation deadlines, not a hard global
wall-clock claim. Existing same Tantivy lock and isolated Rust1.90 cache are used;
no new Rust crates or Bun FFI. This .node links Rust staticlib into C Node-API8.

Parent fixture directories are created by the runner; each create target leaf must
not exist. Reader-only means no IndexWriter/schema repair; existing META_LOCK is
write-opened by Tantivy's public implementation, not OS-readonly media support.
The fixtures are exclusive and local, not hostile same-UID authorization proof.

ABI borrows inputs and caller-owned output only during each synchronous call. Rust
owns copied writer data and session; C wrappers are env-local type-tagged objects.
Output/meta/input overlapping buffers are rejected. All calls reserve 150000-byte
output before mutation; no mutation retry to enlarge output. Generation is stored
in the same Tantivy prepared commit payload, updated only after commit succeeds.
Commit-success/reload-error is poisoned/unknown, not rolled back by a response error.
Pending batches must commit before query; explicit close rolls back uncommitted
operations, tries writer join even if rollback fails, and only code0 is success.

Instance-data, hook and each wrapper hold independent state references. Cleanup
closes Rust resources but does not free wrappers; finalizers unlink and release.
Failed cleanup-hook removal retains its hook reference rather than risking UAF.
Case4's cleanupForTest is a deliberate invocation of the exact registered hook body,
not a natural OS failure. Actual process finalization separately records state-free.
Rust panic hook is once/global anonymous within the test process; catch_unwind is
not abort/OOM/segfault isolation. Worker is a thread, not process crash containment.

No unbounded writes queue. Host busy rejects before acceptance; one replaceable
query is separate. Native sync calls cannot process cancel messages; case4 sends
actual cancel only after commit1, gets native-close ACK with real lastCommit and
asserts only one batch was dispatched. No claim of mid-native interruption. Case6
uses explicit panic and worker post-commit reply-failure injection, never natural
allocation failure evidence. The malformed object test is a forged handle rejection,
not proof that a native handle can legitimately cross workers.

The projected live set is <=16 documents/65536 raw bytes, not each batch unbounded.
Raw preallocation is conservative (wire<=70000, scalar<=bytes, <=3gram windows,
two 128-byte-node+24-byte-token sets, raw copies, 50MiB arena and output scratch),
reserved before clones/grams; 128MiB is a logical model, not allocator RSS limit.
All operations are prevalidated/prepared before first delete/add. Full post-commit
IDs and raw bytes are verified at every CRUD stage. No user corpus, UI, current
window identity/dirty overlay, application build or packaging claim is included.

Source/header/native/lock pins and all process receipts are recorded. Old source
preparation findings are addressed before freezing, not misreported as executed
failures. Any actual compile/test failure must be preserved and reviewed before
another run; do not relax oracles or timeouts.
