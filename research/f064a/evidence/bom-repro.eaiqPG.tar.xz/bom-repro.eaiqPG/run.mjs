import { spawn, spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { strict as assert } from 'node:assert';
const root = new URL('.', import.meta.url).pathname.replace(/\/$/, '');
const stage = process.argv[2];
const comparisons = ['parameter-text', 'literal-text', 'parameter-blob'];
if (!['original', 'one-doc', 'no-fts', 'small', 'minimal', 'boundaries', ...comparisons].includes(stage)) throw Error('stage');
const bun = '/tmp/agentic-direct186.uXVnAg/Agentic Markdown-canary.app/Contents/MacOS/bun';
const args = stage === 'original'
  ? ['/tmp/agentic-f064a-literal.TNa1mW/sqlite.mjs', '/tmp/agentic-f064a-literal.TNa1mW/fixtures', 'A', 'q10.txt']
  : comparisons.includes(stage) ? [root + '/compare.mjs', stage]
  : ['minimal', 'boundaries'].includes(stage) ? [root + '/' + stage + '.mjs'] : [root + '/reduced.mjs', stage];
const output = root + '/run-' + stage + '-' + Date.now();
mkdirSync(output);
const start = Date.now();
const child = spawn(bun, args, { detached: true, stdio: ['ignore', 'pipe', 'pipe'] });
const stdout = [], stderr = [];
let expired = false, killTimer, error;
const kill = signal => { try { process.kill(-child.pid, signal); } catch (e) { if (e.code !== 'ESRCH') error = String(e); } };
const timer = setTimeout(() => {
  expired = true;
  kill('SIGTERM');
  killTimer = setTimeout(() => kill('SIGKILL'), 5000);
}, 15000);
child.stdout.on('data', chunk => stdout.push(chunk));
child.stderr.on('data', chunk => stderr.push(chunk));
child.on('error', e => { error = String(e); });
const [status, signal] = await new Promise(resolve => child.on('close', (s, sig) => resolve([s, sig])));
clearTimeout(timer);
if (killTimer) { await new Promise(resolve => setTimeout(resolve, 5100)); clearTimeout(killTimer); }
const ps = spawnSync('/bin/ps', ['-axo', 'pid,ppid,pgid,command'], { encoding: 'utf8', timeout: 10000 });
const members = (ps.stdout ?? '').split('\n').filter(line => line.trim().split(/\s+/)[2] === String(child.pid));
writeFileSync(output + '/stdout', Buffer.concat(stdout));
writeFileSync(output + '/stderr', Buffer.concat(stderr));
const receipt = { stage, bun, args, status, signal, expired, error, pid: child.pid, elapsedMs: Date.now() - start, members, psStatus: ps.status };
try {
  assert.equal(status, 0); assert.equal(expired, false); assert.equal(error, undefined);
  assert.equal(ps.status, 0); assert.deepEqual(members, []);
  const result = JSON.parse(Buffer.concat(stdout).toString('utf8'));
  if (stage === 'boundaries' || comparisons.includes(stage)) {
    assert.equal(result.input, 'efbbbfe4b8ad');
    Object.assign(receipt, { result, verdict: 'observation' });
  } else {
  const small = stage === 'small' || stage === 'minimal';
  const expectedHex = small ? 'efbbbfe4b8ad' : readFileSync('/tmp/agentic-f064a-literal.TNa1mW/fixtures/f.txt').toString('hex');
  const expectedSpan = small ? ['f', 1, 2] : ['f', 6, 9];
  const rawMatches = result.candidates?.length === 1 && result.candidates[0][0] === 'f' && result.candidates[0][1] === expectedHex;
  const spanMatches = JSON.stringify(result.hits) === JSON.stringify([expectedSpan]);
  Object.assign(receipt, { result, expectedHex, expectedSpan, rawMatches, spanMatches });
  assert.ok(rawMatches && spanMatches, 'BOM bytes and UTF16 span must be preserved');
  receipt.verdict = 'pass';
  }
} catch (e) {
  receipt.verdict = 'fail'; receipt.assertion = String(e); process.exitCode = 1;
}
writeFileSync(output + '/receipt.json', JSON.stringify(receipt, null, 2));
console.log(JSON.stringify({ output, ...receipt }));
