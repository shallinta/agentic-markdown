import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
INPUT_SHA = '461ee2187b50b0d8f092efab7a092c1878b5a6422a42deabc85bfb613338b60e'
LIMIT = 256 * 1024 * 1024
FIXED = 4 * 352051 + 12 * 4096 * 64 + 8 * 1024 * 1024


def inputs():
    raw = (ROOT / 'inputs.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == INPUT_SHA, 'INPUT_SHA'
    value = json.loads(raw)
    assert value['queries'][6].encode('utf-8').hex() == '0a0a', 'Q07_BYTES'
    assert len(value['queries'][6]) == units(value['queries'][6]) == 2, 'Q07_LENGTH'
    return value


def units(text):
    return sum(2 if ord(c) > 0xffff else 1 for c in text)


def validate(query):
    if any(0xd800 <= ord(c) <= 0xdfff for c in query):
        raise ValueError('SURROGATE')
    if units(query) > 4096:
        raise ValueError('QUERY_LIMIT')


def first(text, query):
    # Independent scalar start/element comparison, never substring find or gram candidates.
    validate(query)
    if not query:
        return None
    start_units = 0
    for start in range(len(text)):
        equal = start + len(query) <= len(text)
        if equal:
            for offset in range(len(query)):
                if text[start + offset] != query[offset]:
                    equal = False
                    break
        if equal:
            return [start_units, start_units + units(query)]
        start_units += 2 if ord(text[start]) > 0xffff else 1
    return None


def checked(path, entry):
    assert path.stat().st_size == entry['bytes'], 'INPUT_SIZE'
    raw = path.read_bytes()
    assert len(raw) == entry['bytes'], 'INPUT_READ_SIZE'
    assert hashlib.sha256(raw).hexdigest() == entry['sha256'], 'INPUT_FILE_SHA'
    return raw, raw.decode('utf-8', 'strict')


def reservation(size):
    n = size
    k = n + max(n - 1, 0) + max(n - 2, 0)
    encoded = 9 * n + 15 * max(n - 1, 0) + 21 * max(n - 2, 0)
    cost = 8 * size + 512 * k + 4 * (encoded + k) + 1024 * 1024 + FIXED
    assert cost <= LIMIT, 'RESERVATION_REFUSED'
    return cost


def selftest(m):
    root = pathlib.Path(m['literalDirectory'])
    files = {e['name']: e for e in m['literal']['files']}
    for case in m['literal']['cases']:
        _, query = checked(root / case['queryFile'], files[case['queryFile']])
        hits = []
        for doc in m['literal']['groups'][case['group']]:
            _, text = checked(root / (doc + '.txt'), files[doc + '.txt'])
            span = first(text, query)
            if span is not None:
                hits.append([doc, *span])
        assert hits == case['hits'], ('L_ORACLE', case['index'], hits)
    for query in ['\ud800', '\udc00', 'a' * 4097]:
        try:
            validate(query)
        except ValueError:
            continue
        raise AssertionError('ADMISSION_NOT_REJECTED')
    assert first('😀𠮷', '𠮷') == [2, 4]
    return {'status': 'selftest-passed', 'literalCases': 25, 'admissionRejected': 3}


def queries(m):
    d01 = m['documents'][0]
    reservation(d01['bytes'])
    _, text = checked(pathlib.Path(m['corpusDirectory']) / d01['output'], d01)
    result = list(m['queries'])
    result[11] = text[:512]
    assert len({result[11][i:i + 3] for i in range(max(len(result[11]) - 2, 0))}) > 128, 'LONG_QUERY_COVERAGE'
    for query in result:
        validate(query)
    return result


def document(m, doc_id):
    entry = next(e for e in m['documents'] if e['id'] == doc_id)
    reserved = reservation(entry['bytes'])  # Before read/scalar/Set allocations.
    query_list = queries(m)
    raw, text = checked(pathlib.Path(m['corpusDirectory']) / entry['output'], entry)
    gram_stats = []
    for length in (1, 2, 3):
        distinct = set()
        occurrences = max(len(text) - length + 1, 0)
        for start in range(occurrences):
            distinct.add(text[start:start + length])
        # Actual encoded grammar: g + length + 'x' + fixed six-hex codepoints.
        encoded_bytes = 0
        for gram in distinct:
            token = 'g' + str(length) + 'x' + ''.join(format(ord(c), '06x') for c in gram)
            assert len(token) == 3 + 6 * length
            encoded_bytes += len(token.encode('ascii'))
        gram_stats.append({'length': length, 'occurrences': occurrences,
                           'distinct': len(distinct), 'tokenBytes': encoded_bytes})
        del distinct
    distinct_count = sum(s['distinct'] for s in gram_stats)
    hits = [first(text, query) for query in query_list]
    assert hits[9] is None, 'ABSENT_QUERY_MATCHED'
    crlf = text.count('\r\n')
    return {'id': doc_id, 'sha256': entry['sha256'], 'bytes': len(raw),
            'scalars': len(text), 'utf16': units(text), 'bom': text.startswith('\ufeff'),
            'crlf': crlf, 'loneCR': text.count('\r') - crlf,
            'loneLF': text.count('\n') - crlf, 'grams': gram_stats,
            'joinedTokenBytes': sum(s['tokenBytes'] for s in gram_stats)
                                + max(distinct_count - 1, 0),
            'reservationBytes': reserved, 'hits': hits}


def main():
    m = inputs()
    mode = sys.argv[1]
    if mode == 'selftest':
        result = selftest(m)
    elif mode == 'queries':
        result = {'queries': [{'slot': i + 1, 'text': q,
                  'sha256': hashlib.sha256(q.encode('utf-8')).hexdigest(),
                  'utf16': units(q), 'scalars': len(q)}
                  for i, q in enumerate(queries(m))]}
    elif mode == 'document':
        result = document(m, sys.argv[2])
    else:
        raise ValueError('MODE')
    output = json.dumps(result, ensure_ascii=True).encode()
    assert len(output) <= 8 * 1024 * 1024, 'OUTPUT_LIMIT'
    print(output.decode('ascii'))


if __name__ == '__main__':
    main()

