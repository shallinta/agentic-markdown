import gzip
import hashlib
import json
import os
import pathlib
import signal
import subprocess
import sys
import tarfile
import time

ROOT = pathlib.Path(__file__).resolve().parent
PARSER = '/tmp/agentic-f064a-corpus-meta.meLM1N/list_tar.py'
COMMIT = '354712584b6be1e8532f2ff8559cd01d26ce3c14'
TOP = 'docs-zh-cn-' + COMMIT
# Fixed oracle before any execution. Reject cases require the specific parser error.
CASES = [
    ('ordinary', True, None),
    ('global-comment', True, None),
    ('bad-checksum', False, 'bad checksum'),
    ('duplicate', False, 'DUPLICATE_EFFECTIVE_PATH'),
    ('symlink', False, 'UNSUPPORTED_TYPE'),
    ('parent-path', False, 'UNSAFE_PATH'),
    ('local-pax-path', False, 'UNSUPPORTED_TYPE'),
]


def entry(name, payload=b'', kind=tarfile.REGTYPE, link=''):
    info = tarfile.TarInfo(name)
    info.type = kind
    info.size = len(payload)
    info.linkname = link
    info.mtime = 0
    return info.tobuf(format=tarfile.USTAR_FORMAT) + payload + bytes((-len(payload)) % 512)


def pax(key, value):
    body = (key + '=' + value + '\n').encode()
    length = len(body) + 2
    while len(str(length)) + 1 + len(body) != length:
        length = len(str(length)) + 1 + len(body)
    return str(length).encode() + b' ' + body


base = entry(TOP + '/', kind=tarfile.DIRTYPE)
file = entry(TOP + '/one.md', b'fixture only\n')
archives = {
    'ordinary': base + file,
    'global-comment': entry('pax_global_header', pax('comment', COMMIT), tarfile.XGLTYPE) + base + file,
    'bad-checksum': bytes([base[0] ^ 1]) + base[1:] + file,
    'duplicate': base + file + file,
    'symlink': base + entry(TOP + '/link', kind=tarfile.SYMTYPE, link='one.md'),
    'parent-path': base + entry(TOP + '/../escape.md', b'x'),
    'local-pax-path': base + entry(TOP + '/pax', pax('path', TOP + '/override.md'), tarfile.XHDTYPE) + file,
}
manifest = []
for name, accepted, reason in CASES:
    # Two termination blocks plus extra standard zero padding, all counted.
    compressed = gzip.compress(archives[name] + bytes(1536), mtime=0)
    path = ROOT / (name + '.tar.gz')
    with path.open('xb') as output:
        output.write(compressed)
    manifest.append({'case': name, 'accepted': accepted, 'reason': reason,
                     'sha256': hashlib.sha256(compressed).hexdigest(), 'bytes': len(compressed)})
with (ROOT / 'manifest.json').open('x') as output:
    json.dump(manifest, output, indent=2)

receipts = []
for expected in manifest:
    name = expected['case']
    args = [sys.executable, PARSER, str(ROOT / (name + '.tar.gz')), TOP, str(ROOT / (name + '.members.jsonl'))]
    start = time.monotonic()
    expired = False
    with (ROOT / (name + '.stdout')).open('xb') as out, (ROOT / (name + '.stderr')).open('xb') as err:
        process = subprocess.Popen(args, stdout=out, stderr=err, start_new_session=True)
        try:
            process.wait(timeout=30)
        except subprocess.TimeoutExpired:
            expired = True
            os.killpg(process.pid, signal.SIGTERM)
            time.sleep(5)
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait(timeout=10)
    ps = subprocess.run(['/bin/ps', '-axo', 'pid,ppid,pgid,command'], text=True, capture_output=True, timeout=10, check=True)
    members = [line for line in ps.stdout.splitlines() if len(line.split()) >= 3 and line.split()[2] == str(process.pid)]
    stderr = (ROOT / (name + '.stderr')).read_text()
    passed = ((process.returncode == 0) if expected['accepted'] else
              (process.returncode != 0 and expected['reason'] in stderr))
    passed = passed and not expired and not members
    if passed and expected['accepted']:
        result = json.loads((ROOT / (name + '.stdout')).read_text())
        passed = result['entries'] == 2 and result['globalPaxComment'] == (COMMIT if name == 'global-comment' else None)
    receipt = {**expected, 'command': args, 'exit': process.returncode, 'expired': expired,
               'members': members, 'elapsedMs': round((time.monotonic() - start) * 1000), 'passed': passed}
    receipts.append(receipt)
    (ROOT / 'receipts.json').write_text(json.dumps(receipts, indent=2))
    print(json.dumps(receipt))
    if not passed:
        raise SystemExit(1)
print('7/0 fixed offline cases; no network')
