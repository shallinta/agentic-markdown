"""Explicit compile/correctness/finite20. Reuse frozen inputs; never generate."""
import hashlib
import json
import math
import os
import pathlib
import sys
import time
from processes import BINARY, BUN, LOCK_SHA, ROOT, TOOLCHAIN, command, sha

ENGINE_FILES = ['Cargo.toml', 'Cargo.lock', 'src/main.rs', 'src/sha256.rs',
                'sqlite.mjs', 'processes.py', 'run.py']


def sources(names):
    return {name: sha(ROOT / name) for name in names}


def encoded(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode('utf-8')


def validate(rows, stage, mode, sampling):
    expected = {q['slot']: q for q in stage['queries']}
    if mode not in ('query', 'cancel'):
        expected.update({100 + i: m for i, m in enumerate(stage['markers'])})
    docs = {d['id']: d for d in stage['documents']}
    queries = [r for r in rows if r['kind'] == 'query']
    count = 1 if mode == 'cancel' else (372 if sampling == 'finite20' else 12) if mode == 'query' else len(expected)
    assert len(queries) == count, 'QUERY_COUNT'
    first = {}
    for row in queries:
        slot = row['slot']
        assert slot in expected and row['queryNs'] >= 0 and row['serializeNs'] >= 0
        if 'semantic' in row:
            value = row['semantic']
            assert value['slot'] == slot and value['hits'] == expected[slot]['hits'], 'ORACLE'
            ids = [item[0] for item in value['candidates']]
            assert ids == sorted(set(ids)) and len(ids) <= len(docs), 'CANDIDATES'
            assert all(digest == docs[key]['sha256'] for key, digest in value['candidates'])
            assert value['candidateBytes'] == sum(docs[key]['bytes'] for key in ids)
            assert all(hit[0] in ids for hit in value['hits']), 'HIT_CANDIDATE'
            if slot == 12:
                assert value['mode'] == 'scan-fallback' and ids == sorted(docs), 'FALLBACK'
            raw = encoded(value)
            assert hashlib.sha256(raw).hexdigest() == row['digest'] and len(raw) == row['fullBytes']
            first[slot] = row
        prior = first[slot]
        for field in ('digest', 'fullBytes', 'candidateCount', 'hitCount'):
            assert row[field] == prior[field], 'REPEATED_RESULT'
        assert row['candidateCount'] == len(prior['semantic']['candidates'])
        assert row['hitCount'] == len(prior['semantic']['hits'])
    if mode == 'query':
        assert [(r['slot'], r['phase']) for r in queries[:12]] == [(i, 'first') for i in range(1, 13)]
        for slot in range(1, 13):
            selected = [r for r in queries if r['slot'] == slot]
            assert [r['repeat'] for r in selected if r['phase'] == 'warmup'] == (list(range(10)) if sampling == 'finite20' else [])
            assert [r['repeat'] for r in selected if r['phase'] == 'timed'] == (list(range(20)) if sampling == 'finite20' else [])
    assert rows[0]['kind'] == 'ready' and rows[-1]['kind'] == 'closed', 'LIFECYCLE'
    return queries, {slot: row['semantic'] for slot, row in first.items()}


def check_corpus(folder, expected_sha):
    raw = (folder / 'complete.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected_sha, 'COMPLETE_SHA'
    value = json.loads(raw)
    assert value['complete'] and value['n'] in (100, 1000, 10000)
    assert value['queryHex'][6] == '0a0a' and value['queryHex'][8] == '65cc81'
    assert len(value['stages']) == 7 and value['budget']['logicalBytes'] <= 346977964
    for stage in value['stages']:
        for name, digest in stage['pins'].items():
            assert sha(folder / stage['name'] / name) == digest, 'STAGE_PIN'
    for doc in value['files']:
        path = folder / doc['output']
        assert path.stat().st_size == doc['bytes'] and sha(path) == doc['sha256'], 'RAW_PIN'
    return value


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else ''
    assert mode in ('compile', 'correctness', 'finite20') and sys.platform == 'darwin'
    output = ROOT / ('run-' + str(time.time_ns()))
    output.mkdir()
    records = []
    result = {'status': 'failed', 'mode': mode}
    try:
        if mode == 'compile':
            frozen_sources = sources(ENGINE_FILES)
            result['sources'] = frozen_sources
            (output / 'sources.json').write_text(json.dumps(frozen_sources, indent=2))
            assert sha(ROOT / 'Cargo.lock') == LOCK_SHA
            prefix = TOOLCHAIN / 'prefix'
            environment = {**os.environ, 'RUSTC': str(prefix / 'bin/rustc'),
                           'RUSTDOC': str(prefix / 'bin/rustdoc'),
                           'CARGO_HOME': str(TOOLCHAIN / 'cargo-home'),
                           'CARGO_TARGET_DIR': str(ROOT / 'target'),
                           'PATH': str(prefix / 'bin') + os.pathsep + os.environ['PATH']}
            command(output, 'compile', [str(prefix / 'bin/cargo'), 'build', '--release', '--locked'],
                    time.monotonic() + 600, environment, False)
            assert sources(ENGINE_FILES) == frozen_sources and sha(ROOT / 'Cargo.lock') == LOCK_SHA
            result = {'status': 'complete', 'mode': mode, 'sources': frozen_sources, 'binarySHA': sha(BINARY)}
        else:
            # Explicit reviewed generated receipt + hash required; never auto-generate in a batch.
            assert len(sys.argv) == 4, 'BATCH_REQUIRES_FROZEN_RECEIPT_AND_SHA'
            generation_path = pathlib.Path(sys.argv[2])
            assert sha(generation_path) == sys.argv[3], 'GENERATION_RECEIPT_SHA'
            generation = json.loads(generation_path.read_bytes())
            assert generation['mode'] == 'generate' and generation['status'] == 'complete'
            frozen_sources = sources(ENGINE_FILES)
            result['sources'] = frozen_sources
            (output / 'sources.json').write_text(json.dumps(frozen_sources, indent=2))
            compiled = []
            for path in ROOT.glob('run-*/receipt.json'):
                value = json.loads(path.read_bytes())
                if value.get('mode') == 'compile' and value.get('status') == 'complete':
                    compiled.append((str(path), value))
            assert compiled, 'COMPILE_REQUIRED'
            compile_path, compilation = sorted(compiled)[-1]
            assert compilation['sources'] == frozen_sources and compilation['binarySHA'] == sha(BINARY), 'COMPILE_CHAIN'
            if mode == 'finite20':
                correct = [json.loads(p.read_bytes()) for p in ROOT.glob('run-*/receipt.json')]
                assert any(r.get('mode') == 'correctness' and r.get('status') == 'complete'
                           and r.get('sources') == frozen_sources and r.get('binarySHA') == sha(BINARY)
                           for r in correct), 'CORRECTNESS_REQUIRED'
            assert sha(pathlib.Path(BUN)) == '539598c775882420b9d8deb7dc14d845f20f7d26f5600c50ab067dde6ac3f3bf'
            assert [r['n'] for r in generation['records']] == [100, 1000, 10000]
            for corpus_record in generation['records']:
                if mode == 'finite20' and corpus_record['n'] != 10000:
                    continue
                corpus = pathlib.Path(corpus_record['corpus'])
                complete = check_corpus(corpus, corpus_record['completeSHA'])
                n = complete['n']; deadline = time.monotonic() + 900
                candidate_baseline = {}
                pairs = [['sqlite', 'tantivy']] if mode == 'correctness' else [['sqlite', 'tantivy'], ['tantivy', 'sqlite'], ['sqlite', 'tantivy']]
                for number, engines in enumerate(pairs, 1):
                    for engine in engines:
                        round_end = min(deadline, time.monotonic() + 120)
                        directory = output / f'{n}-{number}-{engine}-index'
                        jobs = [(complete['stages'][0], 'build'), (complete['stages'][0], 'query')]
                        if mode == 'correctness':
                            jobs += [(stage, stage['action']) for stage in complete['stages'][1:]]
                            jobs.append((complete['stages'][-1], 'cancel'))
                        for stage_pin, action in jobs:
                            assert sources(ENGINE_FILES) == frozen_sources, 'SOURCE_CHANGED'
                            stage_dir = corpus / stage_pin['name']
                            stage_raw = (stage_dir / 'manifest.json').read_bytes()
                            assert hashlib.sha256(stage_raw).hexdigest() == stage_pin['pins']['manifest.json']
                            stage = json.loads(stage_raw)
                            label = f'{n}-{number}-{engine}-{stage_pin["name"]}-{action}'
                            if engine == 'sqlite':
                                argv = [BUN, str(ROOT / 'sqlite.mjs'), action, str(directory), str(corpus),
                                        stage_pin['name'], corpus_record['completeSHA'], mode]
                            else:
                                argv = [str(BINARY), action, str(directory), str(stage_dir),
                                        str(output / 'NO_FIXTURES') if action in ('query', 'cancel') else str(corpus)]
                                argv += [stage_pin['pins'][name] for name in ('docs.tsv', 'queries.tsv', 'changes.tsv', 'deleted.tsv')]
                                argv.append(mode)
                            rows = command(output, label, argv, round_end, cancel=action == 'cancel')
                            assert sources(ENGINE_FILES) == frozen_sources, 'SOURCE_CHANGED'
                            samples, first = validate(rows, stage, action, mode)
                            for slot, semantic in first.items():
                                key = (stage_pin['name'], slot)
                                if key in candidate_baseline:
                                    assert candidate_baseline[key] == hashlib.sha256(encoded(semantic)).hexdigest(), 'ENGINE_CANDIDATE_DISAGREEMENT'
                                candidate_baseline[key] = hashlib.sha256(encoded(semantic)).hexdigest()
                            stats = []
                            if action == 'query' and mode == 'finite20':
                                for slot in range(1, 13):
                                    values = sorted(r['queryNs'] for r in samples if r['slot'] == slot and r['phase'] == 'timed')
                                    stats.append({'slot': slot, 'n': len(values), **{
                                        name: values[math.ceil(len(values) * fraction) - 1]
                                        for name, fraction in [('p50', .5), ('p95', .95), ('p99', .99), ('max', 1)]}})
                            records.append({'n': n, 'round': number, 'engine': engine, 'stage': stage_pin['name'],
                                            'action': action, 'label': label, 'stats': stats})
                        assert time.monotonic() < round_end, 'ROUND_DEADLINE'
                assert time.monotonic() < deadline, 'SCALE_DEADLINE'
                check_corpus(corpus, corpus_record['completeSHA'])
            result = {'status': 'complete', 'mode': mode, 'sources': frozen_sources, 'records': records,
                      'binarySHA': sha(BINARY), 'compileReceipt': compile_path,
                      'generationReceipt': str(generation_path), 'generationSHA': sys.argv[3]}
    except Exception as error:
        result.update({'status': 'failed', 'error': repr(error), 'records': records})
        raise
    finally:
        (output / 'receipt.json').write_text(json.dumps(result, indent=2))
        print(output)


if __name__ == '__main__':
    main()
