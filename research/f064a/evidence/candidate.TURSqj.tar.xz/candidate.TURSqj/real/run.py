import hashlib
import json
import math
import os
import pathlib
import selectors
import signal
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
TOOLCHAIN = pathlib.Path('/tmp/agentic-f064a-rust190.zxE80R')
BUN = '/tmp/agentic-direct186.uXVnAg/Agentic Markdown-canary.app/Contents/MacOS/bun'
LOCK_SHA = '639d75f7f400a528fb5879936175f31f51ba6a762e5cee8202f80f73dc00f347'
PINS = {
    'manifest.json': 'd6b544e240993096dfb7514621f7a954413df22d2189e69a8919abd497561711',
    'docs.tsv': 'c9b53c8e0c36b379aa9da77f178d3b1f86c80576ff46f1fd6d7dc1cc40aac64b',
    'queries.tsv': '208ce5ab37f9efdd4b2e1663847e52bdae6774485a44f7e7f8ad5bf5be46af3d',
    'Cargo.lock': LOCK_SHA,
}
BINARY = ROOT / 'target/release/f064a-toolchain-check'
LIMIT = 64 * 1024 * 1024


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(65536), b''):
            h.update(block)
    return h.hexdigest()


def preflight():
    for name, expected in PINS.items():
        if sha(ROOT / name) != expected:
            raise ValueError('PIN_' + name)
    manifest = json.loads((ROOT / 'manifest.json').read_bytes())
    if len(manifest['documents']) != 36 or len(manifest['queries']) != 12:
        raise ValueError('FIXED_COUNTS')
    ref = pathlib.Path('/tmp/agentic-f064a-reference.BDHlVX/run-1792330916464532000/results.json')
    if sha(ref) != manifest['referenceSHA']:
        raise ValueError('REFERENCE_SHA')
    reference = json.loads(ref.read_bytes())
    if manifest['queries'] != reference['oracle']:
        raise ValueError('REFERENCE_ORACLE')
    if manifest['queries'][6]['text'].encode().hex() != '0a0a':
        raise ValueError('Q07')
    if sum(d['bytes'] for d in manifest['documents']) != 352051:
        raise ValueError('CORPUS_SIZE')
    for doc in manifest['documents']:
        path = pathlib.Path(manifest['corpusDirectory']) / doc['output']
        if path.stat().st_size != doc['bytes'] or sha(path) != doc['sha256']:
            raise ValueError('CORPUS_SHA')
    if sha(pathlib.Path(BUN)) != '539598c775882420b9d8deb7dc14d845f20f7d26f5600c50ab067dde6ac3f3bf':
        raise ValueError('BUN_SHA')
    return manifest


def group_members(pid):
    ps = subprocess.run(['/bin/ps', '-axo', 'pid,ppid,pgid,command'],
                        capture_output=True, text=True, timeout=10, check=True)
    return [line for line in ps.stdout.splitlines()
            if len(line.split()) >= 3 and line.split()[2] == str(pid)]


ACTIVE = {}


def command(output, label, argv, deadline, environment=None, parse=True):
    ACTIVE.clear()
    try:
        return command_inner(output, label, argv, deadline, environment, parse)
    except Exception as error:
        cleanup_errors = []
        process = ACTIVE.get('process')
        if process is not None:
            for sig in (signal.SIGTERM, signal.SIGKILL):
                try:
                    os.killpg(process.pid, sig)
                except ProcessLookupError:
                    break
                except Exception as cleanup:
                    cleanup_errors.append(repr(cleanup))
                if sig == signal.SIGTERM:
                    time.sleep(5)
            try:
                process.wait(timeout=10)
            except Exception as cleanup:
                cleanup_errors.append(repr(cleanup))
        for handle in ACTIVE.get('files', {}).values():
            try:
                handle.close()
            except Exception as cleanup:
                cleanup_errors.append(repr(cleanup))
        if 'selector' in ACTIVE:
            ACTIVE['selector'].close()
        members = None
        if process is not None:
            try:
                members = group_members(process.pid)
            except Exception as cleanup:
                cleanup_errors.append(repr(cleanup))
        path = output / (label + '.json')
        prior = json.loads(path.read_bytes()) if path.exists() else {}
        prior.update({'innerFailure': prior.get('failure'), 'outerError': repr(error), 'cleanupErrors': cleanup_errors,
                      'membersAfterCleanup': members, 'pid': None if process is None else process.pid,
                      'partialCounts': ACTIVE.get('counts'), 'partialRSS': ACTIVE.get('samples')})
        path.write_text(json.dumps(prior, indent=2))
        raise
    finally:
        ACTIVE.clear()


def command_inner(output, label, argv, deadline, environment=None, parse=True):
    started = time.monotonic()
    process = subprocess.Popen(argv, cwd=ROOT, env=environment, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, start_new_session=True)
    ACTIVE['process'] = process
    selector = selectors.DefaultSelector()
    files = {}
    counts = {'stdout': 0, 'stderr': 0}
    ACTIVE.update({'files': files, 'selector': selector, 'counts': counts})
    for channel, pipe in [('stdout', process.stdout), ('stderr', process.stderr)]:
        os.set_blocking(pipe.fileno(), False)
        selector.register(pipe, selectors.EVENT_READ, channel)
        files[channel] = (output / (label + '.' + channel)).open('xb')
    samples = []
    ACTIVE['samples'] = samples
    sample_errors = []
    last_sample = 0.0
    finished = False
    failed = None
    term_at = None
    usage = None
    status = None
    first_line = bytearray()
    ready_at = None
    while not finished or selector.get_map():
        tick = time.monotonic()
        if not finished and (tick >= deadline or failed is not None) and term_at is None:
            failed = failed or 'DEADLINE'
            term_at = tick
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        if term_at is not None and tick - term_at > 5 and not finished:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        if not finished and tick - last_sample >= .020:
            sampled_at = time.monotonic()
            try:
                probe = subprocess.run(['/bin/ps', '-o', 'rss=', '-p', str(process.pid)],
                                       capture_output=True, text=True, timeout=2)
                raw = probe.stdout.strip()
            except Exception as error:
                sample_errors.append({'atSeconds': time.monotonic() - started, 'error': repr(error)})
                raw = ''
            if raw.isdigit():
                samples.append({'atSeconds': sampled_at - started, 'rssBytes': int(raw) * 1024})
            last_sample = tick
        for key, _ in selector.select(timeout=.005):
            chunk = os.read(key.fileobj.fileno(), 65536)
            if not chunk:
                selector.unregister(key.fileobj)
                key.fileobj.close()
                continue
            channel = key.data
            if parse and channel == 'stdout' and ready_at is None and len(first_line) < 1048576:
                first_line.extend(chunk)
                if b'\n' in first_line:
                    try:
                        initial = json.loads(first_line.split(b'\n', 1)[0])
                        if initial.get('result', {}).get('kind') == 'ready':
                            ready_at = time.monotonic() - started
                    except (ValueError, UnicodeError):
                        failed = 'READY_JSON'
            counts[channel] += len(chunk)
            if counts[channel] <= LIMIT:
                files[channel].write(chunk)
            else:
                failed = 'OUTPUT_LIMIT'
        if not finished:
            pid, result_status, result_usage = os.wait4(process.pid, os.WNOHANG)
            if pid:
                finished = True
                status = os.waitstatus_to_exitcode(result_status)
                process.returncode = status
                usage = result_usage
        if finished and selector.get_map() and time.monotonic() > deadline + 15:
            failed = failed or 'PIPE_DRAIN_TIMEOUT'
            for key in list(selector.get_map().values()):
                selector.unregister(key.fileobj)
                key.fileobj.close()
    for handle in files.values():
        handle.close()
    selector.close()
    members = group_members(process.pid)
    if members:
        failed = failed or 'RESIDUAL_GROUP'
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        time.sleep(5)
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        members = group_members(process.pid)
    elapsed = time.monotonic() - started
    baseline = samples[0]['rssBytes'] if samples else None
    peak = max((s['rssBytes'] for s in samples), default=None)
    ready_sample = next((s for s in samples if ready_at is not None
                         and s['atSeconds'] >= ready_at), None)
    ready_peak = max((s['rssBytes'] for s in samples if ready_at is not None
                      and s['atSeconds'] >= ready_at), default=None)
    receipt = {'argv': argv, 'pid': process.pid, 'exit': status, 'failure': failed,
               'elapsedSeconds': elapsed, 'members': members, 'stdoutBytes': counts['stdout'],
               'stderrBytes': counts['stderr'], 'rssSamples': samples,
               'sampleErrors': sample_errors,
               'firstSampleBaselineBytes': baseline, 'samplePeakBytes': peak,
               'readyObservedSeconds': ready_at,
               'readyBaselineBytes': None if ready_sample is None else ready_sample['rssBytes'],
               'readyPeakBytes': ready_peak,
               'readyPeakDeltaBytes': None if ready_sample is None else ready_peak - ready_sample['rssBytes'],
               'samplePeakDeltaBytes': None if peak is None else peak - baseline,
               'maxRSSBytes': None if usage is None else usage.ru_maxrss,
               'maxRSSUnit': 'macOS getrusage ru_maxrss bytes',
               'samplingCaveat': '20ms target; actual intervals recorded; short peaks/start allocations may be missed'}
    rows = []
    if parse and not failed and status == 0 and not members:
        parse_start = time.perf_counter_ns()
        raw = (output / (label + '.stdout')).read_bytes()
        try:
            rows = [json.loads(line) for line in raw.splitlines()]
        except Exception as error:
            failed = 'PARSE_' + type(error).__name__
            receipt['failure'] = failed
        receipt['hostParseNs'] = time.perf_counter_ns() - parse_start
        receipt['hostSpawnToParsedNs'] = int((time.monotonic() - started) * 1e9)
    (output / (label + '.json')).write_text(json.dumps(receipt, indent=2))
    if failed or status != 0 or members or time.monotonic() >= deadline:
        raise RuntimeError('FAILED_' + label)
    return rows


def validate_rows(rows, manifest, phase):
    expected = {q['slot']: q for q in manifest['queries']}
    docs = {d['id']: d for d in manifest['documents']}
    queries = [r for r in rows if r['result']['kind'] == 'query']
    wanted = 12
    if len(queries) != wanted:
        raise ValueError('ROW_COUNT')
    for envelope in queries:
        r = envelope['result']
        if r['hits'] != expected[r['slot']]['hits']:
            raise ValueError('ORACLE')
        ids = [c[0] for c in r['candidates']]
        if ids != sorted(set(ids)) or len(ids) > 36:
            raise ValueError('CANDIDATES')
        if any(h != docs[i]['sha256'] for i, h in r['candidates']):
            raise ValueError('CANDIDATE_SHA')
        if r['candidateBytes'] != sum(docs[i]['bytes'] for i in ids):
            raise ValueError('CANDIDATE_BYTES')
        if r['slot'] == 12 and (r['mode'] != 'scan-fallback' or len(ids) != 36):
            raise ValueError('FALLBACK')
    if phase == 'query':
        if [(r['result']['slot'], r['result']['phase']) for r in queries[:12]] != [(i, 'first') for i in range(1, 13)]:
            raise ValueError('FIRST_PHASE')
        for slot in range(1, 13):
            sample = [r for r in queries if r['result']['slot'] == slot]
            if [r['result']['phase'] for r in sample].count('warmup') != 0 or [r['result']['phase'] for r in sample].count('timed') != 0:
                raise ValueError('REPETITIONS')
    return queries


def main():
    mode = sys.argv[1] if len(sys.argv) == 2 else ''
    if mode not in ('compile', 'correctness') or sys.platform != 'darwin':
        raise ValueError('MODE_OR_PLATFORM')
    manifest = preflight()
    output = ROOT / ('run-' + str(time.time_ns()))
    output.mkdir()
    sources = {str(p.relative_to(ROOT)): sha(p) for p in
               [ROOT/'Cargo.toml',ROOT/'Cargo.lock',ROOT/'manifest.json',ROOT/'docs.tsv',
                ROOT/'queries.tsv',ROOT/'sqlite.mjs',ROOT/'src/main.rs',ROOT/'src/sha256.rs',ROOT/'run.py']}
    (output/'sources.json').write_text(json.dumps(sources,indent=2))
    def check_sources():
        if {name: sha(ROOT/name) for name in sources} != sources:
            raise ValueError('SOURCE_CHANGED')
    records = []
    candidate_baseline = {}
    try:
        if mode == 'compile':
            prefix = TOOLCHAIN/'prefix'
            environment = {**os.environ, 'RUSTC':str(prefix/'bin/rustc'),
                           'RUSTDOC':str(prefix/'bin/rustdoc'),
                           'CARGO_HOME':str(TOOLCHAIN/'cargo-home'),
                           'CARGO_TARGET_DIR':str(ROOT/'target'),
                           'PATH':str(prefix/'bin')+os.pathsep+os.environ['PATH']}
            command(output,'compile',[str(prefix/'bin/cargo'),'build','--release','--locked'],
                    time.monotonic()+600, environment, False)
            preflight()
            check_sources()
            result = {'status':'complete','mode':'compile','binarySHA':sha(BINARY), 'sources': sources}
        else:
            successful = []
            for receipt_path in ROOT.glob('run-*/receipt.json'):
                receipt = json.loads(receipt_path.read_bytes())
                if receipt.get('status') == 'complete' and receipt.get('mode') == 'compile':
                    successful.append((receipt_path, receipt))
            if not successful:
                raise ValueError('NO_SUCCESSFUL_COMPILE')
            compile_path, compiled = sorted(successful, key=lambda item: str(item[0]))[-1]
            if compiled['sources'] != sources or compiled['binarySHA'] != sha(BINARY):
                raise ValueError('COMPILE_SOURCE_BINARY_MISMATCH')
            deadline = time.monotonic()+300
            for number, engines in enumerate([['sqlite','tantivy']],1):
                for engine in engines:
                    preflight()
                    round_end = min(deadline,time.monotonic()+120)
                    directory = output/f'{number}-{engine}-index'
                    for phase in ['build','query']:
                        label=f'{number}-{engine}-{phase}'
                        argv=([BUN,str(ROOT/'sqlite.mjs'),phase,str(directory)] if engine=='sqlite'
                              else [str(BINARY),phase,str(directory),str(ROOT),
                                    manifest['corpusDirectory'] if phase=='build' else str(output/'NO_FIXTURES')])
                        rows=command(output,label,argv,round_end)
                        check_sources()
                        preflight()
                        data=validate_rows(rows,manifest,phase)
                        if phase == 'query':
                            for envelope in data[:12]:
                                row = envelope['result']
                                key = row['slot']
                                identity = [row['candidates'], row['candidateBytes'], row['hits'], row['mode']]
                                if key in candidate_baseline and candidate_baseline[key] != identity:
                                    raise ValueError('ENGINE_CANDIDATE_DISAGREEMENT')
                                candidate_baseline[key] = identity
                        stats=[]
                        records.append({'round':number,'engine':engine,'phase':phase,'stats':stats})
                    if time.monotonic() >= round_end:
                        raise ValueError('ROUND_DEADLINE')
            if time.monotonic() >= deadline:
                raise ValueError('BATCH_DEADLINE')
            result={'status':'complete','mode':'correctness','binarySHA':sha(BINARY),'records':records,
                    'compileReceipt':str(compile_path), 'sources':sources}
    except Exception as error:
        result={'status':'failed','mode':mode,'error':repr(error),'records':records,'sources':sources}
        raise
    finally:
        (output/'receipt.json').write_text(json.dumps(result,indent=2))
        print(output)


if __name__ == '__main__':
    main()

