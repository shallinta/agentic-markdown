import assert from 'node:assert/strict';
import { addon, invoke } from '/tmp/agentic-f064b-bridge.w0G13h/protocol.mjs';
const native = addon('/tmp/agentic-f064b-bridge.w0G13h');
let handle, opened, stage = 0;
self.onmessage = async event => {
  const { op, mode, index, audit } = event.data;
  assert.equal(mode, 'zero-yield');
  if (op === 'open') {
    assert.equal(stage, 0);
    stage = 1;
    assert.equal(native.audit(Buffer.from(audit)), 0);
    handle = native.open(Buffer.from(index), 0);
    assert.equal(typeof handle, 'object');
    const initial = invoke(native, handle, 4);
    assert.equal(initial.code, 0);
    assert.equal(initial.generation, 0);
    opened = native.stats();
    postMessage({ op, mode, opened });
    return;
  }
  assert.equal(op, 'close');
  assert.equal(stage, 1);
  stage = 2;
  const code = native.close(handle);
  assert.equal(code, 0);
  const afterClose = native.stats();
  handle = null;
  const afterYield = native.stats();
  postMessage({ mode, opened, afterClose, code, afterYield, closed: true });
  close();
};
