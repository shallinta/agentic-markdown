import { mkdirSync, existsSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const root = new URL('.', import.meta.url).pathname;
if (existsSync(root + 'manifest.json')) throw Error('FROZEN');
mkdirSync(root + 'fixtures');
const texts = { a0: '\ufeff旧词\r\n😀', a1: '\ufeff新词\r\n😀', b: '旁文', c: '\ufeff重建\r\n😀' };
const files = Object.entries(texts).map(([name, text]) => {
  const bytes = Buffer.from(text);
  writeFileSync(root + 'fixtures/' + name + '.txt', bytes, { flag: 'wx' });
  return { name: name + '.txt', bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') };
});
// Fixed hand-written live document and UTF16 query oracles; not engine-derived.
const a0 = ['a', 'p.md', 'a0.txt'], a1 = ['a', 'p.md', 'a1.txt'];
const b = ['b', 'q.md', 'b.txt'], c = ['c', 'p.md', 'c.txt'];
const initial = [[['a', 1, 3]], [], [], [['a', 5, 7]], []];
const added = [[['a', 1, 3]], [], [], [['a', 5, 7]], [['b', 0, 2]]];
const updated = [[], [['a', 1, 3]], [], [['a', 5, 7]], [['b', 0, 2]]];
const deleted = [[], [], [], [], [['b', 0, 2]]];
const recreated = [[], [], [['c', 1, 3]], [['c', 5, 7]], [['b', 0, 2]]];
const stages = [
  { stage: 1, action: 'create', live: [a0], hits: initial },
  { stage: 2, action: 'readonly-reopen', live: [a0], hits: initial },
  { stage: 3, action: 'add-b', live: [a0, b], hits: added },
  { stage: 4, action: 'update-a', live: [a1, b], hits: updated },
  { stage: 5, action: 'delete-a', live: [b], hits: deleted },
  { stage: 6, action: 'add-c', live: [b, c], hits: recreated },
  { stage: 7, action: 'readonly-reopen', live: [b, c], hits: recreated },
];
const manifest = { files, queries: ['旧词', '新词', '重建', '😀', '旁文'], stages, cases: 14 };
const bytes = Buffer.from(JSON.stringify(manifest, null, 2) + '\n');
writeFileSync(root + 'manifest.json', bytes, { flag: 'wx' });
console.log(createHash('sha256').update(bytes).digest('hex'));
