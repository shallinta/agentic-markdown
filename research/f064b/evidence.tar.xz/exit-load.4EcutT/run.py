"""One load-only minimisation, explicitly invoked after source review."""
import json
import pathlib
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
OLD = pathlib.Path('/tmp/agentic-f064b-bridge.w0G13h')
sys.path.insert(0, str(OLD))
from processes import command, sha

BUN = pathlib.Path('/tmp/agentic-direct186.uXVnAg/Agentic Markdown-canary.app/Contents/MacOS/bun')

def main():
    assert len(sys.argv) == 1
    compiled = json.loads((OLD / 'run-1792339410377845000/receipt.json').read_bytes())
    assert compiled['status'] == 'complete'
    assert all(sha(OLD / name) == value for name, value in compiled['sources'].items())
    assert sha(OLD / 'index-primitives.node') == compiled['nativeSHA']
    assert sha(BUN) == compiled['bunSHA']
    pins = {name: sha(ROOT / name) for name in ('probe.mjs', 'load-worker.mjs', 'run.py')}
    output = ROOT / ('run-' + str(time.time_ns()))
    output.mkdir()
    receipt = {'status': 'running', 'mode': 'load-addon-only', 'sources': pins, 'original': compiled}
    try:
        rows = command(output, 'probe', [str(BUN), str(ROOT / 'probe.mjs')],
                       time.monotonic() + 15, parse=True)
        assert rows == [{'mode': 'load-addon-only', 'assertions': 'complete'}]
        assert all(sha(ROOT / name) == value for name, value in pins.items())
        assert all(sha(OLD / name) == value for name, value in compiled['sources'].items())
        assert sha(OLD / 'index-primitives.node') == compiled['nativeSHA']
        receipt['status'] = 'complete'
    except Exception as error:
        receipt.update(status='failed', error=repr(error))
        raise
    finally:
        (output / 'receipt.json').write_text(json.dumps(receipt, indent=2))
        print(output)

if __name__ == '__main__':
    main()
