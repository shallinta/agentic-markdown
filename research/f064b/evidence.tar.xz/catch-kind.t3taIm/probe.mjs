import assert from 'node:assert/strict';
import { isDeepStrictEqual } from 'node:util';
import { join } from 'node:path';

const [mode, output] = process.argv.slice(2);
const original = '/tmp/agentic-f064b-bridge.w0G13h';
if (mode === 'client-open-close') {
  const { Client } = await import('/tmp/agentic-f064b-bridge.w0G13h/client.mjs');
  const client = new Client(original);
  assert.equal((await client.send('open', { path: join(output, 'index'), mode: 0 })).code, 0);
  const result = await client.send('close');
  assert.deepEqual(result, { code: 0, closed: true, closeSucceeded: true, lastCommit: 0 });
} else if (mode === 'direct-open-close') {
  const worker = new Worker(new URL('./worker.mjs', import.meta.url));
  let messages = 0, errors = 0, bridgeErrors = 0, failed = false, summaryWritten = false;
  const expected = [
    { version: 1, epoch: 1, id: 1, result: { code: 0, abi: 1 } },
    { version: 1, epoch: 1, id: 2, result: { code: 0, closed: true, closeSucceeded: true, lastCommit: 0 } },
  ];
  worker.addEventListener('message', event => {
    const data = event.data;
    const exact = messages < 2 && isDeepStrictEqual(data, expected[messages]);
    messages++;
    if (!exact) failed = true;
    const bridgeError = data?.result?.code === 'BRIDGE_ERROR';
    if (bridgeError) bridgeErrors++;
    if (messages + errors <= 16) console.log(JSON.stringify({
      event: 'message', ordinal: messages, exact, bridgeError,
      id: Number.isSafeInteger(data?.id) ? data.id : null,
    }));
  });
  worker.addEventListener('error', event => {
    errors++;
    failed = true;
    // Classification only: never print error text, stack, filename or path.
    const message = typeof event.message === 'string' ? event.message.slice(0, 4096) : '';
    const name = typeof event.error?.name === 'string' ? event.error.name : '';
    if (messages + errors <= 16) console.log(JSON.stringify({
      event: 'error', ordinal: errors,
      referenceError: name === 'ReferenceError' || message.includes('ReferenceError'),
      mentionsClose: /\bclose\b/.test(message),
    }));
  });
  process.on('beforeExit', () => {
    if (failed || messages !== 2 || errors !== 0 || bridgeErrors !== 0) process.exitCode = 1;
    if (!summaryWritten) {
      summaryWritten = true;
      console.log(JSON.stringify({ event: 'oracle-summary', messages, errors, bridgeErrors,
        failed: failed || messages !== 2 || errors !== 0 || bridgeErrors !== 0,
        overflow: messages + errors > 16 }));
    }
  });
  let id = 0;
  const send = (op, payload) => new Promise((resolve, reject) => {
    const current = ++id;
    worker.onerror = reject;
    worker.onmessage = event => {
      const message = event.data;
      assert.equal(message.version, 1);
      assert.equal(message.epoch, 1);
      assert.equal(message.id, current);
      resolve(message.result);
    };
    worker.postMessage({ version: 1, epoch: 1, id: current, op, payload });
  });
  assert.deepEqual(await send('open', { path: join(output, 'index'), mode: 0 }), { code: 0, abi: 1 });
  assert.deepEqual(await send('close', null), { code: 0, closed: true, closeSucceeded: true, lastCommit: 0 });
} else if (mode === 'bare-close') {
  const worker = new Worker(new URL('./bare-worker.mjs', import.meta.url));
  await new Promise((resolve, reject) => {
    worker.onerror = reject;
    worker.onmessage = event => {
      assert.deepEqual(event.data, { closed: true });
      resolve();
    };
    worker.postMessage('close');
  });
} else throw Error('MODE');
// This marker is not process-exit evidence. The external runner must observe exit 0.
console.log(JSON.stringify({ mode, assertions: 'complete' }));
