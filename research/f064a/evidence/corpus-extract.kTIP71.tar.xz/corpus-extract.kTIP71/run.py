import hashlib
import json
import os
import pathlib
import re
import signal
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
ALLOWLIST_SHA = 'a55ae06f9fff68177b9b8a8f5837835d1663c375e368564e27caf05267a58746'


def frozen_manifest():
    raw = (ROOT / 'allowlist.json').read_bytes()
    if hashlib.sha256(raw).hexdigest() != ALLOWLIST_SHA:
        raise ValueError('ALLOWLIST_SHA')
    value = json.loads(raw)
    if any(re.fullmatch(r'd\d{2}|l[1-5]', e['id'], re.ASCII) is None
           for e in value['entries']):
        raise ValueError('UNSAFE_ID')
    return value

REPOS = [
    ('vuejs-translations', 'docs-zh-cn', '354712584b6be1e8532f2ff8559cd01d26ce3c14'),
    ('vuejs', 'docs', '40aa88af0094f7bab4aaf786e55c748a6a251d88'),
    ('rust-lang', 'book', '1500248d8f230566e4ec9f27fcbb8fe9e2898ab1'),
]


def main():
    if sys.argv[1:] != ['extract-approved']:
        raise ValueError('EXPLICIT_MODE_REQUIRED')
    output = ROOT / ('run-' + str(time.time_ns()))
    output.mkdir()
    deadline = time.monotonic() + 180
    records = []
    manifest = frozen_manifest()
    entries = manifest['entries']
    if (len(entries) != 41 or len({e['id'] for e in entries}) != 41
            or sum(e['bytes'] for e in entries) != 399028
            or sum(e['bytes'] for e in entries if e['kind'] == 'document') != 352051
            or sum(e['kind'] == 'document' for e in entries) != 36
            or any(e['bytes'] < 0 or e['bytes'] > 1048576 for e in entries)):
        raise ValueError('FROZEN_ALLOWLIST_INVALID')
    sources = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
               for p in [ROOT / name for name in ['allowlist.json', 'safe_tar.py', 'extract.py', 'run.py']]}
    (output / 'sources.json').write_text(json.dumps(sources, indent=2))

    def command(label, script, args, budget):
        remaining = min(budget, deadline - time.monotonic())
        if remaining <= 0:
            raise TimeoutError('BATCH_DEADLINE')
        started = time.monotonic()
        with (output / (label + '.stdout')).open('xb') as stdout, (output / (label + '.stderr')).open('xb') as stderr:
            process = subprocess.Popen([sys.executable, str(ROOT / script), *args],
                                       stdout=stdout, stderr=stderr, start_new_session=True)
            expired = False
            try:
                process.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                expired = True
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                time.sleep(5)
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait(timeout=10)
        ps = subprocess.run(['/bin/ps', '-axo', 'pid,ppid,pgid,command'], capture_output=True,
                            text=True, timeout=10, check=True)
        members = [line for line in ps.stdout.splitlines()
                   if len(line.split()) >= 3 and line.split()[2] == str(process.pid)]
        receipt = {'label': label, 'python': sys.executable, 'script': script, 'args': args,
                   'pid': process.pid, 'exit': process.returncode, 'expired': expired,
                   'elapsedSeconds': time.monotonic() - started, 'members': members}
        (output / (label + '.json')).write_text(json.dumps(receipt, indent=2))
        if process.returncode != 0 or expired or members or time.monotonic() >= deadline:
            raise RuntimeError('FAILED_' + label)
        return json.loads((output / (label + '.stdout')).read_text())

    try:
        for owner, repo, commit in REPOS:
            frozen_manifest()
            result = command(repo + '-extract', 'extract.py', [repo, str(output)], 30)
            frozen_manifest()
            records.append(result)
        actual = [e for record in records for e in record['entries']]
        if (len(actual) != 41 or len({e['id'] for e in actual}) != 41
                or sum(e['bytes'] for e in actual) != 399028
                or sum(r['metadata']['expandedBytes'] for r in records) > 768 * 1024 * 1024):
            raise ValueError('FINAL_TOTALS')
        by_id = {e['id']: e for e in actual}
        for expected in entries:
            got = by_id[expected['id']]
            if any(got.get(k) != v for k, v in expected.items()):
                raise ValueError('FINAL_MANIFEST_MISMATCH')
            path = output / got['output']
            if path.stat().st_size != expected['bytes']:
                raise ValueError('FINAL_FILE_SIZE')
            if hashlib.sha256(path.read_bytes()).hexdigest() != got['sha256']:
                raise ValueError('FINAL_FILE_SHA')
        if time.monotonic() >= deadline:
            raise TimeoutError('BATCH_DEADLINE')
        receipt = {'status': 'complete', 'records': records, 'sources': sources}
    except Exception as error:
        receipt = {'status': 'failed', 'error': str(error), 'records': records}
        raise
    finally:
        (output / 'receipt.json').write_text(json.dumps(receipt, indent=2))
        print(output)


if __name__ == '__main__':
    main()

