import json
import os
import pathlib
import signal
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
REPOS = [
    ('vuejs-translations', 'docs-zh-cn', '354712584b6be1e8532f2ff8559cd01d26ce3c14'),
    ('vuejs', 'docs', '40aa88af0094f7bab4aaf786e55c748a6a251d88'),
    ('rust-lang', 'book', '1500248d8f230566e4ec9f27fcbb8fe9e2898ab1'),
]


def main():
    if sys.argv[1:] != ['acquire-metadata']:
        raise ValueError('EXPLICIT_MODE_REQUIRED')
    output = ROOT / ('run-' + str(time.time_ns()))
    output.mkdir()
    deadline = time.monotonic() + 360
    records = []
    compressed_total = 0
    expanded_total = 0

    def command(label, script, args, budget):
        remaining = min(budget, deadline - time.monotonic())
        if remaining <= 0:
            raise TimeoutError('BATCH_DEADLINE')
        started = time.monotonic()
        with (output / (label + '.stdout')).open('xb') as stdout, (output / (label + '.stderr')).open('xb') as stderr:
            process = subprocess.Popen([sys.executable, str(ROOT / script), *args],
                                       stdout=stdout, stderr=stderr, start_new_session=True)
            expired = False
            try:
                process.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                expired = True
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                time.sleep(5)
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait(timeout=10)
        ps = subprocess.run(['/bin/ps', '-axo', 'pid,ppid,pgid,command'], capture_output=True,
                            text=True, timeout=10, check=True)
        members = [line for line in ps.stdout.splitlines()
                   if len(line.split()) >= 3 and line.split()[2] == str(process.pid)]
        receipt = {'label': label, 'python': sys.executable, 'script': script, 'args': args,
                   'pid': process.pid, 'exit': process.returncode, 'expired': expired,
                   'elapsedSeconds': time.monotonic() - started, 'members': members}
        (output / (label + '.json')).write_text(json.dumps(receipt, indent=2))
        if process.returncode != 0 or expired or members or time.monotonic() >= deadline:
            raise RuntimeError('FAILED_' + label)
        return json.loads((output / (label + '.stdout')).read_text())

    try:
        for owner, repo, commit in REPOS:
            archive = output / (repo + '.tar.gz')
            url = 'https://codeload.github.com/' + owner + '/' + repo + '/tar.gz/' + commit
            downloaded = command(repo + '-download', 'download.py', [url, str(archive)], 120)
            compressed_total += downloaded['bytes']
            if compressed_total > 96 * 1024 * 1024:
                raise ValueError('TOTAL_TRANSFER_LIMIT')
            listed = command(repo + '-list', 'list_tar.py',
                             [str(archive), repo + '-' + commit, str(output / (repo + '.members.jsonl'))], 30)
            expanded_total += listed['expandedBytes']
            if expanded_total > 768 * 1024 * 1024:
                raise ValueError('TOTAL_EXPANDED_LIMIT')
            records.append({'repo': owner + '/' + repo, 'commit': commit,
                            'download': downloaded, 'metadata': listed})
        receipt = {'status': 'complete', 'records': records}
    except Exception as error:
        receipt = {'status': 'failed', 'error': str(error), 'records': records}
        raise
    finally:
        (output / 'receipt.json').write_text(json.dumps(receipt, indent=2))
        print(output)


if __name__ == '__main__':
    main()
