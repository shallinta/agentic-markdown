"""Six original case bodies, existing native binary, independent terminal observer."""
import json
import pathlib
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
OLD = pathlib.Path('/tmp/agentic-f064b-bridge.w0G13h')
sys.path.insert(0, str(OLD))
from processes import command, sha

BUN = pathlib.Path('/tmp/agentic-direct186.uXVnAg/Agentic Markdown-canary.app/Contents/MacOS/bun')
SOURCES = ['protocol.mjs', 'client.mjs', 'cases.mjs', 'worker.mjs', 'launch.mjs', 'run.py']

def main():
    assert len(sys.argv) == 1
    compiled = json.loads((OLD / 'run-1792339410377845000/receipt.json').read_bytes())
    assert compiled['status'] == 'complete'
    assert all(sha(OLD / name) == value for name, value in compiled['sources'].items())
    assert sha(ROOT / 'index-primitives.node') == sha(OLD / 'index-primitives.node') == compiled['nativeSHA']
    assert sha(BUN) == compiled['bunSHA']
    for name in ('protocol.mjs', 'client.mjs', 'cases.mjs'):
        assert (ROOT / name).read_bytes() == (OLD / name).read_bytes()
    assert (ROOT / 'worker.mjs').read_bytes() == (OLD / 'worker.mjs').read_bytes().replace(
        b'lastCommit});close();}', b'lastCommit});self.onmessage=null;}')
    frozen = {name: sha(ROOT / name) for name in SOURCES}
    output = ROOT / ('run-' + str(time.time_ns()))
    output.mkdir()
    result = {'status': 'running', 'sources': frozen, 'originalCompile': compiled, 'records': []}
    try:
        deadline = time.monotonic() + 180
        for case in range(1, 7):
            label = 'case' + str(case)
            rows = command(output, label, [str(BUN), str(ROOT / 'launch.mjs'), str(ROOT),
                           str(output / label), str(case)], min(deadline, time.monotonic() + 15), parse=True)
            case_rows = [r for r in rows if 'case' in r]
            assert case_rows == [{'case': str(case), 'status': 'complete', 'injected': case in (4, 6)}]
            summaries = [r['observerSummary'] for r in rows if 'observerSummary' in r]
            assert len(summaries) == 1 and summaries[0]['case'] == str(case)
            summary = summaries[0]
            assert summary['failed'] is False and summary['events'] <= 256
            assert len(summary['workers']) == {1: 0, 2: 2, 3: 0, 4: 1, 5: 0, 6: 1}[case]
            for worker in summary['workers']:
                assert worker['pending'] == worker['errors'] == worker['failures'] == 0
                assert worker['closed'] is True and worker['closeEvents'] == 1 and worker['closeCode'] == 0
                assert worker['held'] == worker['released'] == (1 if case == 4 else 0)
                assert worker['unknown'] == (1 if case == 6 else 0)
            if case == 4:
                cancel = [r['cancel'] for r in rows if 'cancel' in r]
                assert len(cancel) == 1
                value = cancel[0]
                assert value['ack'] >= value['sent']
                assert value['lastCompleted'] == value['lastPublished'] == value['batchDispatches'] == 1
                audit = (output / label / 'lifecycle.audit').read_text().splitlines()
                assert sum(line.startswith('close ') for line in audit) == 2
                assert sum(line.startswith('finalize ') for line in audit) == 2
                assert any(line.startswith('cleanup ') for line in audit)
                assert audit[-1] == 'state-free 2 2 2'
            assert all(sha(ROOT / name) == value for name, value in frozen.items())
            assert sha(ROOT / 'index-primitives.node') == compiled['nativeSHA']
            result['records'].append({'case': case, 'summary': summary})
        result['status'] = 'complete'
    except Exception as error:
        result.update(status='failed', error=repr(error))
        raise
    finally:
        result['originalUnchanged'] = all(sha(OLD / name) == value for name, value in compiled['sources'].items())
        result['sourcesUnchanged'] = all(sha(ROOT / name) == value for name, value in frozen.items())
        result['binaryUnchanged'] = sha(ROOT / 'index-primitives.node') == compiled['nativeSHA']
        if not all(result[key] for key in ('originalUnchanged', 'sourcesUnchanged', 'binaryUnchanged')):
            result.update(status='failed', pinError='CHANGED')
        (output / 'receipt.json').write_text(json.dumps(result, indent=2))
        print(output)
    assert result['status'] == 'complete'

if __name__ == '__main__':
    main()
