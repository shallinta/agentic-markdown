import hashlib
import json
import pathlib
import re
import sys

from safe_tar import scan

ROOT = pathlib.Path(__file__).resolve().parent
ALLOWLIST_SHA = 'a55ae06f9fff68177b9b8a8f5837835d1663c375e368564e27caf05267a58746'


def main():
    repo_name, output_arg = sys.argv[1:]
    output = pathlib.Path(output_arg)
    raw = (ROOT / 'allowlist.json').read_bytes()
    if hashlib.sha256(raw).hexdigest() != ALLOWLIST_SHA:
        raise ValueError('ALLOWLIST_SHA')
    manifest = json.loads(raw)
    if any(re.fullmatch(r'd\d{2}|l[1-5]', e['id'], re.ASCII) is None
           for e in manifest['entries']):
        raise ValueError('UNSAFE_ID')
    repo = next(r for r in manifest['repos'] if r['repo'] == repo_name)
    entries = [e for e in manifest['entries'] if e['repo'] == repo_name]
    root = repo_name + '-' + repo['commit']
    expected = {root + '/' + e['path']: e for e in entries}
    if len(expected) != len(entries) or any(e['bytes'] > 1048576 for e in entries):
        raise ValueError('ALLOWLIST_INVALID')
    archive = pathlib.Path(manifest['archiveDirectory']) / (repo_name + '.tar.gz')
    if archive.stat().st_size != repo['bytes']:
        raise ValueError('ARCHIVE_SIZE')
    digest = hashlib.sha256()
    with archive.open('rb') as source:
        for block in iter(lambda: source.read(65536), b''):
            digest.update(block)
    if digest.hexdigest() != repo['sha256']:
        raise ValueError('ARCHIVE_SHA')
    seen = set()
    results = []

    def selected(name, size, directory):
        entry = expected.get(name)
        if entry is None:
            return False
        if directory or size != entry['bytes'] or name in seen:
            raise ValueError('SELECTED_MEMBER_MISMATCH')
        return True

    def consume(name, payload):
        entry = expected[name]
        # Strict validation only. Never rewrite the original bytes or strip BOM/EOL.
        payload.decode('utf-8', 'strict')
        destination = output / (entry['id'] + '.raw')
        with destination.open('xb') as target:
            target.write(payload)
        seen.add(name)
        results.append({**entry, 'sha256': hashlib.sha256(payload).hexdigest(),
                        'output': destination.name,
                        'repository': repo['owner'] + '/' + repo_name,
                        'commit': repo['commit'], 'license': repo['license'],
                        'source': 'https://raw.githubusercontent.com/' + repo['owner']
                        + '/' + repo_name + '/' + repo['commit'] + '/' + entry['path']})

    # Always consumes the entire archive, including trailing zero blocks and gzip EOF.
    summary = scan(str(archive), root, str(output / (repo_name + '.members.jsonl')),
                   selected, consume)
    if seen != set(expected):
        raise ValueError('MISSING_MEMBERS')
    print(json.dumps({'repo': repo_name, 'metadata': summary, 'entries': results}))


if __name__ == '__main__':
    main()

