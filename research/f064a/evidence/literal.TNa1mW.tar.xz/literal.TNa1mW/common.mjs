export function validateScalarString(text) {
  if (typeof text !== 'string') throw Error('INVALID_SCALAR');
  for (let i = 0; i < text.length; i++) {
    const unit = text.charCodeAt(i);
    if (unit >= 0xd800 && unit <= 0xdbff) {
      const next = text.charCodeAt(++i);
      if (!(next >= 0xdc00 && next <= 0xdfff)) throw Error('INVALID_SCALAR');
    } else if (unit >= 0xdc00 && unit <= 0xdfff) throw Error('INVALID_SCALAR');
  }
  return text;
}

export function admitQuery(text, dispatch) {
  validateScalarString(text);
  if (text.length > 4096) return { mode: 'cost-refused', dispatches: 0 };
  if (!text.length) return { mode: 'skipped', dispatches: 0 };
  return dispatch(text);
}

export function token(scalars) {
  const n = scalars.length;
  if (n < 1 || n > 3) throw Error('GRAM_LENGTH');
  const encoded = 'g' + n + 'x' + scalars.map(c => c.codePointAt(0).toString(16).padStart(6, '0')).join('');
  if (!new RegExp('^g' + n + 'x[0-9a-f]{' + (6 * n) + '}$').test(encoded)) throw Error('TOKEN');
  return encoded;
}

export function grams(text, query = false) {
  validateScalarString(text);
  if (Buffer.byteLength(text) > 65536) throw Error('INPUT_BUDGET');
  const chars = Array.from(text);
  const set = new Set();
  const sizes = query ? [Math.min(3, chars.length)] : [1, 2, 3];
  for (const n of sizes) {
    if (!n) continue;
    for (let i = 0; i + n <= chars.length; i++) {
      const value = token(chars.slice(i, i + n));
      if (!set.has(value) && set.size >= 4096) throw Error('GRAM_BUDGET');
      set.add(value);
    }
  }
  return [...set].sort();
}

export function pureAdmissionCheck() {
  let dispatches = 0;
  const action = () => { dispatches++; return { mode: 'dispatch' }; };
  const refused = admitQuery('a'.repeat(4097), action);
  let rejected = 0;
  for (const text of ['\ud800', '\udc00']) {
    try { admitQuery(text, action); }
    catch (e) { if (e.message !== 'INVALID_SCALAR') throw e; rejected++; }
  }
  if (dispatches !== 0 || rejected !== 2 || refused.mode !== 'cost-refused') throw Error('ADMISSION');
  return { refused, rejected, dispatches };
}
